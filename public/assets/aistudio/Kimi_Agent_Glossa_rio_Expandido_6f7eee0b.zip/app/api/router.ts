import { z } from "zod";
import { createRouter, publicQuery } from "./middleware";
import {
  findGlossaryIndex,
  findGlossaryMeta,
  findGlossaryTermBySlug,
  findGlossaryTerms,
} from "./queries/glossary";
import { insertRieamFeedback } from "./queries/rieam";

export const appRouter = createRouter({
  ping: publicQuery.query(() => ({ ok: true, ts: Date.now() })),

  glossary: createRouter({
    list: publicQuery
      .input(
        z
          .object({
            category: z.string().optional(),
            subcategory: z.string().optional(),
            search: z.string().optional(),
          })
          .optional(),
      )
      .query(({ input }) => findGlossaryTerms(input ?? {})),

    bySlug: publicQuery
      .input(z.object({ slug: z.string() }))
      .query(({ input }) => findGlossaryTermBySlug(input.slug)),

    meta: publicQuery.query(() => findGlossaryMeta()),

    index: publicQuery.query(() => findGlossaryIndex()),
  }),

  rieam: createRouter({
    feedback: publicQuery
      .input(
        z.object({
          scenarioId: z.string().min(1).max(80),
          message: z.string().min(3).max(2000),
        }),
      )
      .mutation(({ input }) => insertRieamFeedback(input.scenarioId, input.message)),
  }),
});

export type AppRouter = typeof appRouter;
