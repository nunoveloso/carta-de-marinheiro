import { getDb } from "./connection";
import { rieamFeedback } from "../../db/schema";

export async function insertRieamFeedback(scenarioId: string, message: string) {
  const db = getDb();
  await db.insert(rieamFeedback).values({ scenarioId, message });
  return { ok: true };
}
