import { and, asc, eq, like, or, sql } from "drizzle-orm";
import { getDb } from "./connection";
import { glossaryTerms } from "../../db/schema";

export interface GlossaryFilter {
  category?: string;
  subcategory?: string;
  search?: string;
}

export async function findGlossaryTerms(filter: GlossaryFilter = {}) {
  const db = getDb();
  const conditions = [];
  if (filter.category) conditions.push(eq(glossaryTerms.category, filter.category));
  if (filter.subcategory)
    conditions.push(eq(glossaryTerms.subcategory, filter.subcategory));
  let searching = false;
  if (filter.search && filter.search.trim()) {
    searching = true;
    const q = `%${filter.search.trim()}%`;
    conditions.push(
      or(
        like(glossaryTerms.term, q),
        like(glossaryTerms.definition, q),
        like(glossaryTerms.section, q),
        like(glossaryTerms.subcategory, q),
      ),
    );
  }
  const query = db
    .select()
    .from(glossaryTerms)
    .where(conditions.length ? and(...conditions) : undefined);
  // Ao pesquisar: primeiro os títulos que correspondem, depois os restantes
  if (searching) {
    const q = `%${filter.search!.trim()}%`;
    return query.orderBy(
      sql`case when ${glossaryTerms.term} like ${q} then 0 else 1 end`,
      asc(glossaryTerms.term),
    );
  }
  return query.orderBy(asc(glossaryTerms.term));
}

export async function findGlossaryIndex() {
  const db = getDb();
  return db
    .select({ slug: glossaryTerms.slug, term: glossaryTerms.term })
    .from(glossaryTerms)
    .orderBy(asc(glossaryTerms.term));
}

export async function findGlossaryTermBySlug(slug: string) {
  const db = getDb();
  const rows = await db
    .select()
    .from(glossaryTerms)
    .where(eq(glossaryTerms.slug, slug))
    .limit(1);
  return rows[0] ?? null;
}

export async function findGlossaryMeta() {
  const db = getDb();
  const rows = await db
    .select({
      category: glossaryTerms.category,
      subcategory: glossaryTerms.subcategory,
      section: glossaryTerms.section,
      count: sql<number>`count(*)`.as("count"),
    })
    .from(glossaryTerms)
    .groupBy(
      glossaryTerms.category,
      glossaryTerms.subcategory,
      glossaryTerms.section,
    );

  const categories = new Map<string, Map<string, number>>();
  const sections = new Map<string, number>();
  for (const r of rows) {
    if (!categories.has(r.category)) categories.set(r.category, new Map());
    const subs = categories.get(r.category)!;
    subs.set(r.subcategory, (subs.get(r.subcategory) ?? 0) + Number(r.count));
    sections.set(r.section, (sections.get(r.section) ?? 0) + Number(r.count));
  }
  return {
    total: rows.reduce((acc, r) => acc + Number(r.count), 0),
    categories: [...categories.entries()].map(([name, subs]) => ({
      name,
      count: [...subs.values()].reduce((a, b) => a + b, 0),
      subcategories: [...subs.entries()].map(([sub, count]) => ({
        name: sub,
        count,
      })),
    })),
    sections: [...sections.entries()].map(([name, count]) => ({ name, count })),
  };
}
