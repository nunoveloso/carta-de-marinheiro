export interface Term {
  id: number;
  slug: string;
  term: string;
  definition: string;
  section: string;
  subsection: string | null;
  category: string;
  subcategory: string;
  illustration: string;
  wikiUrl: string | null;
  photoUrl: string | null;
  photoPage: string | null;
  sortOrder: number;
  createdAt: Date | string;
}

export const CATEGORY_META: Record<
  string,
  { color: string; soft: string; blurb: string }
> = {
  "R.I.E.A.M.": {
    color: "#0b3a55",
    soft: "#dce8ef",
    blurb: "Regulamento Internacional para Evitar Abalroamentos no Mar",
  },
  "Segurança e Primeiros Socorros": {
    color: "#b3402f",
    soft: "#f3ded9",
    blurb: "Meios de salvação, incêndios e socorrismo",
  },
  Marinharia: {
    color: "#1e7d4f",
    soft: "#dcebe1",
    blurb: "Nomenclatura, âncoras, cabos e manobras",
  },
  "Outras Matérias": {
    color: "#9a7413",
    soft: "#f0e8cf",
    blurb: "Legislação, balizagem, marés, meteorologia e motores",
  },
};

export function categoryColor(category: string): string {
  return CATEGORY_META[category]?.color ?? "#0b3a55";
}

export function categorySoft(category: string): string {
  return CATEGORY_META[category]?.soft ?? "#dce8ef";
}

/* ── Termos estrangeiros (apresentados em itálico) ──────────────────── */

const FOREIGN_SLUGS = new Set([
  "gmdss", "vhf", "dsc", "mmsi", "epirb", "sart", "gps", "ais", "sar",
  "colreg", "solas", "utc", "inmarsat", "egc", "mayday", "pan-pan",
]);

export function isForeign(slug: string): boolean {
  return FOREIGN_SLUGS.has(slug);
}

/* ── Mapa: secção do glossário → capítulo do manual ─────────────────── */

export const SECTION_GLOSSARY_MAP: Record<string, string[]> = {
  "meios-de-salvacao": ["Meios de salvação"],
  "definicoes-er": ["Definições de embarcação de recreio"],
  palamenta: ["Palamenta"],
  "manobras-de-cabos": ["Manobras de cabos"],
  "ancoras-e-amarras": ["Âncoras e amarras"],
  "homem-ao-mar": ["Manobra de homem ao mar"],
  "velocidade-distancia": ["Determinação de velocidade e distância"],
  mares: ["Marés"],
  "seguranca-no-mar": ["Segurança no mar"],
  "navegacao-mau-tempo": ["Navegação com mau tempo"],
  meteorologia: ["Meteorologia"],
  incendios: ["Prevenção e combate a incêndios"],
  socorrismo: ["Socorrismo"],
  motores: ["Motores"],
  rieam: ["R.I.E.A.M."],
  baloes: ["Balões"],
  balizagem: ["Sistema de balizagem marítima"],
  cis: ["Código internacional de sinais"],
  navtex: ["NAVTEX"],
  anexos: ["Anexos", "Legislação", "Portaria n.º 1464/2002"],
};

const GLOSSARY_TO_MANUAL: Record<string, string> = Object.fromEntries(
  Object.entries(SECTION_GLOSSARY_MAP).flatMap(([manualId, sections]) =>
    sections.map((s) => [s, manualId]),
  ),
);

/** Devolve o id do capítulo do manual que corresponde a uma secção do glossário */
export function manualSectionFor(glossarySection: string): string | null {
  return GLOSSARY_TO_MANUAL[glossarySection] ?? null;
}

/* ── Ligações cruzadas entre termos ─────────────────────────────── */

export interface TermIndexEntry {
  slug: string;
  term: string;
}

function escapeRe(s: string): string {
  return s.replace(/[.*+?^${}()|[\]\\]/g, "\\$&");
}

/** Deriva alias pesquisáveis de um termo: partes antes de —, ( , / e " ou " */
function aliases(term: string): string[] {
  const out = new Set<string>();
  const base = term.split(/\s+[—–(]/)[0].split(",")[0].split("/")[0].trim();
  if (base.length >= 3) out.add(base);
  // também cada segmento significativo depois de vírgulas / "e"
  for (const part of term.split(/[,;]|\s+e\s+/)) {
    const p = part.split(/\s+[—–(]/)[0].trim();
    if (p.length >= 4 && !p.includes(" ")) out.add(p);
  }
  return [...out];
}

interface IndexedAlias {
  pattern: RegExp;
  slug: string;
}

let cachedRegex: { key: string; aliases: IndexedAlias[] } | null = null;

function buildAliases(index: TermIndexEntry[]): IndexedAlias[] {
  const list: { alias: string; slug: string }[] = [];
  for (const e of index) {
    for (const a of aliases(e.term)) list.push({ alias: a, slug: e.slug });
  }
  // mais longo primeiro para ganhar a correspondência mais específica
  list.sort((a, b) => b.alias.length - a.alias.length);
  return list.map(({ alias, slug }) => {
    // plural simples: permite "s" final quando o alias termina em vogal
    const plural = /[aeiouáéíóúâêôãõ]$/i.test(alias) ? "s?" : "";
    return {
      slug,
      pattern: new RegExp(`(^|[^\\p{L}\\p{M}])(${escapeRe(alias)}${plural})(?=$|[^\\p{L}\\p{M}])`, "giu"),
    };
  });
}

export interface LinkSegment {
  text: string;
  slug?: string;
}

/**
 * Divide a definição em segmentos, marcando as ocorrências de outros termos
 * do glossário para serem apresentadas como ligações.
 */
export function linkify(
  text: string,
  index: TermIndexEntry[],
  excludeSlug: string,
): LinkSegment[] {
  const key = index.map((e) => e.slug).join("|");
  if (!cachedRegex || cachedRegex.key !== key) {
    cachedRegex = { key, aliases: buildAliases(index) };
  }
  const segments: LinkSegment[] = [];
  const taken: [number, number][] = [];
  for (const { pattern, slug } of cachedRegex.aliases) {
    if (slug === excludeSlug) continue;
    pattern.lastIndex = 0;
    let m: RegExpExecArray | null;
    while ((m = pattern.exec(text)) !== null) {
      const start = m.index + m[1].length;
      const end = start + m[2].length;
      if (taken.some(([a, b]) => start < b && end > a)) continue;
      taken.push([start, end]);
      segments.push({ text: m[2], slug });
      (segments[segments.length - 1] as LinkSegment & { _s: number })._s = start;
    }
  }
  if (!segments.length) return [{ text }];
  const withPos = segments as (LinkSegment & { _s?: number })[];
  withPos.sort((a, b) => (a._s ?? 0) - (b._s ?? 0));
  const out: LinkSegment[] = [];
  let cursor = 0;
  for (const s of withPos) {
    const start = s._s ?? 0;
    if (start > cursor) out.push({ text: text.slice(cursor, start) });
    out.push({ text: s.text, slug: s.slug });
    cursor = start + s.text.length;
  }
  if (cursor < text.length) out.push({ text: text.slice(cursor) });
  return out;
}

/** Slugs dos termos referenciados numa definição (para os chips "ver também") */
export function linkedSlugs(text: string, index: TermIndexEntry[], excludeSlug: string): string[] {
  const seen = new Set<string>();
  for (const seg of linkify(text, index, excludeSlug)) {
    if (seg.slug) seen.add(seg.slug);
  }
  return [...seen];
}

/** Texto normalizado para pesquisa: minúsculas e sem acentos */
export function normalizeText(s: string): string {
  return s
    .normalize("NFD")
    .replace(/[̀-ͯ]/g, "")
    .toLowerCase();
}

/** Versão "dobrada" do texto com mapa de posições para o original */
function fold(s: string): { text: string; map: number[] } {
  let text = "";
  const map: number[] = [];
  let i = 0;
  for (const ch of s) {
    const base = ch
      .normalize("NFD")
      .replace(/[̀-ͯ]/g, "")
      .toLowerCase();
    for (const b of base) {
      text += b;
      map.push(i);
    }
    i += ch.length;
  }
  return { text, map };
}

/** Verdadeiro se o termo corresponde à pesquisa no nome (sem acentos) */
export function titleMatches(term: string, query: string): boolean {
  const q = query.trim();
  if (q.length < 2) return false;
  return normalizeText(term).includes(normalizeText(q));
}

export interface SnippetMatch {
  text: string;
  matchStart: number;
  matchEnd: number;
}

/** Snippet da definição à volta da correspondência da pesquisa (sem acentos) */
export function matchSnippet(definition: string, query: string): SnippetMatch | null {
  const q = query.trim();
  if (q.length < 2) return null;
  const fd = fold(definition);
  const fq = fold(q).text;
  const i = fd.text.indexOf(fq);
  if (i === -1) return null;
  const mStart = fd.map[i];
  const mEnd = fd.map[i + fq.length - 1] + 1;
  const start = Math.max(0, mStart - 40);
  const end = Math.min(definition.length, mEnd + 60);
  const text = `${start > 0 ? "…" : ""}${definition.slice(start, end)}${end < definition.length ? "…" : ""}`;
  const off = start > 0 ? 1 : 0;
  return { text, matchStart: mStart - start + off, matchEnd: mEnd - start + off };
}
