import { MANUAL_SECTIONS } from "@/data/manual-content";
import type { Term } from "@/lib/glossary";

/* ── Normalização e tokenização ─────────────────────────────────── */

export function normalizeText(s: string): string {
  return s
    .toLowerCase()
    .normalize("NFD")
    .replace(/[\u0300-\u036f]/g, "");
}

const STOPWORDS = new Set(
  (
    "a o as os um uma uns umas de do da dos das em no na nos nas por pelo pela para com sem sob sobre " +
    "e ou mas que se como quando onde qual quais quanto quanta quantos quantas porque pois entao " +
    "o que é e sao ser esta estar este esta isto isso aquilo meu minha teu tua seu sua lhe " +
    "me te nos vos lhes eu tu ele ela eles elas foi era tem ter ha fazer faz posso podemos devo " +
    "muito mais menos ja ainda tambem aqui ali la assim ao aos à às num numa"
  ).split(/\s+/),
);

function tokens(s: string): string[] {
  return normalizeText(s)
    .split(/[^\p{L}\p{N}]+/u)
    .filter((t) => t.length >= 3 && !STOPWORDS.has(t));
}

/* ── Tipos de resposta ──────────────────────────────────────────── */

export interface InstructorAnswer {
  /** Texto principal da resposta (pode conter várias linhas) */
  text: string;
  /** Slugs de termos do glossário a mostrar como fichas clicáveis */
  termSlugs: string[];
  /** Foto ilustrativa (quando o tema principal a tem) */
  photo?: { url: string; alt: string };
  /** Ligação para um capítulo do Manual */
  manualRef?: { hash: string; title: string };
  /** Ligação interna extra (quiz, jogo R.I.E.A.M.…) */
  appLink?: { to: string; label: string };
}

interface Scored<T> {
  item: T;
  score: number;
}

function scoreText(question: string[], target: string): number {
  const hay = normalizeText(target);
  let s = 0;
  for (const t of question) {
    if (!t) continue;
    if (hay.includes(t)) s += t.length >= 5 ? 2 : 1;
  }
  return s;
}

/* ── Respostas fixas para temas estruturais ─────────────────────── */

const ROUTER_HINTS: { pattern: RegExp; answer: InstructorAnswer }[] = [
  {
    pattern: /rieam|regras? de rumo|prioridade|prevenir abalroamento|abalroamento/i,
    answer: {
      text: "O R.I.E.A.M. (Regulamento Internacional para Evitar Abalroamentos no Mar) define as regras de rumo e prioridade entre embarcações.\n\nA melhor forma de treinar estas situações é no jogo interativo, com cenários reais em que decides a manobra correta.",
      termSlugs: ["rieam"],
      appLink: { to: "/rieam", label: "Treinar no jogo R.I.E.A.M." },
    },
  },
  {
    pattern: /\bquiz\b|testar conhecimentos|auto.?avalia/i,
    answer: {
      text: "O quiz é a forma mais rápida de testares os teus conhecimentos: perguntas de escolha múltipla sobre todo o programa do exame de Marinheiro.",
      termSlugs: [],
      appLink: { to: "/quiz", label: "Ir para o Quiz" },
    },
  },
  {
    pattern: /exame|teste dgrm|prova teorica/i,
    answer: {
      text: "O exame teórico de Marinheiro (DGRM) cobre o conteúdo do Manual do Marinheiro: segurança, R.I.E.A.M., balizagem, meteorologia, marés, motores e armamento.\n\nPrepara-te com o glossário, o modo de estudo e o quiz.",
      termSlugs: [],
      appLink: { to: "/estudo", label: "Ir para o modo de estudo" },
    },
  },
];

/* ── Motor principal ────────────────────────────────────────────── */

export function answerQuestion(question: string, terms: Term[], context?: Term): InstructorAnswer {
  const q = question.trim();

  // 1) temas estruturais (R.I.E.A.M., quiz, exame)
  for (const h of ROUTER_HINTS) {
    if (h.pattern.test(q) && q.length < 120) {
      // ainda assim junta o melhor termo se houver um muito relevante
      const qt = tokens(q);
      const best = bestTerm(qt, terms);
      if (best && best.score >= 4 && !h.answer.termSlugs.includes(best.item.slug)) {
        h.answer.termSlugs = [best.item.slug, ...h.answer.termSlugs].slice(0, 3);
      }
      return h.answer;
    }
  }

  const qt = tokens(q);
  if (qt.length === 0) {
    return {
      text: "Não percebi bem a pergunta. Experimenta perguntar, por exemplo: «O que é uma balsa?», «Como se dá um lais de guia?» ou «O que significa boreste?».",
      termSlugs: [],
    };
  }

  // 2) melhores termos do glossário
  const termHits = terms
    .map((t) => {
      const titleScore = scoreText(qt, t.term) * 4;
      const defScore = scoreText(qt, t.definition);
      // bónus se a pergunta contém o nome do termo quase completo
      const bonus = normalizeText(q).includes(normalizeText(t.term)) ? 6 : 0;
      return { item: t, score: titleScore + defScore + bonus };
    })
    .filter((s) => s.score > 0)
    .sort((a, b) => b.score - a.score);

  // 2b) contexto do cenário (R.I.E.A.M.): tem prioridade quando a pergunta
  // toca na situação concreta (ex.: «porque não se guina para bombordo?»)
  if (context) {
    const ctxScore = scoreText(qt, context.definition) * 3;
    if (ctxScore >= 3 && (!termHits[0] || ctxScore >= termHits[0].score)) {
      const related = termHits
        .slice(0, 3)
        .filter((h) => h.score >= 5)
        .map((h) => h.item.slug);
      const manualHits0 = MANUAL_SECTIONS.map((sec) => ({
        item: sec,
        score: scoreText(qt, sec.title) * 4 + scoreText(qt, sec.paragraphs.join(" ")),
      })).sort((a, b) => b.score - a.score)[0];
      const ans: InstructorAnswer = {
        text: context.definition,
        termSlugs: related,
      };
      if (manualHits0 && manualHits0.score >= 4) {
        ans.manualRef = { hash: `manual-${manualHits0.item.id}`, title: manualHits0.item.title };
      }
      return ans;
    }
  }

  // 3) melhores capítulos do manual
  const manualHits = MANUAL_SECTIONS.map((sec) => ({
    item: sec,
    score: scoreText(qt, sec.title) * 4 + scoreText(qt, sec.paragraphs.join(" ")),
  }))
    .filter((s) => s.score > 0)
    .sort((a, b) => b.score - a.score);

  const top = termHits[0];

  if (top && top.score >= 3) {
    const t = top.item;
    const related = termHits
      .slice(1, 4)
      .filter((h) => h.score >= Math.max(3, top.score * 0.4))
      .map((h) => h.item.slug);
    const def =
      t.definition.length > 420 ? t.definition.slice(0, 420).replace(/\s+\S*$/, "") + "…" : t.definition;
    const ans: InstructorAnswer = {
      text: `${t.term} — ${def}`,
      termSlugs: [t.slug, ...related],
    };
    if (t.photoUrl) ans.photo = { url: t.photoUrl, alt: t.term };
    const m = manualHits[0];
    if (m && m.score >= 4) {
      ans.manualRef = { hash: `manual-${m.item.id}`, title: m.item.title };
    }
    return ans;
  }

  // 4) sem termo direto — tentar o manual
  const m = manualHits[0];
  if (m && m.score >= 4) {
    const excerpt = m.item.paragraphs[0];
    const cut = excerpt.length > 420 ? excerpt.slice(0, 420).replace(/\s+\S*$/, "") + "…" : excerpt;
    return {
      text: `Encontrei isto no capítulo «${m.item.title}» do Manual:\n\n${cut}`,
      termSlugs: termHits.slice(0, 3).map((h) => h.item.slug),
      manualRef: { hash: `manual-${m.item.id}`, title: m.item.title },
    };
  }

  return {
    text: "Não encontrei nada sobre isso no glossário nem no Manual. Tenta usar outras palavras — por exemplo o nome do objeto ou da manobra — ou escolhe uma das sugestões abaixo.",
    termSlugs: [],
  };
}

function bestTerm(qt: string[], terms: Term[]): Scored<Term> | null {
  let best: Scored<Term> | null = null;
  for (const t of terms) {
    const s = scoreText(qt, t.term) * 4 + scoreText(qt, t.definition);
    if (s > 0 && (!best || s > best.score)) best = { item: t, score: s };
  }
  return best;
}

export const SUGGESTIONS = [
  "O que é uma balsa salva-vidas?",
  "Como se faz um lais de guia?",
  "O que significa boreste?",
  "O que é o R.I.E.A.M.?",
  "Para que serve um cabeço?",
  "O que é a baixa-mar?",
];
