// Cenários do jogo R.I.E.A.M. — regras do dia (vista de cima, esquema tipo exame).
// Coordenadas num canvas 640×360. Rumos em graus: 0 = Norte (para cima), sentido horário.
// heading: rumo da embarcação · wind: direcção DE ONDE sopra o vento.

export type VesselKind = "motor" | "vela" | "vela-motor" | "pesca" | "sem-governo";

/** Balão diurno içado (Regras 26–28 do R.I.E.A.M.) */
export type DayShape = "esfera" | "esferas" | "bicone" | "cone-down";

export interface Vessel {
  id: string; // "A" | "B"
  kind: VesselKind;
  x: number;
  y: number;
  heading: number;
  boom?: "bb" | "eb"; // em que bordo vai a retranca (só vela)
  tag?: string; // legenda junto à etiqueta (ex.: "PESCA")
  stopped?: boolean; // parado (fundeado, a pescar, parado na água) — sem seta de rumo
  shape?: DayShape; // balão içado
  flagA?: boolean; // bandeira A hasteada (mergulhador em baixo)
}

export type TopicId = "opostos" | "cruzados" | "alcance" | "vela" | "prioridades";

export const TOPICS: { id: TopicId; label: string }[] = [
  { id: "opostos", label: "Rumos opostos" },
  { id: "cruzados", label: "Rumos cruzados" },
  { id: "alcance", label: "Alcance" },
  { id: "vela", label: "Vela" },
  { id: "prioridades", label: "Prioridades" },
];

export interface RieamScenario {
  id: string;
  topic: TopicId;
  you?: "A" | "B"; // embarcação em que o jogador está
  rule: string; // ex.: "Regra 15"
  prompt: string;
  ask: "who" | "do"; // who = clicar na embarcação · do = escolha múltipla
  vessels: Vessel[];
  wind?: number; // direcção de onde sopra (graus)
  options?: string[]; // ask === "do"
  correct: number; // índice da embarcação (who) ou da opção (do)
  explanation: string;
  slugs: string[]; // cartas do glossário para «saber mais»
  resolution?: { idx: number; heading: number; alts?: number[] }[]; // nova proa (e alternativas válidas) após manobra correcta
  channel?: boolean; // desenha um canal (marítimo, balizado)
}

export const RIEAM_SCENARIOS: RieamScenario[] = [
  // ---------- RUMOS OPOSTOS (Regra 14) ----------
  {
    id: "opostos-1",
    you: "A",
    topic: "opostos",
    rule: "Regra 14",
    ask: "do",
    prompt: "Estás no navio A. Vês o navio B exactamente pela proa, em rumo oposto. O que deves fazer?",
    vessels: [
      { id: "A", kind: "motor", x: 210, y: 285, heading: 0 },
      { id: "B", kind: "motor", x: 210, y: 75, heading: 180 },
    ],
    options: [
      "Guinar a estibordo",
      "Guinar a bombordo",
      "Manter rumo e velocidade",
      "Emitir dois sons curtos e guinar a bombordo",
    ],
    correct: 0,
    explanation:
      "Em rumos opostos com risco de abalroamento, ambos os navios guinam a estibordo, passando pelo costado de bombordo um do outro. Um som curto de apito acompanha a manobra («guino a estibordo»).",
    slugs: ["guinar", "bombordo-e-estibordo", "risco-de-abalroamento"],
    resolution: [
      { idx: 0, heading: 35, alts: [60] },
      { idx: 1, heading: 215, alts: [240] },
    ],
  },
  {
    id: "opostos-2",
    you: "A",
    topic: "opostos",
    rule: "Regra 14",
    ask: "do",
    prompt:
      "Estás no navio A. Vês B quase pela proa, ligeiramente a estibordo, e tens dúvidas: rumo oposto ou cruzado muito fechado? O que fazes?",
    vessels: [
      { id: "A", kind: "motor", x: 190, y: 285, heading: 0 },
      { id: "B", kind: "motor", x: 250, y: 70, heading: 185 },
    ],
    options: [
      "Assumir rumos opostos e guinar a estibordo",
      "Assumir rumos cruzados e manter rumo e velocidade",
      "Guinar a bombordo para me afastar mais depressa",
      "Acelerar para passar à proa de B",
    ],
    correct: 0,
    explanation:
      "A Regra 14 é clara: em caso de dúvida sobre se a situação é de rumos opostos, deve considerar-se que o é e agir em conformidade — guina-se a estibordo.",
    slugs: ["guinar", "risco-de-abalroamento", "apito"],
    resolution: [{ idx: 0, heading: 35, alts: [60] }],
  },

  // ---------- RUMOS CRUZADOS (Regras 15–17) ----------
  {
    id: "cruzados-1",
    you: "A",
    topic: "cruzados",
    rule: "Regra 15",
    ask: "who",
    prompt:
      "Rumos cruzados com risco de abalroamento: a marcação de B mantém-se constante. Clica na embarcação que se deve afastar.",
    vessels: [
      { id: "A", kind: "motor", x: 150, y: 240, heading: 90 },
      { id: "B", kind: "motor", x: 370, y: 300, heading: 0 },
    ],
    correct: 0,
    explanation:
      "A tem B a estibordo, por isso afasta-se; B mantém o rumo e a velocidade. A manobra de A deve ser ampla e, se possível, passando pela pôpa de B.",
    slugs: ["marcacao", "risco-de-abalroamento", "guinar"],
    resolution: [{ idx: 0, heading: 135, alts: [180] }],
  },
  {
    id: "cruzados-2",
    you: "A",
    topic: "cruzados",
    rule: "Regra 15",
    ask: "who",
    prompt:
      "Outra situação de rumos cruzados com risco de abalroamento. Clica na embarcação que se deve afastar.",
    vessels: [
      { id: "A", kind: "motor", x: 490, y: 250, heading: 270 },
      { id: "B", kind: "motor", x: 280, y: 300, heading: 0 },
    ],
    correct: 1,
    explanation:
      "B tem A a estibordo, por isso é B quem se afasta — reduzindo e guinando a estibordo, deixando A passar. A mantém rumo e velocidade.",
    slugs: ["marcacao", "risco-de-abalroamento", "guinar"],
    resolution: [{ idx: 1, heading: 60, alts: [90] }],
  },
  {
    id: "cruzados-3",
    you: "A",
    topic: "cruzados",
    rule: "Regra 15",
    ask: "do",
    prompt:
      "Estás no navio A, com o navio B a estibordo: a marcação mantém-se e a distância diminui. O que deves fazer?",
    vessels: [
      { id: "A", kind: "motor", x: 150, y: 240, heading: 90 },
      { id: "B", kind: "motor", x: 370, y: 300, heading: 0 },
    ],
    options: [
      "Guinar a estibordo, passando pela pôpa de B",
      "Manter rumo e velocidade — B é que deve afastar-se",
      "Acelerar para passar à proa de B",
      "Guinar a bombordo, cruzando a proa de B",
    ],
    correct: 0,
    explanation:
      "Quem tem o outro a estibordo afasta-se. A manobra deve ser ampla e feita com antecedência; evita-se cruzar a proa do navio que se mantém — passa-se pela sua pôpa.",
    slugs: ["marcacao", "risco-de-abalroamento", "guinar"],
    resolution: [{ idx: 0, heading: 135, alts: [180] }],
  },
  {
    id: "cruzados-4",
    you: "B",
    topic: "cruzados",
    rule: "Regra 17",
    ask: "do",
    prompt:
      "Estás no navio B. O navio A vem de bombordo e deve afastar-se, mas mantém rumo e velocidade. Num primeiro momento, o que fazes?",
    vessels: [
      { id: "A", kind: "motor", x: 150, y: 240, heading: 90 },
      { id: "B", kind: "motor", x: 370, y: 300, heading: 0 },
    ],
    options: [
      "Manter o rumo e a velocidade, vigiando A atentamente",
      "Guinar imediatamente a bombordo",
      "Parar a embarcação",
      "Emitir cinco sons curtos e virar já",
    ],
    correct: 0,
    explanation:
      "O navio que tem o outro por bombordo é o navio que se mantém: conserva rumo e velocidade (Regra 17a). Se A não manobrar e o risco persistir, aí sim poderás — e deverás — agir.",
    slugs: ["risco-de-abalroamento", "apito", "marcacao"],
  },
  {
    id: "cruzados-5",
    you: "B",
    topic: "cruzados",
    rule: "Regras 17 e 34",
    ask: "do",
    prompt:
      "Na mesma situação, A não manobra e o abalroamento torna-se iminente. O que deves fazer agora?",
    vessels: [
      { id: "A", kind: "motor", x: 150, y: 240, heading: 90 },
      { id: "B", kind: "motor", x: 370, y: 300, heading: 0 },
    ],
    options: [
      "Emitir cinco ou mais sons curtos e manobrar da forma mais segura",
      "Manter rigorosamente o rumo até ao contacto — a culpa é de A",
      "Guinar a bombordo em qualquer circunstância",
      "Emitir um som prolongado e parar",
    ],
    correct: 0,
    explanation:
      "Cinco ou mais sons curtos significam dúvida/perigo («não compreendo as tuas intenções»). Quando o outro não cumpre, o navio que se mantém pode — e por fim deve — manobrar; tendo um navio a bombordo, não se guina para bombordo.",
    slugs: ["som-curto-e-som-prolongado", "apito", "risco-de-abalroamento"],
    resolution: [{ idx: 1, heading: 45, alts: [90] }],
  },

  // ---------- ALCANCE (Regra 13) ----------
  {
    id: "alcance-1",
    you: "A",
    topic: "alcance",
    rule: "Regra 13",
    ask: "who",
    prompt:
      "O navio A, mais rápido, está a alcançar o navio B. Clica na embarcação que se deve afastar.",
    vessels: [
      { id: "B", kind: "vela", x: 320, y: 95, heading: 0, boom: "eb" },
      { id: "A", kind: "motor", x: 320, y: 260, heading: 0 },
    ],
    wind: 270,
    correct: 1,
    explanation:
      "No alcance, quem alcança afasta-se do alcançado — mesmo sendo um navio de propulsão mecânica a alcançar um veleiro. A regra do alcance prevalece sobre as prioridades da Regra 18.",
    slugs: ["navio-rieam", "embarcacao-a-vela-rieam", "marcacao"],
    resolution: [{ idx: 1, heading: 340, alts: [20] }],
  },
  {
    id: "alcance-2",
    you: "A",
    topic: "alcance",
    rule: "Regra 13",
    ask: "do",
    prompt:
      "Estás no navio A, a alcançar o navio B (passas a mais de 22,5° a ré do seu través). Por onde deves passar?",
    vessels: [
      { id: "B", kind: "motor", x: 320, y: 95, heading: 0 },
      { id: "A", kind: "motor", x: 320, y: 260, heading: 0 },
    ],
    options: [
      "Por qualquer um dos bordos, mantendo-me bem afastado de B",
      "Apenas por estibordo",
      "Apenas por bombordo",
      "Não posso alcançar sem autorização de B",
    ],
    correct: 0,
    explanation:
      "O navio que alcança pode passar por qualquer um dos bordos, mas é sempre ele o responsável por se manter afastado do alcançado — até finalmente passar e ficar livre.",
    slugs: ["navio-rieam", "traves", "risco-de-abalroamento"],
    resolution: [{ idx: 1, heading: 340, alts: [20] }],
  },

  // ---------- VELA (Regra 12) ----------
  {
    id: "vela-1",
    you: "A",
    topic: "vela",
    rule: "Regra 12",
    ask: "who",
    prompt:
      "Dois veleiros com bordos opostos: A recebe o vento por bombordo; B recebe-o por estibordo. Clica na embarcação que se deve afastar.",
    wind: 0,
    vessels: [
      { id: "A", kind: "vela", x: 170, y: 210, heading: 90, boom: "eb" },
      { id: "B", kind: "vela", x: 470, y: 150, heading: 270, boom: "eb" },
    ],
    correct: 0,
    explanation:
      "Com bordos opostos, afasta-se quem recebe o vento por bombordo — neste caso A (repara para que lado vai a retranca de cada um).",
    slugs: ["barlavento-e-sotavento", "bombordo-e-estibordo", "bordejar"],
    resolution: [{ idx: 0, heading: 140, alts: [180] }],
  },
  {
    id: "vela-2",
    you: "A",
    topic: "vela",
    rule: "Regra 12",
    ask: "who",
    prompt:
      "Dois veleiros no mesmo bordo, com o vento de oeste: B está a barlavento de A. Clica na embarcação que se deve afastar.",
    wind: 270,
    vessels: [
      { id: "B", kind: "vela", x: 250, y: 150, heading: 180, boom: "bb" },
      { id: "A", kind: "vela", x: 400, y: 150, heading: 180, boom: "bb" },
    ],
    correct: 0,
    explanation:
      "No mesmo bordo, o veleiro que está a barlavento (do lado de onde sopra o vento) afasta-se do que está a sotavento.",
    slugs: ["barlavento-e-sotavento", "bordejar", "orcar-e-arribar"],
    resolution: [{ idx: 0, heading: 225 }],
  },
  {
    id: "vela-3",
    you: "A",
    topic: "vela",
    rule: "Regra 12",
    ask: "do",
    prompt:
      "Estás no veleiro A, com o vento por bombordo. Vês o veleiro B a barlavento, mas a vela dele esconde a retranca e não consegues determinar o seu bordo. O que fazes?",
    wind: 0,
    vessels: [
      { id: "A", kind: "vela", x: 210, y: 230, heading: 60, boom: "eb" },
      { id: "B", kind: "vela", x: 430, y: 130, heading: 240, boom: "eb" },
    ],
    options: [
      "Afastar-me do caminho de B",
      "Manter rumo — quem está a sotavento tem sempre prioridade",
      "Emitir dois sons curtos e manter rumo",
      "Orçar e parar até B passar",
    ],
    correct: 0,
    explanation:
      "Se um veleiro com o vento por bombordo vir outro a barlavento e não puder determinar com certeza o bordo desse outro, deve afastar-se do caminho dele (Regra 12a, iii).",
    slugs: ["barlavento-e-sotavento", "bombordo-e-estibordo", "orcar-e-arribar"],
    resolution: [{ idx: 0, heading: 110, alts: [150] }],
  },

  // ---------- PRIORIDADES (Regras 18, 13 e 9) ----------
  {
    id: "prio-1",
    you: "A",
    topic: "prioridades",
    rule: "Regra 18",
    ask: "who",
    prompt:
      "Rumos cruzados entre um navio a motor (A) e um veleiro (B). Clica na embarcação que se deve afastar.",
    wind: 270,
    vessels: [
      { id: "A", kind: "motor", x: 160, y: 240, heading: 90 },
      { id: "B", kind: "vela", x: 380, y: 300, heading: 0, boom: "eb" },
    ],
    correct: 0,
    explanation:
      "Um navio de propulsão mecânica em movimento afasta-se do caminho de uma embarcação à vela (Regra 18a) — a vela tem prioridade sobre o motor.",
    slugs: ["embarcacao-a-vela-rieam", "navio-rieam", "guinar"],
    resolution: [{ idx: 0, heading: 135 }],
  },
  {
    id: "prio-2",
    you: "A",
    topic: "prioridades",
    rule: "Regra 18",
    ask: "who",
    prompt:
      "Um veleiro (A) e uma embarcação de pesca engajada na pesca (B), com os aparelhos de fora. Clica na embarcação que se deve afastar.",
    wind: 180,
    vessels: [
      { id: "A", kind: "vela", x: 170, y: 265, heading: 90, boom: "bb" },
      { id: "B", kind: "pesca", x: 410, y: 185, heading: 0, tag: "PESCA" },
    ],
    correct: 0,
    explanation:
      "A embarcação à vela afasta-se do caminho de uma embarcação engajada na pesca (Regra 18b) — a pesca limita a capacidade de manobra. Mantém distância também dos aparelhos.",
    slugs: ["embarcacao-de-pesca-rieam", "embarcacao-a-vela-rieam"],
    resolution: [{ idx: 0, heading: 135 }],
  },
  {
    id: "prio-3",
    you: "A",
    topic: "prioridades",
    rule: "Regras 13 e 18",
    ask: "who",
    prompt:
      "O veleiro A, mais rápido, está a alcançar o navio a motor B. Clica na embarcação que se deve afastar.",
    wind: 250,
    vessels: [
      { id: "B", kind: "motor", x: 320, y: 90, heading: 0 },
      { id: "A", kind: "vela", x: 320, y: 255, heading: 0, boom: "eb" },
    ],
    correct: 1,
    explanation:
      "Parece estranho, mas é a regra do alcance que manda: quem alcança afasta-se do alcançado, qualquer que seja o tipo de embarcação — mesmo um veleiro a alcançar um navio a motor.",
    slugs: ["embarcacao-a-vela-rieam", "navio-rieam", "marcacao"],
    resolution: [{ idx: 1, heading: 25 }],
  },
  {
    id: "prio-4",
    you: "A",
    topic: "prioridades",
    rule: "Regras 3 e 18",
    ask: "who",
    prompt:
      "O navio A é um veleiro, mas navega a motor com as velas arriadas. Rumos cruzados com o veleiro B, à vela. Clica na embarcação que se deve afastar.",
    wind: 270,
    vessels: [
      { id: "A", kind: "vela-motor", x: 165, y: 240, heading: 90, tag: "A MOTOR" },
      { id: "B", kind: "vela", x: 385, y: 300, heading: 0, boom: "eb" },
    ],
    correct: 0,
    explanation:
      "Um veleiro a navegar a motor é considerado, para o R.I.E.A.M., um navio de propulsão mecânica — por isso afasta-se do caminho da embarcação à vela.",
    slugs: ["embarcacao-a-vela-rieam", "navio-rieam"],
    resolution: [{ idx: 0, heading: 135 }],
  },
  {
    id: "prio-5",
    you: "A",
    topic: "prioridades",
    rule: "Regra 18",
    ask: "who",
    prompt:
      "Rumos cruzados entre o navio A e o navio B, que está sem governo (duas bolas negras). Clica na embarcação que se deve afastar.",
    vessels: [
      { id: "A", kind: "motor", x: 160, y: 240, heading: 90 },
      { id: "B", kind: "sem-governo", x: 385, y: 295, heading: 0, tag: "SEM GOVERNO" },
    ],
    correct: 0,
    explanation:
      "Todo o navio em movimento afasta-se do caminho de um navio sem governo (ou com capacidade de manobra reduzida) — são os mais protegidos pela Regra 18.",
    slugs: ["navio-sem-governo", "capacidade-de-manobra-reduzida", "risco-de-abalroamento"],
    resolution: [{ idx: 0, heading: 135 }],
  },
  {
    id: "prio-6",
    you: "A",
    topic: "prioridades",
    rule: "Regra 9",
    ask: "who",
    prompt:
      "Num canal estreito: o veleiro A cruza à frente do navio B, que só pode navegar em segurança dentro do canal. Clica na embarcação que não deve dificultar a passagem.",
    channel: true,
    wind: 270,
    vessels: [
      { id: "B", kind: "motor", x: 330, y: 105, heading: 180 },
      { id: "A", kind: "vela", x: 270, y: 260, heading: 20, boom: "eb" },
    ],
    correct: 1,
    explanation:
      "Num canal estreito, a embarcação à vela não deve dificultar a passagem de um navio que só pode navegar com segurança dentro do canal (Regra 9b) — A sai-lhe do caminho.",
    slugs: ["embarcacao-a-vela-rieam", "navio-rieam", "calado"],
    resolution: [{ idx: 1, heading: 90, alts: [45] }],
  },

  // ---------- PARADOS, BALÕES E BANDEIRAS (Regras 18, 26–28 e CIS) ----------
  {
    id: "parado-pesca",
    you: "A",
    topic: "prioridades",
    rule: "Regras 18 e 26",
    ask: "who",
    prompt:
      "O navio B está parado, mostra dois cones unidos pelos vértices (bicónico) e tem os aparelhos de pesca estendidos fora do bordo. Clica na embarcação que se deve afastar.",
    vessels: [
      { id: "A", kind: "motor", x: 170, y: 240, heading: 90 },
      { id: "B", kind: "pesca", x: 410, y: 190, heading: 0, stopped: true, shape: "bicone" },
    ],
    correct: 0,
    explanation:
      "Dois cones unidos pelos vértices são o balão diurno de uma embarcação engajada na pesca (Regra 26). O navio de propulsão mecânica afasta-se do caminho dela — e deve passar bem afastado também dos aparelhos estendidos.",
    slugs: ["embarcacao-de-pesca-rieam", "baloes", "risco-de-abalroamento"],
    resolution: [{ idx: 0, heading: 140, alts: [180] }],
  },
  {
    id: "parado-fundeado",
    you: "A",
    topic: "prioridades",
    rule: "Regras 18 e 30",
    ask: "who",
    prompt:
      "O navio B está parado e mostra um balão (esfera) à proa: está fundeado. Clica na embarcação que se deve afastar.",
    vessels: [
      { id: "A", kind: "motor", x: 160, y: 250, heading: 90 },
      { id: "B", kind: "motor", x: 420, y: 200, heading: 0, stopped: true, shape: "esfera" },
    ],
    correct: 0,
    explanation:
      "Uma esfera içada à proa indica navio fundeado (Regra 30). Um navio fundeado não pode manobrar — cabe ao navio em movimento manter-se afastado dele.",
    slugs: ["fundeadouro", "risco-de-abalroamento", "guinar"],
    resolution: [{ idx: 0, heading: 130, alts: [170] }],
  },
  {
    id: "parado-mergulho",
    you: "A",
    topic: "prioridades",
    rule: "CIS — bandeira A",
    ask: "do",
    prompt:
      "O navio B está parado e tem a bandeira A do Código Internacional de Sinais hasteada. O que significa e o que deves fazer?",
    vessels: [
      { id: "A", kind: "motor", x: 170, y: 245, heading: 90 },
      { id: "B", kind: "motor", x: 410, y: 190, heading: 0, stopped: true, flagA: true },
    ],
    options: [
      "Há mergulhadores em baixo — afasto-me e passo a boa distância, a velocidade reduzida",
      "É um sinal de regata — mantenho o rumo e a velocidade",
      "Indica perigo de incêndio — aproximo-me para ajudar",
      "Não significa nada para embarcações de recreio",
    ],
    correct: 0,
    explanation:
      "A bandeira A (branca e azul, de cauda de andorinha) significa «tenho mergulhador em baixo; afaste-se e navegue devagar». Passa-se longe, sem ondas nem hélices por perto.",
    slugs: ["codigo-internacional-de-sinais", "risco-de-abalroamento"],
    resolution: [{ idx: 0, heading: 140, alts: [175] }],
  },
  {
    id: "parado-vela-motor",
    you: "A",
    topic: "prioridades",
    rule: "Regras 25 e 18",
    ask: "do",
    prompt:
      "O veleiro B navega com um balão cónico içado, com o vértice para baixo. O que é que isso te diz sobre ele?",
    wind: 270,
    vessels: [
      { id: "A", kind: "vela", x: 165, y: 240, heading: 90, boom: "bb" },
      { id: "B", kind: "vela-motor", x: 400, y: 180, heading: 0, shape: "cone-down" },
    ],
    options: [
      "Navega à vela e a motor em simultâneo — para o R.I.E.A.M. conta como navio de propulsão mecânica",
      "Está engajado na pesca — tenho de me afastar do caminho dele",
      "Está sem governo — não consegue manobrar",
      "Está fundeado — devo passar a boa distância",
    ],
    correct: 0,
    explanation:
      "O balão cónico com o vértice para baixo, içado num veleiro, indica que navega também a propulsão mecânica (Regra 25e). Para efeitos de prioridade é tratado como navio a motor: deve afastar-se das embarcações à vela.",
    slugs: ["embarcacao-a-vela-rieam", "baloes", "navio-rieam"],
  },
];
