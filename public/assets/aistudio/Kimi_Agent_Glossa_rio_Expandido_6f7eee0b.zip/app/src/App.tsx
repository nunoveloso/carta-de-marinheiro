import { Routes, Route } from "react-router";
import Home from "./pages/Home";
import Manual from "./pages/Manual";
import Quiz from "./pages/Quiz";
import RieamGame from "./pages/RieamGame";
import Instructor from "./pages/Instructor";
import Simulator from "./pages/Simulator";
import Study from "./pages/Study";

export default function App() {
  return (
    <Routes>
      <Route path="/" element={<Home />} />
      <Route path="/manual" element={<Manual />} />
      <Route path="/estudo" element={<Study />} />
      <Route path="/quiz" element={<Quiz />} />
      <Route path="/rieam" element={<RieamGame />} />
      <Route path="/instrutor" element={<Instructor />} />
      <Route path="/simulador" element={<Simulator />} />
      <Route path="*" element={<Home />} />
    </Routes>
  );
}
