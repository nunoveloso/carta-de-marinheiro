import type { ReactNode } from "react";

export const C = {
  ink: "#0b3a55",
  inkSoft: "#3d647c",
  paper: "#f7f2e6",
  sea: "#cfdfe8",
  seaLine: "#9dbccb",
  red: "#b3402f",
  green: "#1e7d4f",
  yellow: "#e3b505",
  black: "#20201d",
  white: "#fdfcf7",
  sand: "#d8c9a3",
  grey: "#8a9aa4",
};

export const W = 320;
export const H = 200;

/** Wrapper comum: fundo papel + moldura fina */
export function Frame({ children, sea = true }: { children: ReactNode; sea?: boolean }) {
  return (
    <svg
      viewBox={`0 0 ${W} ${H}`}
      className="h-full w-full bg-[#f7f2e6]"
      role="img"
      aria-hidden="true"
      preserveAspectRatio="xMidYMid meet"
    >
      <rect x={0} y={0} width={W} height={H} fill={C.paper} />
      {sea && <Sea />}
      {children}
      <rect x={0.75} y={0.75} width={W - 1.5} height={H - 1.5} fill="none" stroke={C.ink} strokeWidth={1.5} />
    </svg>
  );
}

/** Faixa de mar com ondas */
export function Sea({ y = 150 }: { y?: number }) {
  const wave = "M0 0 q 8 -5 16 0 t 16 0 t 16 0 t 16 0 t 16 0 t 16 0 t 16 0 t 16 0 t 16 0 t 16 0 t 16 0 t 16 0 t 16 0 t 16 0 t 16 0 t 16 0 t 16 0 t 16 0 t 16 0 t 16 0";
  return (
    <g>
      <rect x={0} y={y} width={W} height={H - y} fill={C.sea} />
      <path d={wave} transform={`translate(0 ${y + 6})`} fill="none" stroke={C.seaLine} strokeWidth={1.4} />
      <path d={wave} transform={`translate(-14 ${y + 18})`} fill="none" stroke={C.seaLine} strokeWidth={1.4} />
      <path d={wave} transform={`translate(6 ${y + 30})`} fill="none" stroke={C.seaLine} strokeWidth={1.4} />
    </g>
  );
}

/** Barco a motor visto de cima (proa para cima) */
export function BoatTop({ x = 160, y = 100, scale = 1, rotate = 0, fill = C.ink }: {
  x?: number; y?: number; scale?: number; rotate?: number; fill?: string;
}) {
  return (
    <g transform={`translate(${x} ${y}) rotate(${rotate}) scale(${scale})`}>
      {/* casco: proa bicuda em cima, pôpa recta (painel) em baixo */}
      <path
        d="M0 -34 C 9 -22 11 -8 11 6 L 11 30 L -11 30 L -11 6 C -11 -8 -9 -22 0 -34 Z"
        fill={fill}
      />
      <path d="M-7 6 h14 M-7 14 h14" stroke={C.paper} strokeWidth={2} fill="none" />
      <rect x={-5} y={-16} width={10} height={12} rx={2} fill={C.paper} opacity={0.85} />
    </g>
  );
}

/** Veleiro visto de cima */
export function SailboatTop({ x = 160, y = 100, scale = 1, rotate = 0 }: {
  x?: number; y?: number; scale?: number; rotate?: number;
}) {
  return (
    <g transform={`translate(${x} ${y}) rotate(${rotate}) scale(${scale})`}>
      <path
        d="M0 -38 C 8 -24 10 -8 10 8 L 10 30 L -10 30 L -10 8 C -10 -8 -8 -24 0 -38 Z"
        fill={C.ink}
      />
      <line x1={0} y1={-26} x2={0} y2={26} stroke={C.paper} strokeWidth={2.4} />
      <line x1={-8} y1={14} x2={8} y2={14} stroke={C.paper} strokeWidth={2.4} />
    </g>
  );
}

/** Barco a motor de perfil */
export function BoatSide({ x = 160, y = 148, scale = 1, flip = false, fill = C.ink }: {
  x?: number; y?: number; scale?: number; flip?: boolean; fill?: string;
}) {
  return (
    <g transform={`translate(${x} ${y}) scale(${flip ? -scale : scale} ${scale})`}>
      {/* casco: proa bicuda à direita, pôpa recta (painel) à esquerda */}
      <path d="M-46 -14 L 28 -14 L 46 -1 L 46 2 L -46 2 Z" fill={fill} />
      <rect x={-16} y={-26} width={24} height={12} rx={2} fill={fill} />
      <rect x={-12} y={-23} width={8} height={6} fill={C.paper} opacity={0.9} />
    </g>
  );
}

/** Veleiro de perfil */
export function SailboatSide({ x = 160, y = 148, scale = 1, flip = false }: {
  x?: number; y?: number; scale?: number; flip?: boolean;
}) {
  return (
    <g transform={`translate(${x} ${y}) scale(${flip ? -scale : scale} ${scale})`}>
      <path d="M-40 -12 L 26 -12 L 40 -1 L 40 2 L -40 2 Z" fill={C.ink} />
      <line x1={-2} y1={-12} x2={-2} y2={-64} stroke={C.ink} strokeWidth={3} />
      <path d="M0 -62 L 0 -14 L 26 -14 Z" fill={C.white} stroke={C.ink} strokeWidth={1.6} />
      <path d="M-6 -56 L -6 -14 L -26 -14 Z" fill={C.white} stroke={C.ink} strokeWidth={1.6} />
    </g>
  );
}

/** Etiqueta mono maiúscula */
export function Label({ x, y, children, anchor = "middle", size = 10, color = C.ink, weight = 600 }: {
  x: number; y: number; children: ReactNode; anchor?: "start" | "middle" | "end";
  size?: number; color?: string; weight?: number;
}) {
  return (
    <text
      x={x}
      y={y}
      textAnchor={anchor}
      fontSize={size}
      fontWeight={weight}
      fill={color}
      style={{ fontFamily: "'IBM Plex Mono', monospace", textTransform: "uppercase", letterSpacing: "0.06em" }}
    >
      {children}
    </text>
  );
}

/** Seta de movimento/rumo */
export function Arrow({ x1, y1, x2, y2, color = C.red, dashed = false, width = 2 }: {
  x1: number; y1: number; x2: number; y2: number; color?: string; dashed?: boolean; width?: number;
}) {
  const angle = Math.atan2(y2 - y1, x2 - x1);
  const hx = x2 - 7 * Math.cos(angle);
  const hy = y2 - 7 * Math.sin(angle);
  const a1 = angle + Math.PI * 0.82;
  const a2 = angle - Math.PI * 0.82;
  return (
    <g>
      <line x1={x1} y1={y1} x2={hx} y2={hy} stroke={color} strokeWidth={width} strokeDasharray={dashed ? "5 4" : undefined} />
      <path
        d={`M${x2} ${y2} L ${hx + 6 * Math.cos(a1)} ${hy + 6 * Math.sin(a1)} L ${hx + 6 * Math.cos(a2)} ${hy + 6 * Math.sin(a2)} Z`}
        fill={color}
      />
    </g>
  );
}

/** Seta curva (rotação) */
export function CurveArrow({ cx, cy, r, from, to, color = C.red, width = 2 }: {
  cx: number; cy: number; r: number; from: number; to: number; color?: string; width?: number;
}) {
  const p = (a: number) => [cx + r * Math.cos(a), cy + r * Math.sin(a)];
  const [x1, y1] = p(from);
  const [x2, y2] = p(to);
  const large = Math.abs(to - from) > Math.PI ? 1 : 0;
  const sweep = to > from ? 1 : 0;
  const headAngle = Math.atan2(y2 - (cy + r * Math.sin(to - 0.001)), x2 - (cx + r * Math.cos(to - 0.001)));
  return (
    <g>
      <path d={`M${x1} ${y1} A ${r} ${r} 0 ${large} ${sweep} ${x2} ${y2}`} fill="none" stroke={color} strokeWidth={width} />
      <path
        d={`M${x2} ${y2} l ${7 * Math.cos(headAngle + 2.5)} ${7 * Math.sin(headAngle + 2.5)} l ${7 * Math.cos(headAngle - 2.5 + Math.PI)} ${7 * Math.sin(headAngle - 2.5 + Math.PI)} Z`}
        fill={color}
      />
    </g>
  );
}

/** Seta de vento (com barbelas) */
export function WindArrow({ x, y, angle = 0, label, color = C.inkSoft }: {
  x: number; y: number; angle?: number; label?: string; color?: string;
}) {
  const rad = (angle * Math.PI) / 180;
  const x2 = x + 46 * Math.cos(rad);
  const y2 = y + 46 * Math.sin(rad);
  return (
    <g>
      <Arrow x1={x} y1={y} x2={x2} y2={y2} color={color} width={2.2} />
      {label && <Label x={(x + x2) / 2} y={Math.min(y, y2) - 8} color={color}>{label}</Label>}
    </g>
  );
}

/** Pessoa simples */
export function Person({ x, y, scale = 1, color = C.ink, lying = false }: {
  x: number; y: number; scale?: number; color?: string; lying?: boolean;
}) {
  return (
    <g transform={`translate(${x} ${y}) scale(${scale}) ${lying ? "rotate(90)" : ""}`}>
      <circle cx={0} cy={-14} r={5} fill={color} />
      <path d="M0 -8 L 0 8 M0 -4 L -7 3 M0 -4 L 7 3 M0 8 L -5 20 M0 8 L 5 20" stroke={color} strokeWidth={2.6} fill="none" strokeLinecap="round" />
    </g>
  );
}

/** Círculo de sol */
export function Sun({ x, y, r = 14, color = C.yellow }: { x: number; y: number; r?: number; color?: string }) {
  const rays = [];
  for (let i = 0; i < 8; i++) {
    const a = (i * Math.PI) / 4;
    rays.push(
      <line
        key={i}
        x1={x + (r + 4) * Math.cos(a)}
        y1={y + (r + 4) * Math.sin(a)}
        x2={x + (r + 11) * Math.cos(a)}
        y2={y + (r + 11) * Math.sin(a)}
        stroke={color}
        strokeWidth={2.4}
      />,
    );
  }
  return (
    <g>
      <circle cx={x} cy={y} r={r} fill={color} />
      {rays}
    </g>
  );
}

/** Lua (crescente) */
export function Moon({ x, y, r = 12, phase = "full" }: { x: number; y: number; r?: number; phase?: "full" | "new" | "half" }) {
  if (phase === "new")
    return <circle cx={x} cy={y} r={r} fill={C.black} stroke={C.ink} strokeWidth={1} />;
  if (phase === "half")
    return (
      <g>
        <circle cx={x} cy={y} r={r} fill={C.white} stroke={C.ink} strokeWidth={1.4} />
        <path d={`M${x} ${y - r} A ${r} ${r} 0 0 1 ${x} ${y + r} Z`} fill={C.black} />
      </g>
    );
  return <circle cx={x} cy={y} r={r} fill={C.white} stroke={C.ink} strokeWidth={1.4} />;
}
