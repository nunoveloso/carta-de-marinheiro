import { Arrow, C, Frame, Label, W } from "./shared";

/* ══════════════════════ CASCO DE PERFIL — peças em destaque ══════════════════════ */

const DECK = "M54 116 Q 150 110 246 98";
// casco de perfil: proa bicuda à direita, pôpa recta (painel de popa vertical) à esquerda
const HULL = `${DECK} Q 262 122 240 164 L 54 164 Z`;

function HullBase({ children }: { children?: React.ReactNode }) {
  return (
    <g>
      <path d={HULL} fill={C.ink} opacity={0.1} />
      <path d={HULL} fill="none" stroke={C.ink} strokeWidth={2} />
      {children}
    </g>
  );
}

function Ribs({ color = C.inkSoft, width = 1.6 }: { color?: string; width?: number }) {
  const xs = [105, 135, 165, 195, 222];
  return (
    <g>
      {xs.map((x) => (
        <path key={x} d={`M${x} 112 C ${x + 2} 132 ${x + 2} 148 ${x} 162`} fill="none" stroke={color} strokeWidth={width} />
      ))}
    </g>
  );
}

function Rail({ color = C.inkSoft, width = 2 }: { color?: string; width?: number }) {
  const posts = [78, 110, 142, 174, 206, 238];
  return (
    <g>
      {posts.map((x) => {
        const y = 116 - (x - 78) * 0.062 - 10;
        return <line key={x} x1={x} y1={y + 10} x2={x} y2={y} stroke={color} strokeWidth={width} />;
      })}
      <path d="M78 106 Q 158 100 238 88" fill="none" stroke={color} strokeWidth={width} />
    </g>
  );
}

function Rudder({ color = C.ink, width = 2.4 }: { color?: string; width?: number }) {
  return (
    <g stroke={color} strokeWidth={width} fill={color}>
      {/* madre — eixo vertical à ré do painel */}
      <line x1={48} y1={122} x2={48} y2={162} fill="none" />
      {/* porta (pá) */}
      <path d="M44 148 L 56 148 L 56 172 L 44 172 Z" stroke="none" />
      {/* cachola + cana */}
      <rect x={42} y={112} width={11} height={9} stroke="none" />
      <line x1={48} y1={116} x2={86} y2={106} fill="none" />
    </g>
  );
}

const HULL_PARTS: Record<string, { label: string; lx: number; ly: number; tx: number; ty: number }> = {
  "roda-de-proa": { label: "roda de proa", lx: 258, ly: 60, tx: 250, ty: 104 },
  cadaste: { label: "cadaste", lx: 60, ly: 66, tx: 54, ty: 150 },
  balizas: { label: "balizas (cavernas)", lx: 160, ly: 52, tx: 165, ty: 108 },
  painel: { label: "painel de popa", lx: 46, ly: 92, tx: 54, ty: 124 },
  "linha-de-agua": { label: "linha de água", lx: 250, ly: 146, tx: 236, ty: 149 },
  conves: { label: "convés", lx: 160, ly: 84, tx: 160, ty: 106 },
  enora: { label: "enora", lx: 196, ly: 60, tx: 152, ty: 104 },
  carlinga: { label: "carlinga", lx: 190, ly: 190, tx: 150, ty: 160 },
  escovem: { label: "escovém", lx: 262, ly: 84, tx: 216, ty: 106 },
  verdugo: { label: "verdugo", lx: 92, ly: 88, tx: 92, ty: 108 },
  robaletes: { label: "robaletes", lx: 250, ly: 190, tx: 224, ty: 159 },
  balaustres: { label: "balaustres", lx: 80, ly: 64, tx: 78, ty: 100 },
  leme: { label: "leme: madre · porta · cachola", lx: 118, ly: 66, tx: 66, ty: 116 },
};

export function HullPart({ part }: { part: string }) {
  const meta = HULL_PARTS[part] ?? HULL_PARTS["conves"];
  const hl = C.red;
  return (
    <Frame>
      <HullBase>
        <Ribs />
        <Rail />
        <Rudder />
        {/* quilha */}
        <rect x={54} y={161} width={186} height={6} fill={C.ink} />
        {/* escovém base */}
        <rect x={208} y={101} width={14} height={8} rx={3} fill={C.paper} stroke={C.ink} strokeWidth={1.4} />
        {/* enora base */}
        <ellipse cx={150} cy={109} rx={9} ry={3} fill={C.paper} stroke={C.ink} strokeWidth={1.4} />
      </HullBase>
      {/* destaques por peça */}
      {part === "roda-de-proa" && <path d="M246 98 Q 262 122 240 164" fill="none" stroke={hl} strokeWidth={4.4} />}
      {part === "cadaste" && <line x1={54} y1={132} x2={54} y2={164} stroke={hl} strokeWidth={4.4} />}
      {part === "painel" && <rect x={50} y={116} width={8} height={48} fill={hl} />}
      {part === "balizas" && <Ribs color={hl} width={3} />}
      {part === "linha-de-agua" && <line x1={56} y1={150} x2={252} y2={150} stroke={hl} strokeWidth={3.6} />}
      {part === "conves" && <path d={DECK} fill="none" stroke={hl} strokeWidth={4.4} />}
      {part === "enora" && (
        <g>
          <ellipse cx={150} cy={109} rx={10} ry={4} fill="none" stroke={hl} strokeWidth={3} />
          <line x1={150} y1={109} x2={150} y2={68} stroke={hl} strokeWidth={3.4} />
        </g>
      )}
      {part === "carlinga" && <rect x={142} y={155} width={16} height={9} fill={hl} />}
      {part === "escovem" && <rect x={208} y={101} width={14} height={8} rx={3} fill="none" stroke={hl} strokeWidth={3} />}
      {part === "verdugo" && <path d="M54 112 Q 150 106 246 94" fill="none" stroke={hl} strokeWidth={4.4} />}
      {part === "robaletes" && (
        <g stroke={hl} strokeWidth={3.4}>
          <line x1={106} y1={156} x2={238} y2={156} />
          <line x1={100} y1={161} x2={240} y2={161} />
        </g>
      )}
      {part === "balaustres" && <Rail color={hl} width={3.2} />}
      {part === "leme" && <Rudder color={hl} width={3} />}
      {/* etiqueta + linha de chamada */}
      <line x1={meta.lx} y1={meta.ly + 4} x2={meta.tx} y2={meta.ty} stroke={C.inkSoft} strokeWidth={1.1} />
      <Label x={meta.lx} y={meta.ly} color={hl} anchor={meta.lx > 230 ? "end" : meta.lx < 90 ? "start" : "middle"}>
        {meta.label}
      </Label>
      {part === "leme" && (
        <g>
          <Label x={38} y={110} size={8} color={C.inkSoft} anchor="end">cachola</Label>
          <Label x={38} y={146} size={8} color={C.inkSoft} anchor="end">madre</Label>
          <Label x={64} y={182} size={8} color={C.inkSoft} anchor="start">porta</Label>
        </g>
      )}
    </Frame>
  );
}

/* ══════════════════════ CASCO VISTO DE CIMA ══════════════════════ */

// casco visto de cima: proa bicuda em cima, pôpa recta (painel) em baixo
const TOP_HULL = "M160 30 C 190 60 196 104 196 142 L 196 162 L 124 162 L 124 142 C 124 104 130 60 160 30 Z";

export function HullTopPart({ part }: { part: string }) {
  return (
    <Frame sea={false}>
      <rect x={0} y={118} width={W} height={82} fill={C.sea} opacity={0.55} />
      <path d={TOP_HULL} fill={C.ink} opacity={0.12} />
      <path d={TOP_HULL} fill="none" stroke={C.ink} strokeWidth={2.2} />
      {part === "meia-nau" ? (
        <g>
          <line x1={160} y1={24} x2={160} y2={176} stroke={C.red} strokeWidth={2.6} strokeDasharray="7 5" />
          <Label x={160} y={194} color={C.red}>meia nau — divide os bordos</Label>
          <Label x={82} y={106} color={C.inkSoft}>bombordo</Label>
          <Label x={238} y={106} color={C.inkSoft}>estibordo</Label>
        </g>
      ) : (
        <g>
          <line x1={122} y1={112} x2={198} y2={112} stroke={C.red} strokeWidth={2.6} strokeDasharray="7 5" />
          <Label x={160} y={132} color={C.red}>meio navio</Label>
          <Label x={160} y={52} size={9} color={C.inkSoft}>proa</Label>
          <Label x={160} y={188} size={9} color={C.inkSoft}>popa</Label>
        </g>
      )}
    </Frame>
  );
}

/* ══════════════════════ DIMENSÕES ══════════════════════ */

function DimArrow({ x1, y1, x2, y2, color = C.red }: { x1: number; y1: number; x2: number; y2: number; color?: string }) {
  return (
    <g>
      <line x1={x1} y1={y1} x2={x2} y2={y2} stroke={color} strokeWidth={2.2} />
      <Arrow x1={(x1 + x2) / 2 + (x2 - x1) * 0.06} y1={(y1 + y2) / 2 + (y2 - y1) * 0.06} x2={x2} y2={y2} color={color} />
      <Arrow x1={(x1 + x2) / 2 - (x2 - x1) * 0.06} y1={(y1 + y2) / 2 - (y2 - y1) * 0.06} x2={x1} y2={y1} color={color} />
    </g>
  );
}

export function Dims({ dim }: { dim: string }) {
  if (dim === "comprimento" || dim === "boca") {
    return (
      <Frame sea={false}>
        <rect x={0} y={118} width={W} height={82} fill={C.sea} opacity={0.55} />
        <path d={TOP_HULL} fill={C.ink} opacity={0.12} />
        <path d={TOP_HULL} fill="none" stroke={C.ink} strokeWidth={2.2} />
        {dim === "comprimento" ? (
          <g>
            <DimArrow x1={160} y1={30} x2={160} y2={170} />
            <Label x={176} y={102} color={C.red} anchor="start">comprimento</Label>
            <Label x={160} y={22} size={8.5} color={C.inkSoft}>roda de proa</Label>
            <Label x={160} y={186} size={8.5} color={C.inkSoft}>cadaste</Label>
          </g>
        ) : (
          <g>
            <DimArrow x1={124} y1={120} x2={196} y2={120} />
            <Label x={160} y={104} color={C.red}>boca</Label>
            <Label x={160} y={186} size={8.5} color={C.inkSoft}>largura máxima</Label>
          </g>
        )}
      </Frame>
    );
  }
  // pontal / borda livre — perfil
  return (
    <Frame>
      <HullBase />
      <rect x={54} y={161} width={186} height={6} fill={C.ink} />
      {dim === "pontal" ? (
        <g>
          <DimArrow x1={270} y1={112} x2={270} y2={166} />
          <line x1={252} y1={112} x2={282} y2={112} stroke={C.inkSoft} strokeWidth={1.2} strokeDasharray="4 3" />
          <line x1={244} y1={166} x2={282} y2={166} stroke={C.inkSoft} strokeWidth={1.2} strokeDasharray="4 3" />
          <Label x={266} y={140} color={C.red} anchor="end">pontal</Label>
          <Label x={160} y={190} size={8.5} color={C.inkSoft}>da quilha à borda</Label>
        </g>
      ) : (
        <g>
          <DimArrow x1={270} y1={112} x2={270} y2={150} color={C.red} />
          <DimArrow x1={270} y1={150} x2={270} y2={166} color={C.grey} />
          <line x1={252} y1={112} x2={282} y2={112} stroke={C.inkSoft} strokeWidth={1.2} strokeDasharray="4 3" />
          <line x1={244} y1={150} x2={282} y2={150} stroke={C.inkSoft} strokeWidth={1.2} strokeDasharray="4 3" />
          <Label x={264} y={128} color={C.red} anchor="end" size={9}>borda livre</Label>
          <Label x={264} y={163} color={C.grey} anchor="end" size={9}>calado</Label>
          <Label x={120} y={190} size={8.5} color={C.inkSoft}>linha de água → borda</Label>
        </g>
      )}
    </Frame>
  );
}

/* ══════════════════════ ÂNCORA — partes ══════════════════════ */

function AnchorShape({ highlight }: { highlight?: string }) {
  const base = C.ink;
  const hl = C.red;
  const col = (p: string) => (highlight === p ? hl : base);
  return (
    <g transform="translate(118 102)" fill={base} stroke={base}>
      {/* anete */}
      <circle cx={0} cy={-64} r={9} fill="none" stroke={col("anete")} strokeWidth={highlight === "anete" ? 5 : 3} />
      {highlight === "anete" && <circle cx={0} cy={-64} r={9} fill="none" stroke={hl} strokeWidth={5} />}
      {/* haste */}
      <rect x={-3} y={-58} width={6} height={96} fill={col("haste")} stroke="none" />
      {/* cepo */}
      <rect x={-30} y={-50} width={60} height={7} rx={3} fill={col("cepo")} stroke="none" />
      {/* braços e unhas */}
      <path d="M0 30 C -34 30 -44 8 -42 -12 L -30 -4 C -32 10 -26 20 -8 22 Z" fill={col("bracos")} stroke="none" />
      <path d="M0 30 C 34 30 44 8 42 -12 L 30 -4 C 32 10 26 20 8 22 Z" fill={col("bracos")} stroke="none" />
      {highlight === "unha" && (
        <g fill={hl}>
          <path d="M-42 -12 L -30 -4 C -31 2 -33 6 -36 8 Z" />
          <path d="M42 -12 L 30 -4 C 31 2 33 6 36 8 Z" />
        </g>
      )}
      {highlight === "cruz" && <circle cx={0} cy={26} r={10} fill="none" stroke={hl} strokeWidth={4} />}
    </g>
  );
}

const ANCHOR_LABELS: Record<string, [string, number, number, number, number]> = {
  anete: ["anete — olhal da amarra", 186, 40, 130, 38],
  haste: ["haste — corpo do ferro", 186, 84, 126, 84],
  cruz: ["cruz — união haste/braços", 186, 130, 130, 128],
  bracos: ["braços", 186, 112, 152, 118],
  unha: ["unhas — prendem ao fundo", 186, 130, 154, 92],
  cepo: ["cepo — obriga a unhar", 186, 56, 152, 54],
};

export function AnchorPart({ part }: { part: string }) {
  if (part === "fundeadouro") {
    return (
      <Frame>
        <rect x={0} y={164} width={W} height={36} fill={C.sand} />
        <path d="M40 148 C 90 156 130 162 168 166" fill="none" stroke={C.ink} strokeWidth={3} strokeDasharray="7 5" />
        <g transform="translate(176 166) scale(0.55)" fill={C.ink}>
          <rect x={-4} y={-30} width={8} height={42} />
          <path d="M0 6 C -26 6 -34 -10 -32 -22 L -20 -14 C -22 -4 -16 0 -4 2 Z" />
          <path d="M0 6 C 26 6 34 -10 32 -22 L 20 -14 C 22 -4 16 0 4 2 Z" />
        </g>
        {/* abrigo */}
        <path d="M232 150 q 10 -26 4 -44 M244 150 q 14 -20 8 -40" stroke={C.green} strokeWidth={3} fill="none" />
        <Label x={120} y={120} size={9} color={C.inkSoft}>abrigado · profundidade adequada</Label>
        <Label x={120} y={136} size={9} color={C.inkSoft}>fundo de boa tença</Label>
        <Label x={160} y={192} size={9}>fundeadouro</Label>
      </Frame>
    );
  }
  const [text, lx, ly, tx, ty] = ANCHOR_LABELS[part] ?? ANCHOR_LABELS["haste"];
  return (
    <Frame sea={false}>
      <AnchorShape highlight={part} />
      <line x1={lx - 4} y1={ly - 2} x2={tx} y2={ty} stroke={C.inkSoft} strokeWidth={1.1} />
      <Label x={lx} y={ly} anchor="start" size={9} color={C.red}>{text}</Label>
      {/* silhueta das restantes partes para contexto */}
      <g fill={C.inkSoft}>
        <Label x={40} y={40} size={8} color={C.inkSoft} anchor="start">anete</Label>
        <Label x={40} y={60} size={8} color={C.inkSoft} anchor="start">cepo</Label>
        <Label x={40} y={80} size={8} color={C.inkSoft} anchor="start">haste</Label>
        <Label x={40} y={100} size={8} color={C.inkSoft} anchor="start">cruz</Label>
        <Label x={40} y={120} size={8} color={C.inkSoft} anchor="start">braços</Label>
        <Label x={40} y={140} size={8} color={C.inkSoft} anchor="start">unhas</Label>
      </g>
    </Frame>
  );
}

/* ══════════════════════ EMBARCAÇÕES MIÚDAS ══════════════════════ */

function MiudaHull({ type, x = 160, y = 120 }: { type: string; x?: number; y?: number }) {
  const g = `translate(${x} ${y})`;
  if (type === "baleeira")
    return (
      <g transform={g}>
        <path d="M-64 -18 C -58 -2 -40 8 0 8 C 40 8 58 -2 64 -18 L 52 -16 C 44 -6 26 0 0 0 C -26 0 -44 -6 -52 -16 Z" fill={C.ink} />
        <path d="M-64 -18 Q -66 -28 -58 -30 L -52 -16 Z M64 -18 Q 66 -28 58 -30 L 52 -16 Z" fill={C.ink} />
      </g>
    );
  if (type === "chata")
    return (
      <g transform={g}>
        <path d="M-58 -16 L 44 -16 L 58 -4 L 52 8 L -52 8 Z" fill={C.ink} />
        <rect x={-58} y={-22} width={10} height={24} fill={C.ink} />
      </g>
    );
  if (type === "bote")
    return (
      <g transform={g}>
        <path d="M-56 -18 L 40 -18 Q 58 -16 56 -2 Q 54 8 44 10 L -48 10 Q -56 4 -56 -18 Z" fill={C.ink} />
        <rect x={-62} y={-24} width={8} height={30} fill={C.ink} />
      </g>
    );
  // salva-vidas: baleeira + caixas de ar + cabo de socorros
  return (
    <g transform={g}>
      <path d="M-64 -18 C -58 -2 -40 8 0 8 C 40 8 58 -2 64 -18 L 52 -16 C 44 -6 26 0 0 0 C -26 0 -44 -6 -52 -16 Z" fill={C.ink} />
      <rect x={-56} y={-22} width={18} height={8} rx={2} fill={C.red} />
      <rect x={38} y={-22} width={18} height={8} rx={2} fill={C.red} />
      <rect x={-14} y={-14} width={28} height={6} rx={2} fill={C.red} />
      <path d="M-62 -26 Q 0 -38 62 -26" fill="none" stroke={C.yellow} strokeWidth={2.4} strokeDasharray="6 4" />
    </g>
  );
}

const MIUDA_INFO: Record<string, [string, string]> = {
  baleeira: ["baleeira", "proa e popa elevadas · sem painel de popa"],
  chata: ["chata", "fundo chato · painel de popa"],
  bote: ["bote", "painel de popa + roda de proa · boca larga"],
  salvavidas: ["salva-vidas", "caixas-de-ar + cabo de socorros a náufragos"],
};

export function Miuda({ type }: { type: string }) {
  if (type === "overview") {
    const types = ["baleeira", "chata", "bote"];
    return (
      <Frame>
        {types.map((t, i) => (
          <g key={t} transform={`translate(0 ${i * 0})`}>
            <g transform={`translate(${62 + i * 98} 108) scale(0.72)`}>
              <MiudaHull type={t} x={0} y={0} />
            </g>
            <Label x={62 + i * 98} y={152} size={9}>{t}</Label>
          </g>
        ))}
        <Label x={160} y={56} color={C.inkSoft}>embarcações miúdas</Label>
        <Label x={160} y={176} size={8.5} color={C.inkSoft}>auxiliares · transporte de e para terra</Label>
      </Frame>
    );
  }
  const [name, note] = MIUDA_INFO[type] ?? MIUDA_INFO["bote"];
  return (
    <Frame>
      <MiudaHull type={type === "salvavidas" ? "salvavidas" : type} />
      {type === "bote" && <Label x={160} y={66} size={8.5} color={C.inkSoft}>boca grande vs. comprimento</Label>}
      {type === "salvavidas" && <Label x={160} y={62} size={8.5} color={C.inkSoft}>caixas-de-ar à proa, à ré e sob os bancos</Label>}
      {type === "chata" && <Label x={160} y={66} size={8.5} color={C.inkSoft}>típica auxiliar de pesca</Label>}
      <Label x={160} y={168}>{name}</Label>
      <Label x={160} y={186} size={8.5} color={C.inkSoft}>{note}</Label>
    </Frame>
  );
}

/* ══════════════════════ PALAMENTA ══════════════════════ */

function PalamentaItem({ type, x, y, color = C.ink }: { type: string; x: number; y: number; color?: string }) {
  return (
    <g transform={`translate(${x} ${y})`} stroke={color} fill={color}>
      {type === "ancorete" && (
        <g>
          <circle cx={0} cy={-14} r={4} fill="none" strokeWidth={2.4} />
          <rect x={-1.6} y={-10} width={3.2} height={26} stroke="none" />
          <path d="M0 14 C -12 14 -16 6 -15 0 L -10 3 C -11 8 -8 10 -2 11 Z M0 14 C 12 14 16 6 15 0 L 10 3 C 11 8 8 10 2 11 Z" stroke="none" />
        </g>
      )}
      {type === "vertedouro" && (
        <g>
          <path d="M-12 -6 h24 v10 a12 8 0 0 1 -24 0 Z" stroke="none" />
          <rect x={-2} y={-16} width={4} height={12} stroke="none" />
        </g>
      )}
      {type === "croque" && (
        <g fill="none" strokeWidth={3}>
          <line x1={-16} y1={14} x2={12} y2={-14} />
          <path d="M12 -14 q 8 -2 6 6" />
        </g>
      )}
      {type === "remo" && (
        <g>
          <rect x={-20} y={-1.6} width={30} height={3.2} stroke="none" />
          <path d="M10 -5 L 24 -5 L 26 0 L 24 5 L 10 5 Z" stroke="none" />
          <circle cx={-20} cy={0} r={3.4} stroke="none" />
        </g>
      )}
      {type === "pagaia" && (
        <g>
          <rect x={-18} y={-1.4} width={36} height={2.8} stroke="none" />
          <path d="M-18 -6 L -30 -6 L -32 0 L -30 6 L -18 6 Z M18 -6 L 30 -6 L 32 0 L 30 6 L 18 6 Z" stroke="none" />
        </g>
      )}
      {type === "forqueta" && (
        <g fill="none" strokeWidth={3}>
          <path d="M-6 12 v-16 M6 12 v-16 M-6 -4 q 0 -8 6 -8 q 6 0 6 8" />
          <line x1={-14} y1={12} x2={14} y2={12} />
        </g>
      )}
    </g>
  );
}

export function Palamenta({ type }: { type: string }) {
  if (type === "overview") {
    const items: [string, string][] = [
      ["ancorete", "ancorete"], ["vertedouro", "vertedouro"], ["croque", "croque"],
      ["remo", "remo"], ["pagaia", "pagaia"], ["forqueta", "forqueta"],
    ];
    return (
      <Frame sea={false}>
        <Label x={160} y={34} color={C.inkSoft}>palamenta — apetrechos e peças soltas</Label>
        {items.map(([t, label], i) => (
          <g key={t}>
            <PalamentaItem type={t} x={70 + (i % 3) * 90} y={76 + Math.floor(i / 3) * 62} />
            <Label x={70 + (i % 3) * 90} y={112 + Math.floor(i / 3) * 62} size={8.5}>{label}</Label>
          </g>
        ))}
      </Frame>
    );
  }
  const labels: Record<string, [string, string]> = {
    ancorete: ["ancorete", "pequeno ferro de fundear"],
    vertedouro: ["vertedouro", "esgota a água a bordo"],
    croque: ["croque", "apanha cabos e bóias · atracar/desatracar"],
    remo: ["remo", "punho · corpo · pá"],
    pagaia: ["pagaia", "remo de duas pás"],
    forqueta: ["forqueta (tolete)", "apoio e fulcro do remo"],
  };
  const [name, note] = labels[type] ?? labels["remo"];
  return (
    <Frame>
      <g transform="translate(160 104) scale(2.1)">
        <PalamentaItem type={type} x={0} y={0} />
      </g>
      {type === "forqueta" && (
        <g transform="translate(160 104) rotate(-18)">
          <rect x={-64} y={-2.4} width={96} height={4.8} fill={C.inkSoft} />
          <path d="M32 -8 L 64 -8 L 68 0 L 64 8 L 32 8 Z" fill={C.inkSoft} />
        </g>
      )}
      <Label x={160} y={164}>{name}</Label>
      <Label x={160} y={182} size={8.5} color={C.inkSoft}>{note}</Label>
    </Frame>
  );
}

/* ══════════════════════ QUALIDADES NÁUTICAS ══════════════════════ */

function SmallBoat({ x, y, rotate = 0, color = C.ink }: { x: number; y: number; rotate?: number; color?: string }) {
  return (
    <g transform={`translate(${x} ${y}) rotate(${rotate})`}>
      <path d="M-36 -11 L 24 -11 L 36 -1 L 36 2 L -36 2 Z" fill={color} />
      <rect x={-12} y={-21} width={18} height={10} rx={2} fill={color} />
    </g>
  );
}

export function Quality({ type }: { type: string }) {
  const titles: Record<string, [string, string]> = {
    habitabilidade: ["habitabilidade", "alojar quem embarca com condições"],
    manobrabilidade: ["manobrabilidade", "capacidade de evoluir"],
    navegabilidade: ["navegabilidade", "enfrentar o mar"],
    estabilidade: ["estabilidade", "voltar à posição de equilíbrio"],
    flutuabilidade: ["flutuabilidade", "manter-se à superfície"],
    "poder-giratorio": ["poder giratório", "descrever curvas de raios distintos"],
    solidez: ["solidez", "resistir à vaga e ao vento"],
    estanquicidade: ["estanquicidade", "não embarcar água"],
  };
  const [title, note] = titles[type] ?? titles["estabilidade"];
  return (
    <Frame>
      {type === "habitabilidade" && (
        <g>
          <SmallBoat x={160} y={140} />
          <rect x={-12 + 160} y={-21 + 140} width={5} height={4} fill={C.paper} />
          <rect x={-4 + 160} y={-21 + 140} width={5} height={4} fill={C.paper} />
          <rect x={-60 + 160} y={-10 + 140} width={18} height={8} rx={3} fill={C.inkSoft} />
          <Label x={106} y={128} size={8} color={C.inkSoft}>beliche</Label>
        </g>
      )}
      {type === "manobrabilidade" && (
        <g>
          <SmallBoat x={150} y={132} />
          <path d="M190 140 A 44 44 0 0 1 130 96" fill="none" stroke={C.red} strokeWidth={2.4} />
          <Arrow x1={131.8} y1={100.6} x2={128} y2={92} color={C.red} />
          <line x1={118} y1={136} x2={104} y2={150} stroke={C.inkSoft} strokeWidth={2.4} />
          <Label x={216} y={120} size={8} color={C.inkSoft}>leme + hélice</Label>
        </g>
      )}
      {type === "navegabilidade" && (
        <g>
          <path d="M20 150 q 18 -22 36 0 q 18 -22 36 0" fill="none" stroke={C.seaLine} strokeWidth={3} />
          <path d="M200 150 q 18 -22 36 0 q 18 -22 36 0" fill="none" stroke={C.seaLine} strokeWidth={3} />
          <SmallBoat x={160} y={128} rotate={-9} />
        </g>
      )}
      {type === "estabilidade" && (
        <g>
          <SmallBoat x={160} y={130} rotate={-16} />
          <path d="M196 96 A 40 40 0 0 0 160 88" fill="none" stroke={C.green} strokeWidth={2.4} />
          <Arrow x1={165.5} y1={88.2} x2={158} y2={90} color={C.green} />
          <Arrow x1={160} y1={118} x2={160} y2={148} color={C.inkSoft} />
          <Label x={228} y={80} size={8} color={C.green}>endireita</Label>
        </g>
      )}
      {type === "flutuabilidade" && (
        <g>
          <SmallBoat x={160} y={136} />
          <Arrow x1={138} y1={104} x2={138} y2={122} color={C.red} />
          <Arrow x1={160} y1={104} x2={160} y2={122} color={C.red} />
          <Arrow x1={182} y1={104} x2={182} y2={122} color={C.red} />
          <Arrow x1={160} y1={164} x2={160} y2={146} color={C.green} />
          <Label x={222} y={112} size={8} color={C.red}>carga</Label>
          <Label x={222} y={158} size={8} color={C.green}>impulsão</Label>
        </g>
      )}
      {type === "poder-giratorio" && (
        <g>
          <circle cx={110} cy={120} r={30} fill="none" stroke={C.green} strokeWidth={2.2} strokeDasharray="5 4" />
          <circle cx={230} cy={120} r={52} fill="none" stroke={C.inkSoft} strokeWidth={2.2} strokeDasharray="5 4" />
          <SmallBoat x={110} y={86} rotate={-90} />
          <SmallBoat x={230} y={64} rotate={-90} />
          <Label x={110} y={168} size={8} color={C.green}>raio pequeno</Label>
          <Label x={230} y={186} size={8} color={C.inkSoft}>raio grande</Label>
        </g>
      )}
      {type === "solidez" && (
        <g>
          <SmallBoat x={170} y={132} />
          <path d="M36 128 q 12 -16 24 0 q 12 -16 24 0" fill="none" stroke={C.seaLine} strokeWidth={3} />
          <Arrow x1={92} y1={112} x2={128} y2={122} color={C.inkSoft} />
          <Arrow x1={150} y1={64} x2={160} y2={100} color={C.inkSoft} />
          <Label x={64} y={100} size={8} color={C.inkSoft}>vaga</Label>
          <Label x={132} y={58} size={8} color={C.inkSoft}>vento</Label>
        </g>
      )}
      {type === "estanquicidade" && (
        <g>
          <path d="M96 110 L 224 110 L 208 158 L 112 158 Z" fill={C.paper} stroke={C.ink} strokeWidth={2.6} />
          {[120, 150, 180, 210].map((x) => (
            <path key={x} d={`M${x} 88 q 5 8 0 12 q -5 -4 0 -12`} fill={C.seaLine} />
          ))}
          <line x1={96} y1={110} x2={224} y2={110} stroke={C.red} strokeWidth={3.4} />
          <Label x={160} y={140} size={8.5} color={C.inkSoft}>sem infiltração</Label>
          <Label x={252} y={106} size={8} color={C.red}>casco estanque</Label>
        </g>
      )}
      <Label x={160} y={46}>{title}</Label>
      <Label x={160} y={192} size={8.5} color={C.inkSoft}>{note}</Label>
    </Frame>
  );
}
