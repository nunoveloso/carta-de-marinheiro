import { Arrow, C, Frame, H, Label, Moon, Sun, W } from "./shared";

/* ══════════════════════ BALIZAGEM / SINAIS ══════════════════════ */

function Can({ x, y, color, top = "can" }: { x: number; y: number; color: string; top?: "can" | "cone" }) {
  return (
    <g transform={`translate(${x} ${y})`}>
      <rect x={-9} y={-16} width={18} height={26} fill={color} stroke={C.ink} strokeWidth={1.4} />
      {top === "can" ? (
        <rect x={-7} y={-26} width={14} height={9} fill={color} stroke={C.ink} strokeWidth={1.4} />
      ) : (
        <path d="M-8 -16 L 0 -30 L 8 -16 Z" fill={color} stroke={C.ink} strokeWidth={1.4} />
      )}
      <line x1={0} y1={10} x2={0} y2={16} stroke={C.ink} strokeWidth={2} />
    </g>
  );
}

export function MarksThing({ type }: { type: string }) {
  if (type === "iala") {
    return (
      <Frame>
        {/* dois painéis A / B */}
        <rect x={24} y={42} width={124} height={122} fill={C.white} stroke={C.ink} strokeWidth={1.6} />
        <rect x={172} y={42} width={124} height={122} fill={C.white} stroke={C.ink} strokeWidth={1.6} />
        <Label x={86} y={60} size={10}>Região A</Label>
        <Label x={234} y={60} size={10}>Região B</Label>
        <Can x={56} y={110} color={C.red} top="can" />
        <Can x={118} y={110} color={C.green} top="cone" />
        <Can x={204} y={110} color={C.green} top="can" />
        <Can x={266} y={110} color={C.red} top="cone" />
        <Label x={56} y={150} size={8}>BB</Label>
        <Label x={118} y={150} size={8}>EB</Label>
        <Label x={204} y={150} size={8}>BB</Label>
        <Label x={266} y={150} size={8}>EB</Label>
        <Label x={160} y={184} size={8.5} color={C.inkSoft}>portugal = região a · laterais com cores trocadas na b</Label>
      </Frame>
    );
  }
  if (type === "baliza") {
    return (
      <Frame>
        {/* poste fixo */}
        <line x1={160} y1={60} x2={160} y2={196} stroke={C.ink} strokeWidth={4.4} />
        <path d="M160 60 L 148 84 h 24 Z" fill={C.red} stroke={C.ink} strokeWidth={1.4} />
        <rect x={146} y={88} width={28} height={18} fill={C.yellow} stroke={C.ink} strokeWidth={1.4} />
        <rect x={0} y={172} width={W} height={28} fill={C.sand} />
        <Label x={160} y={44} size={9}>baliza — marca fixa</Label>
        <Label x={226} y={140} size={8.5} color={C.inkSoft}>ao contrário da bóia,</Label>
        <Label x={226} y={156} size={8.5} color={C.inkSoft}>não flutua</Label>
      </Frame>
    );
  }
  // sinais de temporal
  return (
    <Frame sea={false}>
      <line x1={160} y1={24} x2={160} y2={150} stroke={C.ink} strokeWidth={3.4} />
      {/* cone ponta p/ baixo */}
      <g transform="translate(70 66)">
        <path d="M-16 -18 L 0 16 L 16 -18 Z" fill={C.black} />
        <Label x={0} y={44} size={8}>temporal NW</Label>
      </g>
      {/* cone ponta p/ cima */}
      <g transform="translate(160 66)">
        <path d="M-16 16 L 0 -18 L 16 16 Z" fill={C.black} />
        <Label x={0} y={44} size={8}>temporal SW</Label>
      </g>
      {/* dois cones vértices unidos */}
      <g transform="translate(250 66)">
        <path d="M-14 -18 L 0 0 L 14 -18 Z" fill={C.black} />
        <path d="M-14 18 L 0 0 L 14 18 Z" fill={C.black} />
        <Label x={0} y={44} size={8}>temporal N</Label>
      </g>
      <Label x={160} y={176} size={8.5} color={C.inkSoft}>avisos de temporal nos portos de portugal</Label>
    </Frame>
  );
}

/* ══════════════════════ COMUNICAÇÕES ══════════════════════ */

export function RadioThing({ type }: { type: string }) {
  if (type === "navtex") {
    return (
      <Frame sea={false}>
        {/* recetor */}
        <rect x={90} y={70} width={140} height={72} rx={8} fill={C.ink} />
        <rect x={104} y={84} width={86} height={30} rx={3} fill={C.paper} />
        <Label x={147} y={103} size={9} color={C.ink}>518 khz</Label>
        <circle cx={212} cy={96} r={6} fill={C.yellow} />
        <circle cx={212} cy={120} r={6} fill={C.green} />
        {/* mensagem a sair */}
        <g transform="translate(160 44)">
          <path d="M-34 0 q 34 -22 68 0" fill="none" stroke={C.inkSoft} strokeWidth={2.2} />
          <path d="M-24 -10 q 24 -15 48 0" fill="none" stroke={C.inkSoft} strokeWidth={2.2} />
        </g>
        <Label x={160} y={164} size={9}>avisos aos navegantes · 4 em 4 h</Label>
        <Label x={160} y={182} size={8.5} color={C.inkSoft}>parte do gmdss · 490 khz = língua local</Label>
      </Frame>
    );
  }
  // código internacional de sinais
  return (
    <Frame sea={false}>
      {/* bandeira A */}
      <g transform="translate(80 60)">
        <line x1={0} y1={-16} x2={0} y2={52} stroke={C.ink} strokeWidth={2.6} />
        <path d="M0 -16 h 44 v 34 l -12 -8 l -10 8 l -10 -8 Z" fill={C.white} stroke={C.ink} strokeWidth={1.4} />
        <path d="M22 -16 h 22 v 34 l -12 -8 l -10 8 Z" fill="#1d4f91" />
        <Label x={22} y={68} size={10}>A</Label>
        <Label x={22} y={84} size={8} color={C.inkSoft}>mergulhador em baixo</Label>
      </g>
      {/* bandeira B */}
      <g transform="translate(196 60)">
        <line x1={0} y1={-16} x2={0} y2={52} stroke={C.ink} strokeWidth={2.6} />
        <path d="M0 -16 h 44 v 34 l -14 -17 Z" fill={C.red} stroke={C.ink} strokeWidth={1.4} />
        <Label x={22} y={68} size={10}>B</Label>
        <Label x={22} y={84} size={8} color={C.inkSoft}>mercadorias perigosas</Label>
      </g>
      <Label x={160} y={172} size={8.5} color={C.inkSoft}>cada bandeira = letra e/ou mensagem</Label>
    </Frame>
  );
}

/* ══════════════════════ MARÉS — sondas ══════════════════════ */

function TideDepth({ mode }: { mode: string }) {
  // diagrama de coluna de água: fundo, ZH, nível do mar
  const seabed = 176;
  const zh = 150; // zero hidrográfico
  const level = 96; // nível atual
  return (
    <Frame sea={false}>
      <rect x={0} y={level} width={W} height={seabed - level} fill={C.sea} opacity={0.8} />
      <rect x={0} y={seabed} width={W} height={H - seabed} fill={C.sand} />
      {/* linhas de referência */}
      <line x1={20} y1={zh} x2={300} y2={zh} stroke={C.ink} strokeWidth={1.6} strokeDasharray="7 5" />
      <line x1={20} y1={level} x2={300} y2={level} stroke={C.seaLine} strokeWidth={2.4} />
      {/* sonda reduzida */}
      {(mode === "sonda-reduzida" || mode === "sonda-a-hora" || mode === "altura") && (
        <g>
          <Arrow x1={200} y1={seabed} x2={200} y2={zh} color={mode === "sonda-reduzida" ? C.red : C.grey} width={2.2} />
          <Arrow x1={200} y1={zh} x2={200} y2={seabed} color={mode === "sonda-reduzida" ? C.red : C.grey} width={2.2} />
          <Label x={210} y={seabed - 8} size={8.5} anchor="start" color={mode === "sonda-reduzida" ? C.red : C.grey}>sonda reduzida</Label>
        </g>
      )}
      {/* altura da maré */}
      {(mode === "altura" || mode === "sonda-a-hora") && (
        <g>
          <Arrow x1={250} y1={zh} x2={250} y2={level} color={mode === "altura" ? C.red : C.grey} width={2.2} />
          <Arrow x1={250} y1={level} x2={250} y2={zh} color={mode === "altura" ? C.red : C.grey} width={2.2} />
          <Label x={242} y={108} size={8.5} anchor="end" color={mode === "altura" ? C.red : C.grey}>altura da maré</Label>
        </g>
      )}
      {/* sonda à hora */}
      {mode === "sonda-a-hora" && (
        <g>
          <Arrow x1={150} y1={seabed} x2={150} y2={level} color={C.red} width={2.6} />
          <Arrow x1={150} y1={level} x2={150} y2={seabed} color={C.red} width={2.6} />
          <Label x={142} y={112} size={8.5} anchor="end" color={C.red}>sonda à hora</Label>
        </g>
      )}
      {/* amplitude */}
      {mode === "amplitude" && (
        <g>
          <line x1={20} y1={120} x2={300} y2={120} stroke={C.seaLine} strokeWidth={2.2} strokeDasharray="4 4" />
          <Arrow x1={240} y1={level - 14} x2={240} y2={120} color={C.red} width={2.2} />
          <Arrow x1={240} y1={120} x2={240} y2={level - 14} color={C.red} width={2.2} />
          <Label x={120} y={level - 8} size={8.5} color={C.inkSoft}>preia-mar</Label>
          <Label x={120} y={116} size={8.5} color={C.inkSoft}>baixa-mar</Label>
          <Label x={250} y={108} size={8.5} anchor="start" color={C.red}>amplitude</Label>
        </g>
      )}
      <Label x={30} y={zh - 6} size={8.5} anchor="start" color={C.ink}>zero hidrográfico</Label>
      {mode === "sonda-a-hora" && <Label x={160} y={40} size={9} color={C.red}>sʰ = altura da maré + sonda reduzida</Label>}
      {mode === "sonda-reduzida" && <Label x={160} y={40} size={9} color={C.inkSoft}>profundidade anotada na carta</Label>}
      {mode === "altura" && <Label x={160} y={40} size={9} color={C.inkSoft}>altura acima do zero hidrográfico</Label>}
      {mode === "amplitude" && <Label x={160} y={40} size={9} color={C.inkSoft}>preia-mar ↔ baixa-mar consecutivas</Label>}
    </Frame>
  );
}

export function TideThing({ type }: { type: string }) {
  if (type === "luas") {
    return (
      <Frame sea={false}>
        <Sun x={56} y={84} r={15} />
        <circle cx={160} cy={84} r={11} fill={C.inkSoft} />
        <Moon x={236} y={84} r={11} phase="new" />
        <Moon x={266} y={84} r={11} phase="full" />
        <Label x={160} y={110} size={8} color={C.inkSoft}>terra</Label>
        <Label x={56} y={116} size={8} color={C.inkSoft}>sol</Label>
        <Label x={160} y={150} size={9}>lunação ≈ 29,5 dias</Label>
        <Label x={160} y={168} size={8.5} color={C.inkSoft}>nova → crescente → cheia → minguante</Label>
        <Label x={160} y={186} size={8.5} color={C.inkSoft}>idade da lua = dias desde a última lua nova</Label>
      </Frame>
    );
  }
  return <TideDepth mode={type} />;
}

/* ══════════════════════ NUVENS ══════════════════════ */

function CloudShape({ type, x, y, s = 1, color = C.grey }: { type: string; x: number; y: number; s?: number; color?: string }) {
  return (
    <g transform={`translate(${x} ${y}) scale(${s})`} stroke={color} fill="none" strokeWidth={2.2}>
      {type === "cirrus" && <path d="M-26 0 q 12 -8 24 -4 M-20 6 q 14 -8 30 -4 M-14 12 q 12 -6 24 -2" />}
      {type === "cirrocumulus" && (
        <g>
          {[-20, 0, 20].map((dx) => (
            <circle key={dx} cx={dx} cy={0} r={7} />
          ))}
          {[-10, 10].map((dx) => (
            <circle key={dx} cx={dx} cy={-8} r={6} />
          ))}
        </g>
      )}
      {type === "cirrostratus" && <path d="M-30 -6 h 60 M-26 0 h 52 M-30 6 h 60" />}
      {type === "altocumulus" && (
        <g>
          {[-22, -7, 8, 23].map((dx) => (
            <path key={dx} d={`M${dx - 7} 0 a 7 6 0 0 1 14 0 Z`} fill={C.sea} />
          ))}
        </g>
      )}
      {type === "altostratus" && <path d="M-32 -8 h 64 M-32 0 h 64 M-32 8 h 64" strokeWidth={4} opacity={0.7} />}
      {type === "nimbostratus" && (
        <g>
          <path d="M-32 -4 h 64 M-32 4 h 64" strokeWidth={5} />
          {[-18, 0, 18].map((dx) => (
            <line key={dx} x1={dx} y1={12} x2={dx - 3} y2={22} stroke={C.seaLine} strokeWidth={2} />
          ))}
        </g>
      )}
      {type === "stratocumulus" && <path d="M-32 0 a 10 8 0 0 1 20 -4 a 12 9 0 0 1 22 2 a 10 8 0 0 1 18 4 h -60 Z" fill={C.sea} />}
      {type === "stratus" && <path d="M-34 -4 h 68 M-34 4 h 68" strokeWidth={6} opacity={0.55} />}
      {type === "cumulus" && <path d="M-24 6 a 12 10 0 0 1 12 -14 a 13 12 0 0 1 24 4 a 10 9 0 0 1 10 10 Z" fill={C.white} />}
      {type === "cumulonimbus" && (
        <g>
          <path d="M-18 10 a 12 12 0 0 1 4 -24 a 14 14 0 0 1 26 -4 a 12 12 0 0 1 8 28 Z" fill={C.grey} />
          <path d="M-24 -22 h 48 l -6 -8 h -36 Z" fill={C.grey} />
          <path d="M-2 16 l -6 12 h 8 l -6 14" stroke={C.yellow} strokeWidth={2.6} />
        </g>
      )}
    </g>
  );
}

export function CloudThing({ type }: { type: string }) {
  if (type === "overview") {
    return (
      <Frame sea={false}>
        <line x1={24} y1={60} x2={296} y2={60} stroke={C.seaLine} strokeWidth={1.4} strokeDasharray="4 4" />
        <line x1={24} y1={118} x2={296} y2={118} stroke={C.seaLine} strokeWidth={1.4} strokeDasharray="4 4" />
        <CloudShape type="cirrus" x={92} y={40} />
        <CloudShape type="altocumulus" x={92} y={90} />
        <CloudShape type="stratocumulus" x={92} y={140} />
        <CloudShape type="cumulonimbus" x={216} y={128} />
        <Label x={150} y={40} size={8.5} anchor="start">altas — cirro-</Label>
        <Label x={150} y={90} size={8.5} anchor="start">médias — alto-</Label>
        <Label x={150} y={140} size={8.5} anchor="start">baixas · verticais</Label>
        <Label x={160} y={178} size={8.5} color={C.inkSoft}>nimbo = produz precipitação</Label>
      </Frame>
    );
  }
  if (type === "cumulonimbus") {
    return (
      <Frame sea={false}>
        <g transform="translate(160 96) scale(2.6)">
          <CloudShape type="cumulonimbus" x={0} y={0} />
        </g>
        <Label x={160} y={40}>cumulonimbus (cb)</Label>
        <Label x={160} y={180} size={8.5} color={C.red}>tempestade: chuva forte, trovoada, rajadas</Label>
      </Frame>
    );
  }
  // nimbostratus
  return (
    <Frame sea={false}>
      <g transform="translate(160 84) scale(2.2)">
        <CloudShape type="nimbostratus" x={0} y={0} />
      </g>
      <Label x={160} y={40}>nimbostratus (ns)</Label>
      <Label x={160} y={172} size={8.5} color={C.inkSoft}>nuvens baixas e escuras · chuva contínua</Label>
    </Frame>
  );
}

/* ══════════════════════ MOTORES ══════════════════════ */

export function MotorThing({ type }: { type: string }) {
  if (type === "fora-de-borda") {
    const causes = ["falta combustível", "tubo desapertado", "filtro obstruído", "velas gastas"];
    return (
      <Frame sea={false}>
        {/* motor fora de borda */}
        <g transform="translate(96 92)">
          <rect x={-22} y={-34} width={44} height={30} rx={8} fill={C.ink} />
          <rect x={-4} y={-4} width={8} height={48} fill={C.ink} />
          <path d="M0 44 c -8 2 -12 8 -10 14 h 20 c 2 -6 -2 -12 -10 -14 Z" fill={C.ink} />
          <line x1={-22} y1={-26} x2={-40} y2={-30} stroke={C.ink} strokeWidth={3.4} />
        </g>
        {causes.map((c, i) => (
          <g key={c}>
            <circle cx={168} cy={52 + i * 26} r={3.4} fill={C.red} />
            <Label x={180} y={56 + i * 26} size={8.5} anchor="start">{c}</Label>
          </g>
        ))}
        <Label x={160} y={180} size={8.5} color={C.inkSoft}>ângulo errado = perda de velocidade</Label>
      </Frame>
    );
  }
  if (type === "velas") {
    return (
      <Frame sea={false}>
        {/* vela de ignição */}
        <g transform="translate(130 96)">
          <rect x={-10} y={-52} width={20} height={22} rx={4} fill={C.white} stroke={C.ink} strokeWidth={2.2} />
          <path d="M-12 -30 h 24 v 22 l -7 14 h -10 l -7 -14 Z" fill={C.inkSoft} />
          <line x1={0} y1={6} x2={0} y2={26} stroke={C.ink} strokeWidth={4} />
          <path d="M0 26 h 10" stroke={C.ink} strokeWidth={4} />
          {/* faísca */}
          <path d="M2 32 l -6 8 M8 30 l 4 8 M4 34 l 0 10" stroke={C.yellow} strokeWidth={2.6} />
        </g>
        <Label x={196} y={70} size={9} anchor="start" color={C.inkSoft}>faísca que inflama</Label>
        <Label x={196} y={86} size={9} anchor="start" color={C.inkSoft}>a mistura ar-gasolina</Label>
        <Label x={160} y={170} size={8.5} color={C.inkSoft}>velas gastas = motor não arranca</Label>
      </Frame>
    );
  }
  if (type === "arrefecimento") {
    return (
      <Frame>
        {/* casco + motor + circuito */}
        <path d="M70 150 L 84 124 L 236 124 L 250 150 Z" fill="none" stroke={C.ink} strokeWidth={2.2} />
        <rect x={130} y={92} width={60} height={32} rx={6} fill={C.ink} />
        {/* entrada de água + circuito */}
        <circle cx={104} cy={146} r={5} fill={C.seaLine} />
        <path d="M104 146 C 104 122 120 118 132 114" fill="none" stroke={C.seaLine} strokeWidth={3} />
        <path d="M190 114 C 216 118 226 128 228 148" fill="none" stroke={C.seaLine} strokeWidth={3} strokeDasharray="5 4" />
        <Arrow x1={96} y1={162} x2={96} y2={150} color={C.seaLine} width={2.2} />
        <Label x={160} y={76} size={9}>entrada de água → motor → escape</Label>
        <Label x={160} y={184} size={8.5} color={C.inkSoft}>desobstruído + lavagem com água doce</Label>
      </Frame>
    );
  }
  if (type === "macho") {
    return (
      <Frame>
        {/* casco secção */}
        <path d="M110 118 L 210 118 L 196 170 L 124 170 Z" fill={C.paper} stroke={C.ink} strokeWidth={2.4} />
        {/* macho de fundo */}
        <rect x={152} y={158} width={16} height={16} rx={3} fill={C.red} />
        <line x1={160} y1={158} x2={160} y2={136} stroke={C.ink} strokeWidth={3.4} />
        <circle cx={160} cy={132} r={7} fill="none" stroke={C.ink} strokeWidth={2.6} />
        <Arrow x1={160} y1={188} x2={160} y2={176} color={C.seaLine} width={2.4} />
        <Label x={220} y={140} size={9} color={C.red}>macho de fundo</Label>
        <Label x={160} y={60} size={8.5} color={C.inkSoft}>abrir antes de pôr o motor a trabalhar</Label>
      </Frame>
    );
  }
  // combustiveis
  return (
    <Frame sea={false}>
      <rect x={40} y={56} width={110} height={88} rx={8} fill={C.white} stroke={C.ink} strokeWidth={2} />
      <Label x={95} y={78} size={10}>gasóleo</Label>
      <Label x={95} y={98} size={8} color={C.inkSoft}>ar no circuito trava</Label>
      <Label x={95} y={112} size={8} color={C.inkSoft}>o arranque</Label>
      <rect x={170} y={56} width={110} height={88} rx={8} fill={C.white} stroke={C.ink} strokeWidth={2} />
      <Label x={225} y={78} size={10}>gasolina</Label>
      <Label x={225} y={98} size={8} color={C.inkSoft}>velas + filtro em</Label>
      <Label x={225} y={112} size={8} color={C.inkSoft}>bom estado</Label>
      <Label x={160} y={172} size={8.5} color={C.inkSoft}>óleo e filtros do fabricante · revisões a tempo</Label>
    </Frame>
  );
}

/* ══════════════════════ NAVEGAÇÃO — velocidade e distância ══════════════════════ */

export function NavThing({ type }: { type: string }) {
  if (type === "milha") {
    return (
      <Frame>
        {/* régua sobre o mar */}
        {[0, 1, 2, 3, 4, 5, 6, 7, 8].map((i) => (
          <line key={i} x1={40 + i * 30} y1={86} x2={40 + i * 30} y2={i % 2 ? 96 : 104} stroke={C.ink} strokeWidth={2.2} />
        ))}
        <line x1={40} y1={86} x2={280} y2={86} stroke={C.ink} strokeWidth={2.6} />
        <Arrow x1={40} y1={66} x2={280} y2={66} color={C.red} width={2.2} />
        <Arrow x1={280} y1={66} x2={40} y2={66} color={C.red} width={2.2} />
        <Label x={160} y={52} size={10} color={C.red}>1 milha = 1852 m</Label>
        <Label x={160} y={130} size={8.5} color={C.inkSoft}>unidade de distância na navegação</Label>
      </Frame>
    );
  }
  if (type === "no") {
    return (
      <Frame>
        <BoatSideX />
        {/* barquinha: cunha de madeira + linha com nós */}
        <path d="M196 138 C 214 146 226 152 234 158" fill="none" stroke={C.ink} strokeWidth={2} strokeDasharray="4 4" />
        {[206, 216, 226].map((x, i) => (
          <circle key={i} cx={x} cy={145 + i * 6} r={3} fill={C.red} />
        ))}
        <path d="M236 152 l 14 6 l -4 12 l -14 -6 Z" fill={C.inkSoft} />
        <Label x={160} y={66} size={10}>1 nó = 1 milha / hora</Label>
        <Label x={160} y={182} size={8.5} color={C.inkSoft}>o nome vem dos nós da linha da barquinha</Label>
      </Frame>
    );
  }
  // odometro
  return (
    <Frame>
      <BoatSideX />
      {/* instrumento na popa */}
      <circle cx={96} cy={96} r={26} fill={C.white} stroke={C.ink} strokeWidth={2.6} />
      <line x1={96} y1={96} x2={110} y2={82} stroke={C.red} strokeWidth={3} />
      {[0, 45, 90, 135, 180, 225, 270, 315].map((a) => (
        <line key={a} x1={96 + 20 * Math.cos((a * Math.PI) / 180)} y1={96 + 20 * Math.sin((a * Math.PI) / 180)} x2={96 + 24 * Math.cos((a * Math.PI) / 180)} y2={96 + 24 * Math.sin((a * Math.PI) / 180)} stroke={C.ink} strokeWidth={1.6} />
      ))}
      <path d="M200 140 C 216 148 226 154 232 160" fill="none" stroke={C.ink} strokeWidth={2} strokeDasharray="4 4" />
      <circle cx={236} cy={164} r={7} fill="none" stroke={C.ink} strokeWidth={2.4} />
      <path d="M236 157 v 14 M229 164 h 14" stroke={C.ink} strokeWidth={2} />
      <Label x={96} y={60} size={9}>odómetro</Label>
      <Label x={160} y={186} size={8.5} color={C.inkSoft}>mede velocidade e distância percorrida</Label>
    </Frame>
  );
}

function BoatSideX() {
  return (
    <g transform="translate(150 140)">
      <path d="M-46 -14 L 28 -14 L 46 -1 L 46 2 L -46 2 Z" fill={C.ink} />
      <rect x={-16} y={-26} width={24} height={12} rx={2} fill={C.ink} />
    </g>
  );
}

/* ══════════════════════ LEGISLAÇÃO ══════════════════════ */

export function LegThing() {
  // mota de água
  return (
    <Frame>
      <g transform="translate(160 132)">
        <path d="M-44 4 q 8 -16 28 -16 q 28 0 44 10 l -8 10 q -32 8 -64 -4 Z" fill={C.ink} />
        <line x1={-6} y1={-12} x2={8} y2={-26} stroke={C.ink} strokeWidth={3.4} />
        <line x1={8} y1={-26} x2={22} y2={-24} stroke={C.ink} strokeWidth={3.4} />
        {/* condutor */}
        <circle cx={-2} cy={-30} r={6} fill={C.inkSoft} />
        <path d="M-2 -24 l 2 12" stroke={C.inkSoft} strokeWidth={3.4} />
      </g>
      <path d="M118 148 q 14 8 30 4 M180 152 q 16 8 34 2" stroke={C.seaLine} strokeWidth={2.6} fill="none" />
      <Label x={160} y={60}>mota de água = embarcação de recreio</Label>
      <Label x={160} y={180} size={8.5} color={C.inkSoft}>mesmas regras de habilitação e navegação</Label>
    </Frame>
  );
}
