import { Arrow, BoatSide, C, Frame, Label, Moon, SailboatSide, Sun, W } from "./shared";

/* ---------- Legislação ---------- */

export function Recreio() {
  return (
    <Frame>
      <SailboatSide x={90} scale={0.8} />
      <BoatSide x={220} scale={0.8} flip />
      {/* mota de água */}
      <g transform="translate(268 148)">
        <path d="M-16 0 L -10 -8 L 8 -8 L 16 0 Z" fill={C.red} stroke={C.ink} strokeWidth={1.2} />
        <path d="M-4 -8 L 2 -16 L 8 -16" fill="none" stroke={C.ink} strokeWidth={2} />
      </g>
      <Label x={W / 2} y={44} size={10}>2,5 m – 24 m</Label>
      <Label x={W / 2} y={60} size={9} color={C.inkSoft}>lazer · sem fins lucrativos</Label>
    </Frame>
  );
}

export function Harbour() {
  return (
    <Frame>
      {/* molhe */}
      <path d="M0 96 L 96 96 L 96 112 L 0 112 Z" fill={C.sand} stroke={C.ink} strokeWidth={1.6} />
      <path d="M96 96 L 150 118 L 142 132 L 96 112 Z" fill={C.sand} stroke={C.ink} strokeWidth={1.6} />
      {/* farolim */}
      <g transform="translate(148 96)">
        <rect x={-5} y={-26} width={10} height={26} fill={C.white} stroke={C.ink} strokeWidth={1.6} />
        <rect x={-7} y={-34} width={14} height={9} fill={C.red} stroke={C.ink} strokeWidth={1.4} />
      </g>
      <SailboatSide x={56} y={140} scale={0.75} />
      <BoatSide x={196} y={152} scale={0.65} flip />
      <Label x={W / 2} y={40} size={9} color={C.inkSoft}>refúgio · embarque em segurança</Label>
    </Frame>
  );
}

export function VesselTypes() {
  const rows = [
    { t: "1", d: "Oceânica — sem limite", w: 250 },
    { t: "2", d: "Oceânica restrita — 200 M", w: 208 },
    { t: "3", d: "Costeira — 25 M", w: 166 },
    { t: "4", d: "Local restrita — 6 M", w: 124 },
    { t: "5", d: "Local protegida — 3 M", w: 82 },
  ];
  return (
    <Frame sea={false}>
      {rows.map((r, i) => (
        <g key={r.t}>
          <rect x={34} y={32 + i * 32} width={r.w} height={22} fill={i % 2 ? C.sea : C.paper} stroke={C.ink} strokeWidth={1.4} />
          <circle cx={50} cy={43 + i * 32} r={11} fill={C.ink} />
          <Label x={50} y={47 + i * 32} size={10} color={C.paper}>{r.t}</Label>
          <Label x={70} y={47 + i * 32} anchor="start" size={9}>{r.d}</Label>
        </g>
      ))}
    </Frame>
  );
}

/* ---------- Balizagem ---------- */

function BuoyBase({ x, body }: { x: number; body: React.ReactNode }) {
  return (
    <g transform={`translate(${x} 0)`}>
      <path d="M-16 150 L 16 150 L 10 128 L -10 128 Z" fill={C.black} />
      {body}
    </g>
  );
}

export function LateralMarks() {
  return (
    <Frame>
      {/* canal */}
      <path d="M120 150 L 200 150 L 230 200 L 90 200 Z" fill={C.sea} opacity={0.5} />
      <Label x={160} y={186} size={9} color={C.inkSoft}>canal — sentido da entrada</Label>
      <Arrow x1={160} y1={172} x2={160} y2={156} color={C.inkSoft} width={1.6} />
      {/* BB vermelho cilíndrico */}
      <BuoyBase
        x={86}
        body={
          <g>
            <rect x={-11} y={96} width={22} height={32} fill={C.red} stroke={C.ink} strokeWidth={1.6} />
            <rect x={-8} y={78} width={16} height={18} rx={2} fill={C.red} stroke={C.ink} strokeWidth={1.6} />
            <circle cx={0} cy={72} r={4} fill={C.red} />
          </g>
        }
      />
      <Label x={86} y={170} size={9} color={C.red}>BB</Label>
      {/* EB verde cónico */}
      <BuoyBase
        x={234}
        body={
          <g>
            <path d="M-12 128 L 0 82 L 12 128 Z" fill={C.green} stroke={C.ink} strokeWidth={1.6} />
            <circle cx={0} cy={76} r={4} fill={C.green} />
          </g>
        }
      />
      <Label x={234} y={170} size={9} color={C.green}>EB</Label>
    </Frame>
  );
}

function Cones({ x, y, variant }: { x: number; y: number; variant: "N" | "E" | "S" | "W" }) {
  const up = (dy: number) => <path d={`M${x - 9} ${y + dy} L ${x} ${y + dy - 16} L ${x + 9} ${y + dy} Z`} fill={C.black} />;
  const down = (dy: number) => <path d={`M${x - 9} ${y + dy} L ${x} ${y + dy + 16} L ${x + 9} ${y + dy} Z`} fill={C.black} />;
  if (variant === "N") return <g>{up(-4)}{up(-24)}</g>;
  if (variant === "S") return <g>{down(4)}{down(24)}</g>;
  if (variant === "E") return <g>{up(-12)}{down(8)}</g>;
  return <g>{down(-12)}{up(8)}</g>;
}

export function CardinalMarks() {
  const cols: { v: "N" | "E" | "S" | "W"; bands: string[] }[] = [
    { v: "N", bands: [C.black, C.yellow] },
    { v: "E", bands: [C.black, C.yellow, C.black] },
    { v: "S", bands: [C.yellow, C.black] },
    { v: "W", bands: [C.yellow, C.black, C.yellow] },
  ];
  return (
    <Frame sea={false}>
      {cols.map((c, i) => {
        const x = 48 + i * 76;
        const bh = 40 / c.bands.length;
        return (
          <g key={c.v}>
            <Cones x={x} y={58} variant={c.v} />
            <line x1={x} y1={86} x2={x} y2={96} stroke={C.ink} strokeWidth={2} />
            {c.bands.map((col, bi) => (
              <rect key={bi} x={x - 12} y={96 + bi * bh} width={24} height={bh} fill={col} stroke={C.ink} strokeWidth={1} />
            ))}
            <path d={`M${x - 14} 150 L ${x + 14} 150 L ${x + 9} 136 L ${x - 9} 136 Z`} fill={C.black} />
            <Label x={x} y={170} size={10}>{c.v}</Label>
          </g>
        );
      })}
      <Label x={W / 2} y={28} size={8} color={C.inkSoft}>passar no quadrante indicado</Label>
    </Frame>
  );
}

export function IsolatedDanger() {
  return (
    <Frame>
      <BuoyBase
        x={120}
        body={
          <g>
            <rect x={-13} y={92} width={26} height={36} fill={C.black} />
            <rect x={-13} y={102} width={26} height={12} fill={C.red} />
            <rect x={-13} y={92} width={26} height={36} fill="none" stroke={C.ink} strokeWidth={1.6} />
            <line x1={0} y1={92} x2={0} y2={66} stroke={C.ink} strokeWidth={2} />
            <circle cx={0} cy={60} r={7} fill={C.black} />
            <circle cx={0} cy={44} r={7} fill={C.black} />
          </g>
        }
      />
      {/* rocha */}
      <path d="M96 168 L 112 148 L 128 168 Z" fill={C.grey} stroke={C.ink} strokeWidth={1.4} />
      <Label x={210} y={110} anchor="start" size={9}>2 esferas pretas</Label>
      <Label x={210} y={126} anchor="start" size={8} color={C.inkSoft}>preto + faixa vermelha</Label>
      <Label x={210} y={142} anchor="start" size={8} color={C.inkSoft}>águas limpas à volta</Label>
    </Frame>
  );
}

export function SafeWater() {
  return (
    <Frame>
      <BuoyBase
        x={160}
        body={
          <g>
            {[0, 1, 2, 3, 4].map((i) => (
              <rect key={i} x={-13 + i * 5.2} y={92} width={5.2} height={36} fill={i % 2 ? C.white : C.red} />
            ))}
            <rect x={-13} y={92} width={26} height={36} fill="none" stroke={C.ink} strokeWidth={1.6} />
            <line x1={0} y1={92} x2={0} y2={74} stroke={C.ink} strokeWidth={2} />
            <circle cx={0} cy={66} r={8} fill={C.red} stroke={C.ink} strokeWidth={1.4} />
          </g>
        }
      />
      {/* passável por todos os lados */}
      {[0, 90, 180, 270].map((a) => {
        const r = (a * Math.PI) / 180;
        const x1 = 160 + 56 * Math.cos(r), y1 = 110 + 34 * Math.sin(r);
        const x2 = 160 + 40 * Math.cos(r), y2 = 110 + 24 * Math.sin(r);
        return <Arrow key={a} x1={x1} y1={y1} x2={x2} y2={y2} color={C.inkSoft} width={1.6} />;
      })}
      <Label x={W / 2} y={176} size={8} color={C.inkSoft}>riscas verticais vermelho-branco · 1 esfera vermelha</Label>
    </Frame>
  );
}

export function SpecialMark() {
  return (
    <Frame>
      <BuoyBase
        x={160}
        body={
          <g>
            <path d="M-12 128 L 0 92 L 12 128 Z" fill={C.yellow} stroke={C.ink} strokeWidth={1.6} />
            <line x1={0} y1={92} x2={0} y2={78} stroke={C.ink} strokeWidth={2} />
            <path d="M-9 76 L 9 60 M-9 60 L 9 76" stroke={C.yellow} strokeWidth={6} />
            <path d="M-9 76 L 9 60 M-9 60 L 9 76" stroke={C.ink} strokeWidth={1.6} />
          </g>
        }
      />
      <Label x={W / 2} y={44} size={9} color={C.inkSoft}>amarela · cabeço em X</Label>
      <Label x={W / 2} y={176} size={8} color={C.inkSoft}>recreio · banhos · culturas marinhas · cabos</Label>
    </Frame>
  );
}

/* ---------- Marés ---------- */

function TideCurveBase({ slack = false }: { slack?: boolean }) {
  return (
    <g>
      <line x1={30} y1={160} x2={300} y2={160} stroke={C.ink} strokeWidth={1.6} />
      <line x1={30} y1={160} x2={30} y2={30} stroke={C.ink} strokeWidth={1.6} />
      <path
        d="M34 120 C 70 116 80 56 120 52 C 160 48 170 118 210 122 C 240 124 250 84 290 78"
        fill="none"
        stroke={C.red}
        strokeWidth={2.6}
      />
      {slack && (
        <g>
          <line x1={108} y1={44} x2={136} y2={44} stroke={C.ink} strokeWidth={2.4} />
          <line x1={196} y1={130} x2={224} y2={130} stroke={C.ink} strokeWidth={2.4} />
          <Label x={122} y={38} size={8}>estofo</Label>
          <Label x={210} y={144} size={8}>estofo</Label>
        </g>
      )}
      {!slack && (
        <g>
          <circle cx={120} cy={52} r={4} fill={C.ink} />
          <circle cx={210} cy={122} r={4} fill={C.ink} />
          <Label x={120} y={40} size={9}>preia-mar</Label>
          <Label x={210} y={142} size={9}>baixa-mar</Label>
          <Arrow x1={164} y1={92} x2={186} y2={106} color={C.inkSoft} width={1.6} />
          <Label x={168} y={84} size={8} color={C.inkSoft}>vaza</Label>
          <Label x={64} y={84} size={8} color={C.inkSoft}>enche</Label>
        </g>
      )}
      <Label x={296} y={172} size={8} anchor="end" color={C.inkSoft}>tempo</Label>
    </g>
  );
}

export function TideCurve() {
  return (
    <Frame sea={false}>
      <TideCurveBase />
      <Label x={W / 2} y={188} size={8} color={C.inkSoft}>entre duas baixa-mares ≈ 12 h (Portugal continental)</Label>
    </Frame>
  );
}

export function TideSlack() {
  return (
    <Frame sea={false}>
      <TideCurveBase slack />
      <Label x={W / 2} y={188} size={8} color={C.inkSoft}>nível imobilizado antes de a maré inverter</Label>
    </Frame>
  );
}

export function Syzygy() {
  return (
    <Frame sea={false}>
      <Sun x={56} y={100} r={16} />
      {/* Terra */}
      <circle cx={160} cy={100} r={13} fill={C.sea} stroke={C.ink} strokeWidth={1.8} />
      <Label x={160} y={128} size={8}>Terra</Label>
      {/* Lua cheia (oposição) */}
      <Moon x={248} y={62} r={10} phase="full" />
      <Label x={248} y={86} size={8}>cheia</Label>
      {/* Lua nova (conjunção) */}
      <Moon x={112} y={100} r={10} phase="new" />
      <Label x={112} y={128} size={8}>nova</Label>
      <line x1={40} y1={100} x2={264} y2={100} stroke={C.inkSoft} strokeWidth={1} strokeDasharray="4 4" />
      <line x1={160} y1={100} x2={248} y2={62} stroke={C.inkSoft} strokeWidth={1} strokeDasharray="4 4" />
      <Label x={W / 2} y={176} size={9}>alinhados → marés vivas</Label>
    </Frame>
  );
}

export function ChartDatum() {
  return (
    <Frame sea={false}>
      {/* nível do mar (sonda à hora) */}
      <rect x={0} y={60} width={W} height={80} fill={C.sea} />
      <line x1={0} y1={60} x2={W} y2={60} stroke={C.ink} strokeWidth={1.8} />
      <Label x={8} y={52} anchor="start" size={8} color={C.inkSoft}>nível do mar agora</Label>
      {/* zero hidrográfico */}
      <line x1={0} y1={110} x2={W} y2={110} stroke={C.red} strokeWidth={1.8} strokeDasharray="8 5" />
      <Label x={8} y={104} anchor="start" size={8} color={C.red}>zero hidrográfico</Label>
      {/* fundo */}
      <rect x={0} y={140} width={W} height={60} fill={C.sand} />
      {/* sonda reduzida */}
      <line x1={120} y1={110} x2={120} y2={140} stroke={C.ink} strokeWidth={2.2} />
      <Label x={130} y={130} anchor="start" size={9}>sonda reduzida (carta)</Label>
      {/* altura da maré */}
      <line x1={220} y1={60} x2={220} y2={110} stroke={C.green} strokeWidth={2.2} />
      <Label x={230} y={90} anchor="start" size={9} color={C.green}>altura da maré</Label>
      <Label x={W / 2} y={176} size={8} color={C.inkSoft}>sonda à hora = sonda reduzida + altura da maré</Label>
    </Frame>
  );
}

/* ---------- Meteorologia / Motores ---------- */

export function Breeze() {
  return (
    <Frame sea={false}>
      {/* sol */}
      <Sun x={56} y={44} r={12} />
      {/* terra */}
      <rect x={0} y={118} width={130} height={82} fill={C.sand} stroke={C.ink} strokeWidth={1.6} />
      <Label x={65} y={166} size={9}>terra</Label>
      {/* mar */}
      <rect x={130} y={118} width={190} height={82} fill={C.sea} stroke={C.ink} strokeWidth={1.6} />
      <Label x={225} y={166} size={9}>mar</Label>
      {/* viração: mar → terra */}
      <Arrow x1={216} y1={96} x2={110} y2={96} color={C.red} width={2.4} />
      <Label x={163} y={88} size={9} color={C.red}>viração (dia)</Label>
      {/* terral: terra → mar */}
      <Arrow x1={104} y1={134} x2={208} y2={134} color={C.inkSoft} width={2.4} dashed />
      <Label x={163} y={152} size={8} color={C.inkSoft}>terral (noite)</Label>
    </Frame>
  );
}

export function Beaufort() {
  const rows = [
    { f: "0", label: "Calma", waves: 0 },
    { f: "3", label: "Brisa fraca", waves: 1 },
    { f: "6", label: "Fresco", waves: 2 },
    { f: "9", label: "Temporal", waves: 3 },
    { f: "12", label: "Furacão", waves: 4 },
  ];
  return (
    <Frame sea={false}>
      {rows.map((r, i) => (
        <g key={r.f} transform={`translate(0 ${34 + i * 32})`}>
          <circle cx={42} cy={12} r={11} fill={i < 2 ? C.green : i < 3 ? C.yellow : C.red} stroke={C.ink} strokeWidth={1.2} />
          <Label x={42} y={16} size={9} color={i < 2 ? C.paper : C.black}>{r.f}</Label>
          <Label x={62} y={16} anchor="start" size={9}>{r.label}</Label>
          {Array.from({ length: r.waves + 1 }).map((_, wi) => (
            <path
              key={wi}
              d={`M${150 + wi * 34} 14 q ${6 + wi * 2} ${-(6 + wi * 4)} ${12 + wi * 4} 0`}
              fill="none"
              stroke={C.inkSoft}
              strokeWidth={1.8 + wi * 0.5}
            />
          ))}
        </g>
      ))}
      <Label x={W / 2} y={192} size={8} color={C.inkSoft}>Beaufort: vento 0–12 · Douglas: estado da ondulação</Label>
    </Frame>
  );
}

export function Cavitation() {
  return (
    <Frame sea={false}>
      <rect x={0} y={84} width={W} height={116} fill={C.sea} />
      {/* motor fora de borda */}
      <g transform="translate(120 0)">
        <rect x={-20} y={18} width={40} height={34} rx={6} fill={C.ink} />
        <rect x={-6} y={52} width={12} height={52} fill={C.inkSoft} />
        {/* hélice */}
        <g transform="translate(0 112)">
          {[0, 120, 240].map((a) => (
            <path key={a} d="M0 0 C 10 -3 16 -11 15 -21 C 6 -18 1 -10 0 0 Z" fill={C.ink} transform={`rotate(${a})`} />
          ))}
          <circle cx={0} cy={0} r={5} fill={C.yellow} stroke={C.ink} strokeWidth={1.4} />
        </g>
      </g>
      {/* bolhas */}
      {[[146, 108, 4], [158, 100, 6], [172, 92, 4], [166, 114, 3], [186, 106, 5], [198, 96, 3]].map(([x, y, r], i) => (
        <circle key={i} cx={x} cy={y} r={r} fill={C.white} stroke={C.inkSoft} strokeWidth={1.2} />
      ))}
      <Label x={W / 2} y={34} size={9} color={C.inkSoft}>bolhas de vapor junto à hélice</Label>
      <Label x={W / 2} y={182} size={8} color={C.inkSoft}>menos empuxo · vibração · erosão das pás</Label>
    </Frame>
  );
}

export function SiglaThing({ type }: { type: string }) {
  const size = type.length > 7 ? 24 : type.length > 5 ? 30 : 36;
  return (
    <Frame sea={false}>
      {/* ondas de rádio */}
      <g transform="translate(160 46)">
        <path d="M-42 0 q 42 -26 84 0" fill="none" stroke={C.inkSoft} strokeWidth={2.2} />
        <path d="M-29 -13 q 29 -18 58 0" fill="none" stroke={C.inkSoft} strokeWidth={2.2} />
        <path d="M-16 -26 q 16 -10 32 0" fill="none" stroke={C.inkSoft} strokeWidth={2.2} />
      </g>
      <text
        x={W / 2}
        y={126}
        textAnchor="middle"
        fontSize={size}
        fontStyle="italic"
        fontWeight={700}
        fill={C.ink}
        fontFamily="ui-monospace, SFMono-Regular, Menlo, monospace"
        letterSpacing={2}
      >
        {type}
      </text>
      <Label x={W / 2} y={160} size={9} color={C.inkSoft}>sigla internacional · usada no mar em todo o mundo</Label>
    </Frame>
  );
}

export { Arrow, Moon };
