import { Arrow, BoatSide, C, Frame, Label, Sun, W, WindArrow } from "./shared";

/** Balsa pneumática */
export function Liferaft() {
  return (
    <Frame>
      <g transform="translate(160 128)">
        <ellipse cx={0} cy={14} rx={64} ry={16} fill={C.yellow} stroke={C.ink} strokeWidth={2} />
        <ellipse cx={0} cy={10} rx={44} ry={10} fill={C.paper} stroke={C.ink} strokeWidth={1.6} />
        <path d="M-40 4 Q -40 -34 0 -34 Q 40 -34 40 4" fill={C.red} stroke={C.ink} strokeWidth={1.8} />
        <path d="M-40 4 Q 0 -10 40 4" fill="none" stroke={C.ink} strokeWidth={1.4} />
      </g>
      <Label x={W / 2} y={52}>Balsa pneumática</Label>
      <Label x={W / 2} y={66} size={9} color={C.inkSoft}>cabo da garrafa de ar fixo a bordo</Label>
    </Frame>
  );
}

/** Colete de salvação */
export function Lifejacket() {
  return (
    <Frame sea={false}>
      <g transform="translate(160 100)">
        <path
          d="M-14 -56 Q 0 -66 14 -56 L 16 -34 Q 34 -30 34 -12 L 30 44 Q 30 52 22 52 L 8 52 L 8 20 L -8 20 L -8 52 L -22 52 Q -30 52 -30 44 L -34 -12 Q -34 -30 -16 -34 Z"
          fill={C.yellow}
          stroke={C.ink}
          strokeWidth={2}
        />
        <line x1={0} y1={-58} x2={0} y2={20} stroke={C.ink} strokeWidth={1.6} />
        <rect x={-30} y={-8} width={60} height={8} fill={C.red} opacity={0.85} />
        <rect x={-26} y={22} width={14} height={22} fill={C.red} opacity={0.85} />
        <rect x={12} y={22} width={14} height={22} fill={C.red} opacity={0.85} />
      </g>
      <Label x={W / 2} y={180} size={9} color={C.inkSoft}>1 por pessoa a bordo · crianças sempre com colete</Label>
    </Frame>
  );
}

/** Bóia de salvação com retenida e com luz */
export function Lifebuoy() {
  return (
    <Frame>
      <g transform="translate(105 100)">
        <circle cx={0} cy={0} r={38} fill={C.red} stroke={C.ink} strokeWidth={2} />
        <circle cx={0} cy={0} r={18} fill={C.paper} stroke={C.ink} strokeWidth={1.8} />
        {[0, 90, 180, 270].map((a) => (
          <rect key={a} x={-7} y={-38} width={14} height={20} fill={C.white} stroke={C.ink} strokeWidth={1.2} transform={`rotate(${a})`} />
        ))}
        <path d="M38 0 q 30 6 44 30 q 10 18 30 20" fill="none" stroke={C.inkSoft} strokeWidth={2.2} strokeDasharray="6 4" />
      </g>
      <Label x={105} y={162} size={9}>com retenida (30 m)</Label>
      <g transform="translate(245 100)">
        <circle cx={0} cy={0} r={30} fill={C.red} stroke={C.ink} strokeWidth={2} />
        <circle cx={0} cy={0} r={13} fill={C.paper} stroke={C.ink} strokeWidth={1.6} />
        <circle cx={0} cy={-38} r={7} fill={C.yellow} stroke={C.ink} strokeWidth={1.6} />
        {[-9, 0, 9].map((dx) => (
          <line key={dx} x1={dx} y1={-52} x2={dx} y2={-60} stroke={C.yellow} strokeWidth={2.2} />
        ))}
      </g>
      <Label x={245} y={162} size={9}>com luz</Label>
    </Frame>
  );
}

/** Sinais pirotécnicos */
export function Flares() {
  return (
    <Frame>
      {/* pára-quedas */}
      <path d="M60 70 Q 85 28 110 70" fill={C.red} stroke={C.ink} strokeWidth={1.6} />
      <line x1={66} y1={66} x2={85} y2={92} stroke={C.ink} strokeWidth={1.2} />
      <line x1={104} y1={66} x2={85} y2={92} stroke={C.ink} strokeWidth={1.2} />
      <circle cx={85} cy={96} r={6} fill={C.red} />
      {[-8, 0, 8].map((dx) => (
        <line key={dx} x1={85 + dx} y1={108} x2={85 + dx} y2={116} stroke={C.red} strokeWidth={2} />
      ))}
      <Label x={85} y={140} size={8}>Pára-quedas</Label>
      {/* facho de mão */}
      <g transform="translate(180 100)">
        <rect x={-5} y={0} width={10} height={34} rx={3} fill={C.ink} />
        <path d="M0 0 C -10 -12 -8 -26 0 -34 C 8 -26 10 -12 0 0" fill={C.red} />
        <path d="M0 -4 C -5 -12 -4 -20 0 -25 C 4 -20 5 -12 0 -4" fill={C.yellow} />
      </g>
      <Label x={180} y={152} size={8}>Facho de mão</Label>
      {/* fumígeno */}
      <g transform="translate(258 108)">
        <rect x={-6} y={6} width={12} height={26} rx={3} fill={C.ink} />
        <circle cx={-2} cy={-2} r={9} fill="#e07b39" opacity={0.9} />
        <circle cx={8} cy={-12} r={12} fill="#e07b39" opacity={0.75} />
        <circle cx={-6} cy={-22} r={14} fill="#e07b39" opacity={0.6} />
      </g>
      <Label x={258} y={152} size={8}>Fumígeno</Label>
    </Frame>
  );
}

/** Manobra de Butakow */
export function Butakow() {
  return (
    <Frame sea={false}>
      <rect x={0} y={150} width={W} height={50} fill={C.sea} />
      {/* trajeto */}
      <path
        d="M60 150 C 60 110 90 96 130 96 C 190 96 236 118 250 150 C 258 168 244 178 226 174"
        fill="none"
        stroke={C.red}
        strokeWidth={2.4}
      />
      <Arrow x1={226} y1={174} x2={206} y2={168} color={C.red} width={2.4} />
      <BoatSide x={60} y={150} scale={0.7} />
      <BoatSide x={212} y={166} scale={0.7} flip />
      {/* náufrago */}
      <circle cx={268} cy={156} r={5} fill={C.ink} />
      <path d="M258 160 q 10 6 20 0" stroke={C.ink} strokeWidth={2} fill="none" />
      <Label x={120} y={70} size={9}>1.º leme todo a um bordo (~60°)</Label>
      <Label x={200} y={84} size={9}>2.º leme todo ao bordo contrário</Label>
      <Label x={250} y={140} size={8} anchor="middle" color={C.inkSoft}>vítima</Label>
    </Frame>
  );
}

/** Hipotermia: termómetro abaixo de 35 °C */
export function Hypothermia() {
  return (
    <Frame sea={false}>
      <g transform="translate(130 100)">
        <rect x={-8} y={-64} width={16} height={96} rx={8} fill={C.white} stroke={C.ink} strokeWidth={2} />
        <circle cx={0} cy={44} r={16} fill={C.white} stroke={C.ink} strokeWidth={2} />
        <rect x={-3} y={-20} width={6} height={60} fill="#5b8fb0" />
        <circle cx={0} cy={44} r={10} fill="#5b8fb0" />
        {/* marca dos 35° */}
        <line x1={8} y1={-18} x2={26} y2={-18} stroke={C.red} strokeWidth={2.4} />
        <Label x={34} y={-14} anchor="start" size={10} color={C.red}>35 °C</Label>
        {[ -48, -32, -2, 12 ].map((dy) => (
          <line key={dy} x1={8} y1={dy} x2={16} y2={dy} stroke={C.ink} strokeWidth={1.4} />
        ))}
      </g>
      {/* floco de neve */}
      <g transform="translate(230 90)" stroke={C.inkSoft} strokeWidth={2.2} strokeLinecap="round">
        {[0, 60, 120].map((a) => (
          <line key={a} x1={-22} y1={0} x2={22} y2={0} transform={`rotate(${a})`} />
        ))}
        <circle cx={0} cy={0} r={4} fill={C.inkSoft} stroke="none" />
      </g>
      <Label x={230} y={134} size={9} color={C.inkSoft}>&lt; 35 °C = hipotermia</Label>
    </Frame>
  );
}

/** Insolação */
export function Sunstroke() {
  return (
    <Frame sea={false}>
      <Sun x={90} y={70} r={18} />
      <g transform="translate(200 118)">
        <circle cx={0} cy={-30} r={14} fill={C.red} stroke={C.ink} strokeWidth={1.8} />
        <path d="M-10 -16 L 10 -16 L 14 24 L -14 24 Z" fill={C.ink} />
        {/* ondas de calor */}
        <path d="M-30 -52 q 6 -8 0 -16 M0 -56 q 6 -8 0 -16 M30 -52 q 6 -8 0 -16" fill="none" stroke={C.red} strokeWidth={2} />
      </g>
      <Label x={200} y={172} size={9} color={C.inkSoft}>sombra · fresco · compressas frias</Label>
    </Frame>
  );
}

/** Hidrocussão: imersão súbita em água fria */
export function Hydrocussion() {
  return (
    <Frame>
      {/* pessoa a cair */}
      <g transform="translate(140 96) rotate(35)">
        <circle cx={0} cy={-18} r={7} fill={C.ink} />
        <path d="M0 -10 L 0 12 M0 -6 L -10 2 M0 -6 L 10 2 M0 12 L -7 26 M0 12 L 7 26" stroke={C.ink} strokeWidth={3} fill="none" strokeLinecap="round" />
      </g>
      {/* salpicos */}
      <path d="M110 148 q -6 -14 -14 -18 M150 146 q 4 -16 12 -22 M170 148 q 8 -10 16 -12" fill="none" stroke={C.inkSoft} strokeWidth={2.4} />
      {/* símbolo de choque térmico */}
      <g transform="translate(240 86)">
        <path d="M0 -26 L 10 -6 L 2 -6 L 12 18 L -8 -2 L 0 -2 Z" fill={C.yellow} stroke={C.ink} strokeWidth={1.6} />
      </g>
      <Label x={240} y={130} size={9} color={C.inkSoft}>choque térmico</Label>
      <Label x={W / 2} y={40}>imersão súbita → iniciar R.C.P.</Label>
    </Frame>
  );
}

/** PLS — posição lateral de segurança */
export function Pls() {
  return (
    <Frame sea={false}>
      <rect x={40} y={140} width={240} height={8} rx={4} fill={C.seaLine} />
      <g transform="translate(160 138)">
        {/* corpo deitado de lado */}
        <circle cx={-64} cy={-18} r={12} fill={C.white} stroke={C.ink} strokeWidth={2} />
        <path d="M-52 -14 L 20 -8 Q 30 -6 28 0 L 30 2 L -50 2 Q -58 -2 -52 -14 Z" fill={C.ink} />
        {/* braço fletido */}
        <path d="M-40 -12 L -56 -32" stroke={C.ink} strokeWidth={5} strokeLinecap="round" />
        {/* perna fletida */}
        <path d="M18 -6 L 44 -22 L 58 -4" fill="none" stroke={C.ink} strokeWidth={5} strokeLinecap="round" />
      </g>
      <Label x={W / 2} y={60}>inconsciente mas a respirar</Label>
      <Label x={W / 2} y={76} size={9} color={C.inkSoft}>via aérea livre · drenagem pela boca</Label>
    </Frame>
  );
}

/** Parâmetros vitais */
export function Vitals() {
  return (
    <Frame sea={false}>
      {/* linha de ECG */}
      <path
        d="M30 100 L 70 100 L 82 70 L 96 128 L 108 88 L 116 100 L 150 100 L 162 70 L 176 128 L 188 88 L 196 100 L 230 100"
        fill="none"
        stroke={C.red}
        strokeWidth={2.6}
      />
      <Label x={56} y={152} size={10}>16–18 resp/min</Label>
      <Label x={160} y={172} size={10}>60–80 pulsações/min</Label>
      <Label x={252} y={152} size={10}>120/70</Label>
      {/* coração */}
      <path
        d="M252 84 C 240 68 218 76 218 92 C 218 108 252 122 252 122 C 252 122 286 108 286 92 C 286 76 264 68 252 84 Z"
        fill={C.red}
        stroke={C.ink}
        strokeWidth={1.6}
      />
    </Frame>
  );
}

/** Hemorragia: compressão direta */
export function Bleeding() {
  return (
    <Frame sea={false}>
      {/* braço */}
      <path d="M40 110 L 200 110 Q 214 110 214 124 Q 214 138 200 138 L 40 138 Z" fill={C.white} stroke={C.ink} strokeWidth={2} />
      {/* penso */}
      <rect x={110} y={96} width={52} height={20} rx={4} fill={C.white} stroke={C.red} strokeWidth={2.4} />
      {/* mão a comprimir */}
      <path d="M118 96 C 118 74 170 74 170 96" fill="none" stroke={C.ink} strokeWidth={7} strokeLinecap="round" />
      <Arrow x1={140} y1={58} x2={140} y2={76} color={C.red} />
      <Label x={W / 2} y={170} size={9} color={C.inkSoft}>compressão manual direta · pensos sucessivos</Label>
    </Frame>
  );
}

/** Tetraedro/triângulo do fogo */
export function FireTriangle() {
  const cx = 130, cy = 104;
  return (
    <Frame sea={false}>
      <path d={`M${cx} ${cy - 58} L ${cx - 62} ${cy + 46} L ${cx + 62} ${cy + 46} Z`} fill="#f6e7c9" stroke={C.ink} strokeWidth={2} />
      <Label x={cx} y={cy - 66} size={9}>Temperatura</Label>
      <Label x={cx - 64} y={cy + 62} size={9} anchor="middle">Combustível</Label>
      <Label x={cx + 64} y={cy + 62} size={9} anchor="middle">Comburente</Label>
      {/* chama */}
      <g transform={`translate(${cx} ${cy + 4})`}>
        <path d="M0 -22 C -12 -8 -10 6 0 14 C 10 6 12 -8 0 -22" fill={C.red} />
        <path d="M0 -10 C -6 -2 -5 6 0 10 C 5 6 6 -2 0 -10" fill={C.yellow} />
      </g>
      <Label x={cx} y={cy + 28} size={8} color={C.inkSoft}>+ reação em cadeia</Label>
      {/* método */}
      <Label x={252} y={80} size={9} anchor="middle">retirar 1 elemento</Label>
      <Label x={252} y={94} size={9} anchor="middle" color={C.red}>= fogo apagado</Label>
    </Frame>
  );
}

/** Métodos de extinção */
export function ExtinctionMethods() {
  const items = [
    { label: "Asfixia", draw: <path d="M0 -14 C -10 -2 -8 8 0 14 C 8 8 10 -2 0 -14" fill={C.red} /> },
    { label: "Abafamento", draw: <rect x={-14} y={-10} width={28} height={22} rx={3} fill={C.inkSoft} /> },
    { label: "Arrefec.", draw: <path d="M-8 -12 q 4 8 0 14 M0 -14 q 4 8 0 16 M8 -12 q 4 8 0 14" fill="none" stroke="#5b8fb0" strokeWidth={2.6} /> },
    { label: "Inibição", draw: <path d="M-12 -12 L 12 12 M-12 12 L 12 -12" stroke={C.red} strokeWidth={3} /> },
  ];
  return (
    <Frame sea={false}>
      {items.map((it, i) => (
        <g key={it.label} transform={`translate(${46 + i * 76} 92)`}>
          <circle cx={0} cy={0} r={26} fill={C.white} stroke={C.ink} strokeWidth={1.8} />
          {it.draw}
          <Label x={0} y={48} size={8}>{it.label}</Label>
        </g>
      ))}
      <Label x={W / 2} y={34} size={9} color={C.inkSoft}>4 métodos de extinção</Label>
    </Frame>
  );
}

/** Extintor de pó químico */
export function Extinguisher() {
  return (
    <Frame sea={false}>
      <g transform="translate(120 104)">
        <rect x={-18} y={-40} width={36} height={76} rx={14} fill={C.red} stroke={C.ink} strokeWidth={2} />
        <rect x={-6} y={-56} width={12} height={18} fill={C.ink} />
        <path d="M6 -50 L 30 -58 L 34 -48 L 10 -42" fill={C.ink} />
        <rect x={-14} y={-18} width={28} height={22} fill={C.white} stroke={C.ink} strokeWidth={1.4} />
        <Label x={0} y={-3} size={8}>PÓ</Label>
      </g>
      {/* jato para a base das chamas */}
      <path d="M154 76 L 196 108" stroke={C.grey} strokeWidth={3} strokeDasharray="4 3" />
      <g transform="translate(212 128)">
        <path d="M0 -20 C -11 -8 -9 6 0 13 C 9 6 11 -8 0 -20" fill={C.red} />
        <path d="M0 -8 C -5 -1 -4 6 0 9 C 4 6 5 -1 0 -8" fill={C.yellow} />
      </g>
      <Label x={W / 2} y={176} size={9} color={C.inkSoft}>disparos curtos · apontar à base das chamas</Label>
    </Frame>
  );
}

export { WindArrow };
