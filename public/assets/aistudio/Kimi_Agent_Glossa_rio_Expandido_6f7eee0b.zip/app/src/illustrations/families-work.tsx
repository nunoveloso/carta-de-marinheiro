import { Arrow, BoatSide, BoatTop, C, CurveArrow, Frame, H, Label, Person, SailboatSide, Sun, W } from "./shared";

/* ══════════════════════ CABOS ══════════════════════ */

function Rope({ d, color = C.ink, width = 4, dash }: { d: string; color?: string; width?: number; dash?: string }) {
  return <path d={d} fill="none" stroke={color} strokeWidth={width} strokeLinecap="round" strokeDasharray={dash} />;
}

export function RopeThing({ type }: { type: string }) {
  if (type === "bitola") {
    return (
      <Frame sea={false}>
        <circle cx={160} cy={92} r={38} fill={C.ink} opacity={0.14} />
        <circle cx={160} cy={92} r={38} fill="none" stroke={C.ink} strokeWidth={3} />
        {/* tranças */}
        {[0, 60, 120, 180, 240, 300].map((a) => (
          <circle key={a} cx={160 + 24 * Math.cos((a * Math.PI) / 180)} cy={92 + 24 * Math.sin((a * Math.PI) / 180)} r={11} fill="none" stroke={C.inkSoft} strokeWidth={1.6} />
        ))}
        <path d="M160 92 m -38 0 a 38 38 0 1 0 76 0 a 38 38 0 1 0 -76 0" fill="none" stroke={C.red} strokeWidth={3} strokeDasharray="6 5" transform="translate(0 -0.5)" />
        <Label x={160} y={152} color={C.red}>bitola = perímetro da secção</Label>
        <Label x={160} y={172} size={8.5} color={C.inkSoft}>com o material, identifica o cabo</Label>
      </Frame>
    );
  }
  if (type === "sarilho") {
    return (
      <Frame sea={false}>
        <rect x={96} y={46} width={128} height={14} rx={6} fill={C.ink} />
        <rect x={104} y={60} width={112} height={88} rx={8} fill="none" stroke={C.ink} strokeWidth={3} />
        {[74, 92, 110, 128].map((y) => (
          <path key={y} d={`M104 ${y} q 56 10 112 0`} fill="none" stroke={C.inkSoft} strokeWidth={3.4} />
        ))}
        <rect x={96} y={140} width={128} height={14} rx={6} fill={C.ink} />
        <Label x={160} y={176}>sarilho — cabos solteiros arrumados</Label>
      </Frame>
    );
  }
  if (type === "cocas") {
    return (
      <Frame sea={false}>
        <Rope d="M30 100 C 70 92 90 108 118 100" />
        <path d="M118 100 c 8 -12 22 -10 22 2 c 0 12 -16 14 -20 4 c -4 -10 8 -18 16 -12" fill="none" stroke={C.red} strokeWidth={4} strokeLinecap="round" />
        <Rope d="M160 104 C 190 112 200 96 226 102" />
        <path d="M226 102 c 6 -10 20 -8 18 4 c -2 10 -16 10 -18 0" fill="none" stroke={C.red} strokeWidth={4} strokeLinecap="round" />
        <Rope d="M248 104 C 268 108 282 100 296 102" />
        <Label x={160} y={66} color={C.red}>cocas — torções no cabo</Label>
        <Label x={160} y={150} size={8.5} color={C.inkSoft}>prejudicam a boa utilização</Label>
      </Frame>
    );
  }
  if (type === "colher") {
    return (
      <Frame sea={false}>
        {/* padeiro */}
        {[0, 1, 2].map((i) => (
          <ellipse key={i} cx={86} cy={96} rx={34 - i * 8} ry={34 - i * 8} fill="none" stroke={C.ink} strokeWidth={3.4} />
        ))}
        <Label x={86} y={152} size={9}>padeiro</Label>
        {/* aduchas */}
        {[0, 1, 2].map((i) => (
          <ellipse key={i} cx={228} cy={96} rx={40} ry={16 + i * 10} fill="none" stroke={C.inkSoft} strokeWidth={3.4} transform={`translate(0 ${-i * 0})`} />
        ))}
        <Label x={228} y={152} size={9}>aduchas</Label>
        <Label x={160} y={182} size={8.5} color={C.inkSoft}>colhido sem cocas, claro</Label>
      </Frame>
    );
  }
  if (type === "retenida") {
    return (
      <Frame>
        <BoatSide x={80} />
        {/* punho pesado */}
        <circle cx={238} cy={86} r={12} fill="none" stroke={C.ink} strokeWidth={3.4} />
        <path d="M230 78 a 12 12 0 0 1 16 0 M228 86 a 12 12 0 0 1 24 0 M230 94 a 12 12 0 0 1 16 0" stroke={C.ink} strokeWidth={2} fill="none" />
        <path d="M226 92 C 190 108 160 118 120 128" fill="none" stroke={C.red} strokeWidth={2.8} strokeDasharray="6 4" />
        <Arrow x1={212} y1={82} x2={238} y2={74} color={C.inkSoft} width={1.8} />
        <Label x={212} y={64} size={8.5} color={C.inkSoft}>arremesso</Label>
        <Label x={160} y={176} size={9}>retenida — puxa o cabo de amarração</Label>
      </Frame>
    );
  }
  if (type === "solteiros") {
    return (
      <Frame sea={false}>
        {/* fixos: brandais do mastro */}
        <line x1={86} y1={40} x2={86} y2={150} stroke={C.ink} strokeWidth={4} />
        <path d="M86 48 L 50 150 M86 48 L 122 150" stroke={C.red} strokeWidth={2.8} />
        <Label x={86} y={170} size={9} color={C.red}>fixos (sustentam o mastro)</Label>
        {/* solteiros: cabo enrolado */}
        {[0, 1, 2].map((i) => (
          <ellipse key={i} cx={222} cy={96} rx={32 - i * 8} ry={32 - i * 8} fill="none" stroke={C.ink} strokeWidth={3.2} />
        ))}
        <path d="M254 96 q 20 4 18 22" fill="none" stroke={C.ink} strokeWidth={3.2} />
        <Label x={222} y={170} size={9}>solteiros (prontos a usar)</Label>
      </Frame>
    );
  }
  if (type === "boca") {
    return (
      <Frame>
        <BoatTop x={130} y={96} scale={1.05} />
        {/* arganéu de proa */}
        <circle cx={130} cy={58} r={6} fill="none" stroke={C.red} strokeWidth={3} />
        <Rope d="M130 58 C 150 44 190 40 234 44" color={C.red} width={3.4} />
        <Label x={212} y={34} size={9} color={C.red}>boça</Label>
        <Label x={130} y={160} size={8.5} color={C.inkSoft}>amarrar ou rebocar pela proa</Label>
      </Frame>
    );
  }
  if (type === "adrica") {
    return (
      <Frame>
        <SailboatSide x={120} scale={1.1} />
        <path d="M118 76 L 118 24 L 92 24" fill="none" stroke={C.red} strokeWidth={2.8} strokeDasharray="6 4" />
        <Arrow x1={118} y1={48} x2={118} y2={26} color={C.red} width={2.2} />
        <Label x={212} y={60} size={9} color={C.red}>adriça</Label>
        <Label x={160} y={176} size={8.5} color={C.inkSoft}>iça a vela pelo mastro acima</Label>
      </Frame>
    );
  }
  // arinque
  return (
    <Frame>
      {/* bóia de arinque */}
      <circle cx={120} cy={140} r={10} fill={C.red} stroke={C.ink} strokeWidth={1.6} />
      <rect x={0} y={164} width={W} height={36} fill={C.sand} />
      <path d="M120 150 C 140 158 160 164 176 168" fill="none" stroke={C.ink} strokeWidth={2.6} strokeDasharray="5 4" />
      <g transform="translate(184 168) scale(0.5)" fill={C.ink}>
        <rect x={-4} y={-30} width={8} height={42} />
        <path d="M0 6 C -26 6 -34 -10 -32 -22 L -20 -14 C -22 -4 -16 0 -4 2 Z" />
        <path d="M0 6 C 26 6 34 -10 32 -22 L 20 -14 C 22 -4 16 0 4 2 Z" />
      </g>
      <Label x={120} y={122} size={9}>bóia de arinque</Label>
      <Label x={160} y={192} size={8.5} color={C.inkSoft}>o arinque liga a bóia ao anete do ferro</Label>
    </Frame>
  );
}

/* ══════════════════════ NÓS E VOLTAS ══════════════════════ */

export function KnotThing({ type }: { type: string }) {
  if (type === "no-direito") {
    return (
      <Frame sea={false}>
        {/* dois cabos, dois cruzamentos alternados */}
        <path d="M40 84 C 90 84 110 84 150 84" fill="none" stroke={C.ink} strokeWidth={5} strokeLinecap="round" />
        <path d="M150 84 c 14 0 16 10 8 14 c -10 5 -18 -2 -12 -10" fill="none" stroke={C.ink} strokeWidth={5} strokeLinecap="round" />
        <path d="M280 100 C 230 100 210 100 172 100" fill="none" stroke={C.red} strokeWidth={5} strokeLinecap="round" />
        <path d="M172 100 c -14 0 -16 -10 -8 -14 c 10 -5 18 2 12 10" fill="none" stroke={C.red} strokeWidth={5} strokeLinecap="round" />
        <path d="M40 100 L 136 100" stroke={C.ink} strokeWidth={5} strokeLinecap="round" />
        <path d="M186 84 L 280 84" stroke={C.red} strokeWidth={5} strokeLinecap="round" />
        <Label x={160} y={50}>nó direito</Label>
        <Label x={160} y={152} size={8.5} color={C.inkSoft}>liga dois cabos da mesma bitola</Label>
      </Frame>
    );
  }
  if (type === "no-de-escota") {
    return (
      <Frame sea={false}>
        {/* gaza do cabo grosso */}
        <path d="M70 118 C 70 92 96 78 122 84 C 148 90 150 112 128 118 C 110 123 92 120 84 112" fill="none" stroke={C.ink} strokeWidth={6} strokeLinecap="round" />
        <path d="M70 118 L 40 118" stroke={C.ink} strokeWidth={6} strokeLinecap="round" />
        {/* cabo fino que passa pela gaza */}
        <path d="M250 78 C 190 78 150 84 128 96 C 112 104 112 114 128 118" fill="none" stroke={C.red} strokeWidth={3.6} strokeLinecap="round" />
        <path d="M128 118 C 160 126 210 128 250 128" fill="none" stroke={C.red} strokeWidth={3.6} strokeLinecap="round" />
        <Label x={160} y={50}>nó de escota</Label>
        <Label x={160} y={158} size={8.5} color={C.inkSoft}>une cabos de bitolas diferentes</Label>
      </Frame>
    );
  }
  if (type === "volta-de-fiel") {
    return (
      <Frame sea={false}>
        <rect x={146} y={40} width={28} height={124} rx={6} fill={C.inkSoft} />
        <path d="M120 96 L 200 76 M120 76 L 200 96" stroke={C.ink} strokeWidth={4.6} strokeLinecap="round" />
        <path d="M120 96 L 200 76" stroke={C.ink} strokeWidth={4.6} strokeLinecap="round" />
        <path d="M120 76 C 90 72 66 76 44 84" fill="none" stroke={C.ink} strokeWidth={4.6} strokeLinecap="round" />
        <path d="M200 96 C 224 100 244 104 262 112" fill="none" stroke={C.ink} strokeWidth={4.6} strokeLinecap="round" />
        <Label x={160} y={188} size={8.5} color={C.inkSoft}>amarrar a um pau ou cabo grosso</Label>
        <Label x={160} y={30}>volta de fiel</Label>
      </Frame>
    );
  }
  if (type === "voltas-falidas") {
    return (
      <Frame sea={false}>
        {/* cabeço duplo */}
        <rect x={128} y={86} width={22} height={56} rx={8} fill={C.inkSoft} />
        <rect x={170} y={86} width={22} height={56} rx={8} fill={C.inkSoft} />
        <rect x={118} y={134} width={84} height={12} rx={5} fill={C.ink} />
        {/* voltas em oito */}
        <path d="M96 104 C 128 96 140 100 139 108 C 138 116 118 116 110 112 M110 112 C 150 122 176 118 192 108 C 200 102 192 94 176 96 C 150 99 120 104 96 104" fill="none" stroke={C.ink} strokeWidth={4} strokeLinecap="round" />
        <path d="M96 104 C 80 106 66 104 52 98" fill="none" stroke={C.ink} strokeWidth={4} strokeLinecap="round" />
        <Label x={160} y={52}>voltas falidas</Label>
        <Label x={160} y={176} size={8.5} color={C.inkSoft}>fixar um cabo num cabeço duplo</Label>
      </Frame>
    );
  }
  // volta de anete
  return (
    <Frame sea={false}>
      <circle cx={130} cy={96} r={30} fill="none" stroke={C.ink} strokeWidth={5} />
      <path d="M160 96 C 190 96 210 92 236 90" fill="none" stroke={C.red} strokeWidth={4.4} strokeLinecap="round" />
      <path d="M172 96 c 10 -10 22 -8 22 2 c 0 10 -14 12 -18 4" fill="none" stroke={C.red} strokeWidth={4.4} strokeLinecap="round" />
      <path d="M186 92 c 10 -10 22 -8 22 2 c 0 10 -14 12 -18 4" fill="none" stroke={C.red} strokeWidth={4.4} strokeLinecap="round" />
      <Label x={130} y={100} size={9} color={C.inkSoft}>anete</Label>
      <Label x={160} y={44}>volta de anete</Label>
      <Label x={160} y={158} size={8.5} color={C.inkSoft}>liga o chicote ao anete da âncora ou da bóia</Label>
    </Frame>
  );
}

/* ══════════════════════ MANOBRAS ══════════════════════ */

export function ManobraThing({ type }: { type: string }) {
  if (type === "rotacao") {
    return (
      <Frame>
        <BoatSide x={96} y={120} scale={0.9} />
        <Person x={242} y={128} scale={0.8} color={C.red} />
        <circle cx={176} cy={112} r={58} fill="none" stroke={C.red} strokeWidth={2.4} strokeDasharray="7 5" />
        <Arrow x1={176 - 58} y1={106} x2={176 - 56} y2={96} color={C.red} />
        <Label x={176} y={48} size={9} color={C.red}>rotação 360°</Label>
        <Label x={242} y={156} size={8.5} color={C.inkSoft}>vítima</Label>
        <Label x={96} y={170} size={8.5} color={C.inkSoft}>leme todo ao bordo da queda</Label>
      </Frame>
    );
  }
  if (type === "cabeco") {
    return (
      <Frame>
        <rect x={0} y={36} width={W} height={60} fill={C.sand} />
        <Label x={20} y={30} anchor="start" size={9} color={C.inkSoft}>cais</Label>
        {/* cabeço */}
        <path d="M120 78 h80 l-10 22 h-60 Z" fill={C.ink} />
        <rect x={150} y={58} width={20} height={26} rx={7} fill={C.ink} />
        {/* cabos em espia, separados */}
        <path d="M160 84 C 130 110 110 130 84 150" fill="none" stroke={C.green} strokeWidth={3.6} />
        <path d="M160 84 C 190 112 212 132 240 150" fill="none" stroke={C.red} strokeWidth={3.6} strokeDasharray="7 5" />
        <Label x={160} y={124} size={9}>cabeço</Label>
        <Label x={160} y={176} size={8.5} color={C.inkSoft}>qualquer cabo sai sem mexer nos outros</Label>
      </Frame>
    );
  }
  if (type === "cunho") {
    return (
      <Frame sea={false}>
        <rect x={118} y={120} width={84} height={14} rx={5} fill={C.ink} />
        <rect x={136} y={60} width={20} height={66} rx={7} fill={C.inkSoft} />
        <rect x={164} y={60} width={20} height={66} rx={7} fill={C.inkSoft} />
        <path d="M92 88 C 130 78 150 82 148 92 C 146 102 120 100 108 96 M108 96 C 150 106 176 100 196 92 C 206 88 200 78 184 80 C 150 84 120 88 92 88" fill="none" stroke={C.red} strokeWidth={4} strokeLinecap="round" />
        <path d="M92 88 C 72 90 58 88 44 82" fill="none" stroke={C.red} strokeWidth={4} strokeLinecap="round" />
        <Label x={160} y={44}>cunho (bita)</Label>
        <Label x={160} y={160} size={8.5} color={C.inkSoft}>a volta de cunho segura grandes esforços</Label>
      </Frame>
    );
  }
  if (type === "corrente") {
    return (
      <Frame>
        <rect x={0} y={0} width={W} height={56} fill={C.sand} />
        <Label x={16} y={26} anchor="start" size={9} color={C.inkSoft}>cais</Label>
        {/* corrente a favor do cais → contra a proa */}
        {[0, 1].map((i) => (
          <Arrow key={i} x1={60} y1={92 + i * 30} x2={180} y2={92 + i * 30} color={C.seaLine} width={3} />
        ))}
        <Label x={70} y={140} size={8.5} color={C.inkSoft}>corrente</Label>
        <g transform="translate(232 96) rotate(180)">
          <path d="M-38 0 L -31 -12 L 30 -12 L 38 0 C 25 5 -25 5 -38 0 Z" fill={C.ink} />
        </g>
        <Arrow x1={252} y1={116} x2={252} y2={86} color={C.red} width={2.2} />
        <Label x={232} y={140} size={8.5} color={C.red}>proa contra a corrente</Label>
      </Frame>
    );
  }
  if (type === "largar") {
    return (
      <Frame>
        <rect x={0} y={0} width={W} height={56} fill={C.sand} />
        <Label x={16} y={26} anchor="start" size={9} color={C.inkSoft}>cais</Label>
        <Arrow x1={120} y1={8} x2={130} y2={66} color={C.inkSoft} />
        <Label x={98} y={16} size={8.5} color={C.inkSoft}>vento contra o cais</Label>
        <BoatTop x={160} y={110} rotate={90} />
        <circle cx={216} cy={66} r={5} fill={C.ink} />
        <path d="M200 74 C 210 72 214 70 216 66" fill="none" stroke={C.green} strokeWidth={3.2} />
        <Label x={238} y={96} size={8.5} color={C.green}>traseira de vante (mola)</Label>
        <CurveArrow cx={160} cy={110} r={34} from={2.2} to={3.5} color={C.red} />
        <Label x={160} y={164} size={8.5} color={C.inkSoft}>a popa abre antes de sair</Label>
      </Frame>
    );
  }
  if (type === "roda" || type === "devante") {
    const isRoda = type === "roda";
    return (
      <Frame>
        <Arrow x1={160} y1={26} x2={160} y2={60} color={C.inkSoft} width={2.2} />
        <Label x={160} y={20} size={8.5} color={C.inkSoft}>vento</Label>
        <SailboatSide x={isRoda ? 96 : 96} y={150} scale={0.8} flip={isRoda} />
        <SailboatSide x={240} y={150} scale={0.8} flip={!isRoda} />
        {isRoda ? (
          <path d="M96 118 C 140 96 200 96 240 118" fill="none" stroke={C.red} strokeWidth={2.4} strokeDasharray="6 4" />
        ) : (
          <path d="M96 118 C 130 70 190 70 240 118" fill="none" stroke={C.red} strokeWidth={2.4} strokeDasharray="6 4" />
        )}
        <Label x={160} y={isRoda ? 104 : 66} size={9} color={C.red}>
          {isRoda ? "popa atravessa o vento" : "proa atravessa o vento"}
        </Label>
        <Label x={96} y={182} size={8.5} color={C.inkSoft}>antes</Label>
        <Label x={240} y={182} size={8.5} color={C.inkSoft}>depois</Label>
      </Frame>
    );
  }
  return <Frame sea={false}>{null}</Frame>;
}

/* ══════════════════════ R.I.E.A.M. ══════════════════════ */

function ShapeStack({ shapes, x = 160, y = 96 }: { shapes: ("ball" | "bicone" | "cyl")[]; x?: number; y?: number }) {
  return (
    <g transform={`translate(${x} ${y})`} fill={C.black}>
      {shapes.map((s, i) => {
        const cy = -((shapes.length - 1) * 16) + i * 32;
        if (s === "ball") return <circle key={i} cx={0} cy={cy} r={11} />;
        if (s === "cyl") return <rect key={i} x={-9} y={cy - 12} width={18} height={24} rx={3} />;
        return (
          <g key={i}>
            {/* bicónico: cone de cima com o vértice para baixo, cone de baixo
                com o vértice para cima — as pontas tocam-se */}
            <path d={`M-11 ${cy - 10} L 0 ${cy} L 11 ${cy - 10} Z`} />
            <path d={`M-11 ${cy + 10} L 0 ${cy} L 11 ${cy + 10} Z`} />
          </g>
        );
      })}
      <line x1={0} y1={-((shapes.length - 1) * 16) - 34} x2={0} y2={-((shapes.length - 1) * 16) - 12} stroke={C.ink} strokeWidth={2.4} />
    </g>
  );
}

export function RieamThing({ type }: { type: string }) {
  if (type === "navio") {
    return (
      <Frame>
        <BoatSide x={86} scale={1} />
        <SailboatSide x={230} scale={0.9} />
        {/* mota de água */}
        <g transform="translate(160 154)">
          <path d="M-18 0 q 4 -10 14 -10 q 14 0 22 6 l -4 6 q -16 4 -32 -2 Z" fill={C.ink} />
          <line x1={-2} y1={-10} x2={6} y2={-18} stroke={C.ink} strokeWidth={2.6} />
        </g>
        <Label x={160} y={52}>«navio» = todo o engenho na água</Label>
        <Label x={160} y={184} size={8.5} color={C.inkSoft}>inclui as embarcações de recreio e as motas de água</Label>
      </Frame>
    );
  }
  if (type === "vela") {
    return (
      <Frame>
        <SailboatSide x={120} scale={1.15} />
        <g transform="translate(238 148)">
          <path d="M-34 0 L -28 -10 L 26 -10 L 34 0 C 22 5 -22 5 -34 0 Z" fill={C.inkSoft} />
          <rect x={-8} y={-20} width={6} height={12} fill={C.inkSoft} />
          <line x1={28} y1={-4} x2={40} y2={-4} stroke={C.red} strokeWidth={2.6} />
        </g>
        <Label x={120} y={52} size={9}>à vela: exclusivamente à vela</Label>
        <Label x={232} y={120} size={8.5} color={C.red}>com motor = propulsão mecânica</Label>
      </Frame>
    );
  }
  if (type === "arrancada") {
    return (
      <Frame>
        <BoatSide x={88} y={118} />
        <path d="M34 130 q 10 6 22 2 M30 140 q 12 7 26 3" stroke={C.seaLine} strokeWidth={2.4} fill="none" />
        <Label x={88} y={86} size={9}>com arrancada</Label>
        <BoatSide x={232} y={118} fill={C.inkSoft} />
        <Label x={232} y={86} size={9}>sem arrancada</Label>
        <Label x={160} y={176} size={8.5} color={C.inkSoft}>velocidade em relação à água — ou não</Label>
      </Frame>
    );
  }
  if (type === "vante-a-vante") {
    return (
      <Frame sea={false}>
        <rect x={0} y={96} width={W} height={104} fill={C.sea} opacity={0.55} />
        <BoatTop x={120} y={66} rotate={0} />
        <BoatTop x={120} y={150} rotate={180} />
        <CurveArrow cx={120} cy={66} r={26} from={Math.PI * 0.8} to={Math.PI * 0.05} color={C.green} />
        <CurveArrow cx={120} cy={150} r={26} from={-Math.PI * 0.2} to={Math.PI * 0.55} color={C.green} />
        <Label x={196} y={62} size={9} color={C.green}>cada uma altera a EB</Label>
        <Label x={196} y={162} size={9} color={C.inkSoft}>passagem BB com BB</Label>
        <Label x={120} y={110} size={9} color={C.red}>1 som curto</Label>
      </Frame>
    );
  }
  if (type === "cruzamento") {
    return (
      <Frame sea={false}>
        <rect x={0} y={96} width={W} height={104} fill={C.sea} opacity={0.55} />
        <BoatTop x={110} y={66} />
        <BoatTop x={196} y={150} rotate={-90} />
        <path d="M110 92 L 110 176" stroke={C.inkSoft} strokeWidth={2} strokeDasharray="5 4" />
        <path d="M170 150 L 60 150" stroke={C.inkSoft} strokeWidth={2} strokeDasharray="5 4" />
        <circle cx={110} cy={150} r={6} fill="none" stroke={C.red} strokeWidth={2.4} />
        <Label x={110} y={44} size={8.5} color={C.inkSoft}>mantém rumo e velocidade</Label>
        <Label x={220} y={138} size={8.5} color={C.red}>mantém-se afastada</Label>
        <Label x={220} y={154} size={8.5} color={C.red}>(tem a outra por EB)</Label>
      </Frame>
    );
  }
  if (type === "alcancada") {
    return (
      <Frame sea={false}>
        <rect x={0} y={96} width={W} height={104} fill={C.sea} opacity={0.55} />
        <BoatTop x={160} y={64} />
        <BoatTop x={160} y={152} fill={C.inkSoft} />
        <Arrow x1={160} y1={124} x2={160} y2={104} color={C.red} width={2} />
        <Label x={160} y={36} size={8.5} color={C.inkSoft}>alcançada: mantém rumo e velocidade</Label>
        <Label x={160} y={188} size={8.5} color={C.red}>alcançante: mantém-se afastada</Label>
      </Frame>
    );
  }
  if (type === "pesca") {
    return (
      <Frame>
        <ShapeStack shapes={["bicone", "bicone"]} x={130} y={110} />
        <BoatSide x={130} y={170} scale={0.9} />
        <Label x={212} y={80} size={9}>2 bicónicos unidos</Label>
        <Label x={212} y={96} size={9}>pelos vértices</Label>
        <Label x={160} y={192} size={8.5} color={C.inkSoft}>embarcação engajada na pesca — de dia</Label>
      </Frame>
    );
  }
  if (type === "cilindro") {
    return (
      <Frame>
        <ShapeStack shapes={["cyl"]} x={130} y={104} />
        <BoatSide x={130} y={170} scale={0.9} />
        <Label x={200} y={70} size={9}>balão cilíndrico</Label>
        <Label x={160} y={192} size={8.5} color={C.inkSoft}>navio condicionado pelo seu calado</Label>
      </Frame>
    );
  }
  if (type === "cinco-sons") {
    return (
      <Frame sea={false}>
        {/* apito */}
        <g transform="translate(70 96)">
          <rect x={-26} y={-10} width={52} height={20} rx={8} fill={C.ink} />
          <rect x={-6} y={-22} width={12} height={14} fill={C.ink} />
        </g>
        {[0, 1, 2, 3, 4].map((i) => (
          <g key={i} transform={`translate(${124 + i * 34} 96)`}>
            <path d="M0 0 q 7 -12 14 0" fill="none" stroke={C.red} strokeWidth={3} />
            <path d="M2 14 q 5 -8 10 0" fill="none" stroke={C.red} strokeWidth={2.2} />
          </g>
        ))}
        <Label x={160} y={54}>cinco sons curtos e rápidos</Label>
        <Label x={160} y={140} size={9} color={C.red}>dúvida ou perigo</Label>
        <Label x={160} y={162} size={8.5} color={C.inkSoft}>pode repetir-se com 5 clarões de luz</Label>
      </Frame>
    );
  }
  // nevoeiro
  return (
    <Frame sea={false}>
      {[66, 86, 106].map((y, i) => (
        <path key={y} d={`M20 ${y} q 20 -10 40 0 t 40 0 t 40 0 t 40 0 t 40 0 t 40 0 t 40 0`} fill="none" stroke={C.grey} strokeWidth={3.4} opacity={0.75 - i * 0.15} />
      ))}
      <BoatSide x={160} y={140} scale={0.95} />
      <g transform="translate(214 96)">
        <path d="M0 0 q 10 -16 20 0" fill="none" stroke={C.ink} strokeWidth={3} />
        <path d="M26 0 q 14 -20 28 0" fill="none" stroke={C.inkSoft} strokeWidth={3} />
      </g>
      <Label x={160} y={36}>visibilidade reduzida</Label>
      <Label x={160} y={172} size={9}>1 prolongado / 2 min (com arrancada)</Label>
      <Label x={160} y={188} size={8.5} color={C.inkSoft}>2 prolongados / 2 min (parada)</Label>
    </Frame>
  );
}

/* ══════════════════════ SEGURANÇA ══════════════════════ */

export function SafetyThing({ type }: { type: string }) {
  if (type === "checklist") {
    const items = ["flutuabilidade", "motor arejado", "palamenta", "meios de salvação", "sinais de socorro", "VHF + agulha", "ferro e cabos", "extintor"];
    return (
      <Frame sea={false}>
        <rect x={70} y={30} width={180} height={146} rx={4} fill={C.white} stroke={C.ink} strokeWidth={2} />
        {items.map((t, i) => (
          <g key={t}>
            <rect x={84} y={44 + i * 16} width={9} height={9} fill="none" stroke={C.ink} strokeWidth={1.4} />
            <path d={`M85.5 ${48.5 + i * 16} l 2.4 2.6 l 4 -5`} fill="none" stroke={C.green} strokeWidth={1.8} />
            <Label x={100} y={52.5 + i * 16} size={8.5} anchor="start" color={C.ink}>{t}</Label>
          </g>
        ))}
        <Label x={160} y={24} size={9} color={C.inkSoft}>antes de sair</Label>
      </Frame>
    );
  }
  // acompanhado
  return (
    <Frame>
      <BoatSide x={100} />
      <BoatSide x={222} scale={0.85} fill={C.inkSoft} />
      <path d="M150 132 q 20 10 40 0" fill="none" stroke={C.seaLine} strokeWidth={2.2} strokeDasharray="4 4" />
      <Label x={160} y={70} size={9}>à vista uns dos outros</Label>
      <Label x={160} y={182} size={8.5} color={C.inkSoft}>e avisar em terra: saída e destino</Label>
    </Frame>
  );
}

/* ══════════════════════ PRIMEIROS SOCORROS ══════════════════════ */

export function AidThing({ type }: { type: string }) {
  if (type === "boia-retenida") {
    return (
      <Frame>
        <circle cx={210} cy={110} r={26} fill="none" stroke={C.red} strokeWidth={12} />
        <circle cx={210} cy={110} r={26} fill="none" stroke={C.white} strokeWidth={12} strokeDasharray="20 20" />
        <path d="M188 92 C 150 84 120 90 96 104" fill="none" stroke={C.ink} strokeWidth={2.8} />
        <BoatSide x={76} y={128} scale={0.8} />
        <Label x={210} y={152} size={9} color={C.red}>retenida</Label>
        <Label x={160} y={182} size={8.5} color={C.inkSoft}>arremesso certeiro e recuperação</Label>
      </Frame>
    );
  }
  if (type === "boia-luz") {
    return (
      <Frame sea={false}>
        <rect x={0} y={0} width={W} height={H} fill={C.ink} opacity={0.92} />
        <rect x={0} y={118} width={W} height={82} fill={C.ink} />
        <circle cx={160} cy={104} r={26} fill="none" stroke={C.red} strokeWidth={12} />
        <circle cx={160} cy={104} r={26} fill="none" stroke={C.white} strokeWidth={12} strokeDasharray="20 20" />
        {/* luz */}
        <circle cx={160} cy={66} r={7} fill={C.yellow} />
        {[0, 60, 120, 180, 240, 300].map((a) => (
          <line key={a} x1={160 + 12 * Math.cos((a * Math.PI) / 180)} y1={66 + 12 * Math.sin((a * Math.PI) / 180)} x2={160 + 20 * Math.cos((a * Math.PI) / 180)} y2={66 + 20 * Math.sin((a * Math.PI) / 180)} stroke={C.yellow} strokeWidth={2.4} />
        ))}
        <Label x={160} y={160} size={9} color={C.yellow}>luz de ignição automática</Label>
        <Label x={160} y={180} size={8.5} color={C.white}>assinala a posição durante a noite</Label>
      </Frame>
    );
  }
  if (type === "rcp") {
    return (
      <Frame sea={false}>
        {/* vítima deitada */}
        <g transform="translate(150 120)">
          <ellipse cx={20} cy={26} rx={86} ry={10} fill={C.sea} />
          <circle cx={-58} cy={8} r={11} fill={C.inkSoft} />
          <path d="M-46 8 L 40 8 L 44 22 L -42 22 Z" fill={C.inkSoft} />
        </g>
        {/* mãos sobre o peito */}
        <Arrow x1={140} y1={58} x2={140} y2={112} color={C.red} width={3} />
        <Arrow x1={140} y1={112} x2={140} y2={70} color={C.green} width={2} />
        <rect x={126} y={106} width={28} height={10} rx={4} fill={C.red} />
        <Label x={196} y={80} size={9} color={C.red}>compressões torácicas</Label>
        <Label x={160} y={178} size={8.5} color={C.inkSoft}>+ insuflações · vítima sem respiração nem pulso</Label>
      </Frame>
    );
  }
  if (type === "compressao") {
    return (
      <Frame sea={false}>
        {/* braço */}
        <path d="M60 96 C 110 84 190 84 260 92" fill="none" stroke={C.ink} strokeWidth={16} strokeLinecap="round" />
        {/* ferida + penso */}
        <rect x={146} y={76} width={34} height={22} rx={4} fill={C.white} stroke={C.red} strokeWidth={2.4} />
        <Arrow x1={163} y1={44} x2={163} y2={70} color={C.red} width={3} />
        <Label x={163} y={36} size={9} color={C.red}>compressão manual direta</Label>
        <Label x={160} y={140} size={8.5} color={C.inkSoft}>penso improvisado + pensos sucessivos</Label>
        <Label x={160} y={160} size={8.5} color={C.inkSoft}>chamar o 112</Label>
      </Frame>
    );
  }
  // queimaduras
  return (
    <Frame sea={false}>
      {/* mão sob água corrente */}
      <path d="M110 130 C 120 104 150 96 176 100 L 172 112 C 150 110 132 116 124 132 Z" fill={C.inkSoft} />
      <path d="M196 40 C 190 66 188 84 186 100 M206 44 C 202 68 200 84 198 98" stroke={C.seaLine} strokeWidth={3.4} fill="none" />
      <Label x={238} y={50} size={9} color={C.inkSoft}>água corrente</Label>
      <Label x={160} y={166} size={9}>queimaduras</Label>
      <Label x={160} y={184} size={8.5} color={C.inkSoft}>nos olhos: lavar demoradamente · 112</Label>
    </Frame>
  );
}

/* ══════════════════════ INCÊNDIO ══════════════════════ */

function Triangle({ highlight }: { highlight?: "combustivel" | "comburente" | "ignicao" }) {
  const col = (p: string) => (highlight === p ? C.red : C.ink);
  return (
    <g>
      <path d="M160 44 L 96 148 L 224 148 Z" fill="none" stroke={C.ink} strokeWidth={2.4} />
      <Label x={160} y={38} color={col("ignicao")}>temperatura de ignição</Label>
      <Label x={70} y={162} color={col("combustivel")} anchor="middle">combustível</Label>
      <Label x={250} y={162} color={col("comburente")} anchor="middle">comburente</Label>
      {/* chama */}
      <path d="M160 112 c -10 -14 6 -18 2 -32 c 12 8 16 20 8 30 c 6 -2 8 -6 9 -10 c 4 10 -2 22 -19 22 c -12 0 -18 -8 -14 -18 c 3 6 8 8 14 8 Z" fill={C.red} opacity={highlight ? 0.45 : 1} />
    </g>
  );
}

export function FirePart({ part }: { part: string }) {
  if (part === "combustivel" || part === "comburente" || part === "ignicao") {
    return (
      <Frame sea={false}>
        <Triangle highlight={part} />
        <Label x={160} y={188} size={8.5} color={C.inkSoft}>eliminar um dos três extingue o fogo</Label>
      </Frame>
    );
  }
  if (part === "cobertor") {
    return (
      <Frame sea={false}>
        {/* fogão */}
        <rect x={106} y={118} width={108} height={40} rx={4} fill={C.ink} />
        <circle cx={138} cy={118} r={10} fill="none" stroke={C.ink} strokeWidth={3} />
        {/* manta a cobrir */}
        <path d="M108 118 C 120 92 200 92 212 118 L 212 132 C 190 122 130 122 108 132 Z" fill={C.red} opacity={0.85} />
        <Label x={160} y={66} size={9} color={C.red}>manta antifogo junto ao fogão</Label>
        <Label x={160} y={180} size={8.5} color={C.inkSoft}>abafa inflamações de gordura — nunca água</Label>
      </Frame>
    );
  }
  // agua
  return (
    <Frame sea={false}>
      {/* quadro elétrico + água riscada */}
      <rect x={76} y={60} width={64} height={84} rx={6} fill={C.ink} />
      <path d="M116 76 L 100 104 h 12 L 104 128" fill="none" stroke={C.yellow} strokeWidth={3.4} />
      {[0, 1, 2].map((i) => (
        <path key={i} d={`M${190 + i * 22} 76 q 5 8 0 12 q -5 -4 0 -12`} fill={C.seaLine} />
      ))}
      <line x1={170} y1={58} x2={258} y2={138} stroke={C.red} strokeWidth={4} />
      <line x1={258} y1={58} x2={170} y2={138} stroke={C.red} strokeWidth={4} />
      <Label x={160} y={172} size={9} color={C.red}>nunca água em elétricos ou gorduras</Label>
    </Frame>
  );
}

/* ══════════════════════ MÉTODOS DE EXTINÇÃO ══════════════════════ */

function Flame({ x, y, s = 1, opacity = 1 }: { x: number; y: number; s?: number; opacity?: number }) {
  return (
    <path
      transform={`translate(${x} ${y}) scale(${s})`}
      d="M0 0 c -10 -14 6 -18 2 -32 c 12 8 16 20 8 30 c 6 -2 8 -6 9 -10 c 4 10 -2 22 -19 22 c -12 0 -18 -8 -14 -18 c 3 6 8 8 14 8 Z"
      fill={C.red}
      opacity={opacity}
    />
  );
}

export function ExtMethod({ m }: { m: string }) {
  if (m === "asfixia") {
    return (
      <Frame sea={false}>
        <rect x={96} y={64} width={128} height={100} rx={6} fill="none" stroke={C.ink} strokeWidth={2.6} />
        <Flame x={160} y={132} s={1.2} opacity={0.8} />
        <path d="M110 84 q 20 10 44 6 M180 96 q 16 -6 30 2" stroke={C.grey} strokeWidth={2.4} fill="none" strokeDasharray="3 5" />
        <Label x={160} y={50}>espaço fechado: o O₂ esgota-se</Label>
        <Label x={160} y={188} size={8.5} color={C.inkSoft}>o fogo consome o comburente</Label>
      </Frame>
    );
  }
  if (m === "abafamento") {
    return (
      <Frame sea={false}>
        <Flame x={160} y={150} s={1.2} opacity={0.55} />
        <path d="M96 138 C 110 96 210 96 224 138 L 224 158 C 200 146 120 146 96 158 Z" fill={C.ink} opacity={0.88} />
        <Label x={160} y={52}>cobrir as chamas</Label>
        <Label x={160} y={186} size={8.5} color={C.inkSoft}>cobertor, manta ou pó químico separam o ar</Label>
      </Frame>
    );
  }
  if (m === "arrefecimento") {
    return (
      <Frame sea={false}>
        <Flame x={160} y={140} s={1.3} />
        {[0, 1, 2].map((i) => (
          <path key={i} d={`M${136 + i * 24} 66 q 5 8 0 12 q -5 -4 0 -12`} fill={C.seaLine} />
        ))}
        <Arrow x1={148} y1={88} x2={152} y2={112} color={C.seaLine} width={2.4} />
        <Label x={160} y={50}>água = baixar a temperatura</Label>
        <Label x={160} y={186} size={8.5} color={C.inkSoft}>só onde a água pode ser usada</Label>
      </Frame>
    );
  }
  // inibicao
  return (
    <Frame sea={false}>
      {/* corrente partida */}
      {[0, 1, 2].map((i) => (
        <ellipse key={i} cx={102 + i * 34} cy={96} rx={16} ry={9} fill="none" stroke={C.ink} strokeWidth={3.4} transform={`rotate(${i % 2 ? 90 : 0} ${102 + i * 34} 96)`} />
      ))}
      {[0, 1].map((i) => (
        <ellipse key={i} cx={212 + i * 34} cy={96} rx={16} ry={9} fill="none" stroke={C.grey} strokeWidth={3.4} strokeDasharray="4 4" transform={`rotate(${i % 2 ? 90 : 0} ${212 + i * 34} 96)`} />
      ))}
      <line x1={196} y1={72} x2={204} y2={120} stroke={C.red} strokeWidth={4} />
      <Flame x={118} y={150} s={0.9} opacity={0.7} />
      <Label x={160} y={48}>inibição — reação em cadeia rompida</Label>
      <Label x={160} y={186} size={8.5} color={C.inkSoft}>princípio do pó químico dos extintores</Label>
    </Frame>
  );
}

/* ══════════════════════ MAU TEMPO / METEOROLOGIA ══════════════════════ */

export function WeatherThing({ type }: { type: string }) {
  if (type === "aproado") {
    return (
      <Frame>
        {/* vagas de vante */}
        {[0, 1, 2].map((i) => (
          <path key={i} d={`M${26 + i * 34} ${128 - i * 8} q 12 -18 24 0`} fill="none" stroke={C.seaLine} strokeWidth={3.2} />
        ))}
        <g transform="translate(216 120) rotate(-24)">
          <path d="M-44 0 L -36 -13 L 36 -13 L 44 0 C 30 6 -30 6 -44 0 Z" fill={C.ink} />
          <rect x={-14} y={-24} width={20} height={11} rx={2} fill={C.ink} />
        </g>
        <Arrow x1={100} y1={112} x2={164} y2={118} color={C.red} width={2.4} />
        <Label x={160} y={54}>proa ou amuras à vaga</Label>
        <Label x={160} y={182} size={8.5} color={C.inkSoft}>apresentar a parte mais forte da embarcação</Label>
      </Frame>
    );
  }
  if (type === "correr") {
    return (
      <Frame>
        {[0, 1, 2].map((i) => (
          <path key={i} d={`M${222 + i * 34} ${128 - i * 6} q 12 -18 24 0`} fill="none" stroke={C.seaLine} strokeWidth={3.2} />
        ))}
        <BoatSide x={140} y={122} flip />
        {/* drogue pela popa */}
        <path d="M96 130 C 76 140 64 148 56 156" fill="none" stroke={C.ink} strokeWidth={2.4} strokeDasharray="5 4" />
        <path d="M56 150 l -14 8 l 14 8 Z" fill={C.red} />
        <Arrow x1={230} y1={112} x2={186} y2={118} color={C.red} width={2.4} />
        <Label x={160} y={54}>vaga e vento por ré</Label>
        <Label x={70} y={180} size={8.5} color={C.inkSoft}>drogue pela popa mantém o governo</Label>
      </Frame>
    );
  }
  // nevoeiro meteorológico
  return (
    <Frame>
      <Sun x={56} y={46} r={13} />
      <path d="M20 96 q 30 -12 60 0 t 60 0 t 60 0 t 60 0 t 60 0" fill="none" stroke={C.grey} strokeWidth={4} />
      <path d="M-10 116 q 30 -12 60 0 t 60 0 t 60 0 t 60 0 t 60 0" fill="none" stroke={C.grey} strokeWidth={4} opacity={0.8} />
      <path d="M20 136 q 30 -12 60 0 t 60 0 t 60 0 t 60 0 t 60 0" fill="none" stroke={C.grey} strokeWidth={4} opacity={0.6} />
      <BoatSide x={160} y={162} scale={0.9} fill={C.inkSoft} />
      <Label x={160} y={36} size={9}>condensação junto à superfície</Label>
      <Label x={160} y={192} size={8.5} color={C.inkSoft}>nevoeiro &lt; 1 km · neblina ≥ 1 km</Label>
    </Frame>
  );
}
