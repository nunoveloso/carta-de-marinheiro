import { Arrow, BoatSide, BoatTop, C, Frame, Label, SailboatTop, W, WindArrow } from "./shared";

/** Quilha e balizas — construção do casco */
export function Keel() {
  return (
    <Frame sea={false}>
      {/* quilha */}
      <path d="M30 130 L 250 130 L 268 118 L 262 130 L 250 138 L 40 138 Z" fill={C.ink} />
      {/* balizas/cavernas */}
      {[60, 95, 130, 165, 200, 235].map((x) => (
        <path
          key={x}
          d={`M${x} 128 C ${x - 16} 96 ${x - 18} 66 ${x - 10} 44 M${x} 128 C ${x + 16} 96 ${x + 18} 66 ${x + 10} 44`}
          fill="none"
          stroke={C.inkSoft}
          strokeWidth={2.4}
        />
      ))}
      <Label x={60} y={162} size={9} anchor="start">quilha</Label>
      <line x1={78} y1={152} x2={110} y2={136} stroke={C.ink} strokeWidth={1.2} />
      <Label x={212} y={40} size={9}>balizas (cavernas)</Label>
      <line x1={208} y1={46} x2={196} y2={66} stroke={C.inkSoft} strokeWidth={1.2} />
    </Frame>
  );
}

/** Bombordo / Estibordo com luzes */
export function PortStarboard() {
  return (
    <Frame>
      <BoatTop x={160} y={100} scale={1.1} />
      {/* setores das luzes */}
      <path d="M160 100 L 104 60 A 74 74 0 0 0 112 136 Z" fill="#e8c9c3" opacity={0.85} />
      <path d="M160 100 L 216 60 A 74 74 0 0 1 208 136 Z" fill="#cfe3d4" opacity={0.85} />
      <circle cx={138} cy={88} r={5} fill={C.red} />
      <circle cx={182} cy={88} r={5} fill={C.green} />
      <Label x={82} y={120} size={10} color={C.red}>Bombordo</Label>
      <Label x={238} y={120} size={10} color={C.green}>Estibordo</Label>
      <Arrow x1={160} y1={78} x2={160} y2={46} color={C.inkSoft} width={1.8} />
      <Label x={160} y={40} size={9} color={C.inkSoft}>proa</Label>
    </Frame>
  );
}

/** Amura, través e alheta */
export function ShipRegions() {
  return (
    <Frame>
      <BoatTop x={160} y={102} scale={1.05} />
      <path d="M160 102 L 96 66" stroke={C.red} strokeWidth={2} strokeDasharray="5 4" />
      <path d="M160 102 L 96 138" stroke={C.yellow} strokeWidth={2} strokeDasharray="5 4" />
      <path d="M160 102 L 224 138" stroke={C.inkSoft} strokeWidth={2} strokeDasharray="5 4" />
      <Label x={74} y={60} size={10} color={C.red}>amura</Label>
      <Label x={70} y={106} size={10} color={C.ink}>través</Label>
      <line x1={100} y1={102} x2={92} y2={102} stroke={C.ink} strokeWidth={1.6} />
      <Label x={76} y={152} size={10} color={C.inkSoft}>alheta</Label>
      <Label x={232} y={152} size={9} color={C.inkSoft}>popa</Label>
      <Label x={232} y={60} size={9} color={C.inkSoft}>proa</Label>
    </Frame>
  );
}

/** Través: 90° do rumo */
export function Abeam() {
  return (
    <Frame>
      <BoatTop x={160} y={105} scale={0.95} />
      <line x1={160} y1={105} x2={160} y2={48} stroke={C.ink} strokeWidth={2} />
      <line x1={160} y1={105} x2={88} y2={105} stroke={C.red} strokeWidth={2.4} />
      <line x1={160} y1={105} x2={232} y2={105} stroke={C.green} strokeWidth={2.4} />
      <path d="M136 105 A 24 24 0 0 0 160 81" fill="none" stroke={C.ink} strokeWidth={1.4} />
      <Label x={141} y={94} size={9}>90°</Label>
      <Label x={66} y={110} size={9} color={C.red}>través BB</Label>
      <Label x={254} y={110} size={9} color={C.green}>través EB</Label>
      {/* bóia pelo través */}
      <circle cx={88} cy={105} r={6} fill={C.red} stroke={C.ink} strokeWidth={1.4} />
      <circle cx={232} cy={105} r={6} fill={C.green} stroke={C.ink} strokeWidth={1.4} />
    </Frame>
  );
}

/** Barlavento / Sotavento */
export function Windward() {
  return (
    <Frame>
      <WindArrow x={40} y={60} angle={18} label="vento" />
      <BoatTop x={170} y={110} scale={0.95} />
      <Label x={92} y={126} size={10}>barlavento</Label>
      <Label x={238} y={126} size={10}>sotavento</Label>
      <line x1={170} y1={40} x2={170} y2={176} stroke={C.inkSoft} strokeWidth={1.2} strokeDasharray="4 4" />
    </Frame>
  );
}

/** Orçar e arribar */
export function Luff() {
  return (
    <Frame>
      <WindArrow x={60} y={56} angle={90} label="vento" />
      <SailboatTop x={180} y={118} scale={0.8} rotate={-18} />
      {/* orçar: sobe ao vento */}
      <path d="M180 118 C 170 92 178 74 196 60" fill="none" stroke={C.green} strokeWidth={2.4} />
      <Arrow x1={196} y1={60} x2={204} y2={50} color={C.green} />
      {/* arribar: desce */}
      <path d="M180 118 C 196 108 214 108 230 118" fill="none" stroke={C.red} strokeWidth={2.4} />
      <Arrow x1={230} y1={118} x2={240} y2={126} color={C.red} />
      <Label x={238} y={52} size={9} color={C.green}>orçar</Label>
      <Label x={256} y={140} size={9} color={C.red}>arribar</Label>
    </Frame>
  );
}

/** Costado e querena — obras mortas e vivas */
export function HullWorks() {
  return (
    <Frame>
      {/* casco de perfil: proa bicuda à direita, pôpa recta à esquerda */}
      <path d="M66 110 L 240 110 L 272 150 C 230 166 108 166 66 164 Z" fill={C.ink} />
      {/* obras vivas (querena) abaixo da linha de água */}
      <path d="M66 110 L 240 110 L 272 150 C 230 166 108 166 66 164 Z" fill="none" stroke={C.ink} strokeWidth={2} />
      <path d="M70 150 C 110 162 212 162 264 150 C 226 164 106 164 70 160 Z" fill={C.red} opacity={0.85} />
      <line x1={30} y1={150} x2={292} y2={150} stroke={C.seaLine} strokeWidth={2} strokeDasharray="8 5" />
      <Label x={160} y={134} size={9} color={C.paper}>costado — obras mortas</Label>
      <Label x={160} y={162} size={9} color={C.paper}>querena — obras vivas</Label>
      <Label x={292} y={144} size={8} anchor="end" color={C.inkSoft}>linha de água</Label>
    </Frame>
  );
}

/** Calado */
export function Draft() {
  return (
    <Frame>
      <path d="M104 108 L 216 108 L 232 150 C 196 164 132 164 104 162 Z" fill={C.ink} />
      <line x1={40} y1={150} x2={280} y2={150} stroke={C.seaLine} strokeWidth={2} strokeDasharray="8 5" />
      <Label x={52} y={144} size={8} color={C.inkSoft} anchor="start">linha de água</Label>
      {/* cota do calado */}
      <line x1={250} y1={150} x2={250} y2={168} stroke={C.red} strokeWidth={2.2} />
      <line x1={244} y1={150} x2={256} y2={150} stroke={C.red} strokeWidth={2.2} />
      <line x1={244} y1={168} x2={256} y2={168} stroke={C.red} strokeWidth={2.2} />
      <Label x={264} y={163} size={9} color={C.red} anchor="start">calado</Label>
      {/* quilha */}
      <path d="M118 162 L 206 162 L 200 168 L 124 168 Z" fill={C.ink} />
      <Label x={162} y={184} size={8} color={C.inkSoft}>ponto mais baixo da quilha</Label>
    </Frame>
  );
}

/** Âncora com partes */
export function AnchorIll() {
  return (
    <Frame sea={false}>
      <g transform="translate(130 100)" stroke={C.ink} fill={C.ink}>
        {/* anete */}
        <circle cx={0} cy={-64} r={9} fill="none" strokeWidth={3} />
        {/* haste */}
        <rect x={-3} y={-58} width={6} height={96} />
        {/* cepo */}
        <rect x={-30} y={-50} width={60} height={7} rx={3} />
        {/* braços e unhas */}
        <path d="M0 30 C -34 30 -44 8 -42 -12 L -30 -4 C -32 10 -26 20 -8 22 Z" stroke="none" />
        <path d="M0 30 C 34 30 44 8 42 -12 L 30 -4 C 32 10 26 20 8 22 Z" stroke="none" />
      </g>
      <Label x={196} y={38} anchor="start" size={9}>anete</Label>
      <Label x={196} y={58} anchor="start" size={9}>cepo</Label>
      <Label x={196} y={84} anchor="start" size={9}>haste</Label>
      <Label x={196} y={128} anchor="start" size={9}>braço / unha</Label>
      <line x1={142} y1={36} x2={192} y2={36} stroke={C.inkSoft} strokeWidth={1} />
      <line x1={163} y1={54} x2={192} y2={55} stroke={C.inkSoft} strokeWidth={1} />
      <line x1={136} y1={84} x2={192} y2={80} stroke={C.inkSoft} strokeWidth={1} />
      <line x1={164} y1={126} x2={192} y2={124} stroke={C.inkSoft} strokeWidth={1} />
    </Frame>
  );
}

/** Amarra com quarteladas */
export function Rode() {
  return (
    <Frame>
      <BoatSide x={86} />
      {/* amarra em cadeia */}
      <path d="M122 142 C 150 156 190 162 236 158" fill="none" stroke={C.ink} strokeWidth={3} strokeDasharray="7 5" />
      {/* marcas de quartelada */}
      {[150, 178, 206].map((x, i) => (
        <circle key={i} cx={x} cy={153 + i * 3} r={4} fill={i % 2 ? C.yellow : C.red} stroke={C.ink} strokeWidth={1.2} />
      ))}
      {/* âncora no fundo */}
      <g transform="translate(244 160) scale(0.5)" fill={C.ink}>
        <circle cx={0} cy={-40} r={9} fill="none" stroke={C.ink} strokeWidth={5} />
        <rect x={-4} y={-32} width={8} height={56} />
        <path d="M0 18 C -28 18 -36 0 -34 -14 L -22 -6 C -24 6 -18 12 -4 14 Z" />
        <path d="M0 18 C 28 18 36 0 34 -14 L 22 -6 C 24 6 18 12 4 14 Z" />
      </g>
      <Label x={180} y={132} size={9}>amarra</Label>
      <Label x={180} y={180} size={8} color={C.inkSoft}>quarteladas sinalizadas com tinta</Label>
    </Frame>
  );
}

/** Fundo de boa tença */
export function HoldingGround() {
  return (
    <Frame>
      {/* fundo */}
      <rect x={0} y={164} width={W} height={36} fill={C.sand} />
      <BoatSide x={100} />
      <path d="M138 146 C 160 158 180 164 200 166" fill="none" stroke={C.ink} strokeWidth={3} strokeDasharray="7 5" />
      {/* âncora enterrada */}
      <g transform="translate(208 168) scale(0.55)" fill={C.ink}>
        <rect x={-4} y={-30} width={8} height={42} />
        <path d="M0 6 C -26 6 -34 -10 -32 -22 L -20 -14 C -22 -4 -16 0 -4 2 Z" />
        <path d="M0 6 C 26 6 34 -10 32 -22 L 20 -14 C 22 -4 16 0 4 2 Z" />
      </g>
      {/* areia a cobrir as unhas */}
      <path d="M180 168 q 14 -10 30 -2 q 16 -8 30 0 l 0 10 l -60 0 Z" fill={C.sand} />
      <Label x={160} y={126} size={9} color={C.inkSoft}>areia / lodo compacto</Label>
      <Label x={160} y={192} size={9}>o ferro unhe com facilidade</Label>
    </Frame>
  );
}

/** Drogue — âncora flutuante */
export function Drogue() {
  return (
    <Frame>
      <WindArrow x={34} y={44} angle={0} label="mar" />
      <BoatSide x={90} flip />
      {/* cone da drogue */}
      <path d="M140 146 L 216 158 L 216 172 L 140 158 Z" fill={C.red} stroke={C.ink} strokeWidth={1.6} />
      <path d="M216 158 L 236 150 L 236 180 L 216 172 Z" fill="none" stroke={C.ink} strokeWidth={1.6} />
      <line x1={128} y1={146} x2={142} y2={152} stroke={C.ink} strokeWidth={2.4} />
      <path d="M216 165 q 20 2 34 10" fill="none" stroke={C.inkSoft} strokeWidth={1.6} strokeDasharray="4 3" />
      <Label x={200} y={140} size={9}>drogue</Label>
      <Label x={160} y={190} size={8} color={C.inkSoft}>reduz o arrio · mantém aproada ao mar</Label>
    </Frame>
  );
}

/** Defensas na atracagem */
export function Fender() {
  return (
    <Frame sea={false}>
      <rect x={0} y={118} width={W} height={82} fill={C.sea} />
      {/* cais */}
      <rect x={236} y={60} width={84} height={140} fill={C.sand} stroke={C.ink} strokeWidth={1.6} />
      {/* barco */}
      <g transform="translate(150 148)">
        <path d="M-58 -20 L 46 -20 L 70 -2 L 70 4 L -58 4 Z" fill={C.ink} />
      </g>
      {/* defensas */}
      {[ -20, 12, 44 ].map((dx, i) => (
        <g key={i}>
          <line x1={150 + dx} y1={128} x2={158 + dx} y2={136} stroke={C.inkSoft} strokeWidth={1.6} />
          <circle cx={161 + dx} cy={146} r={11} fill={C.yellow} stroke={C.ink} strokeWidth={1.8} />
        </g>
      ))}
      <Label x={160} y={92} size={9} color={C.inkSoft}>defensas protegem o costado</Label>
      <Label x={278} y={50} size={9}>cais</Label>
    </Frame>
  );
}
