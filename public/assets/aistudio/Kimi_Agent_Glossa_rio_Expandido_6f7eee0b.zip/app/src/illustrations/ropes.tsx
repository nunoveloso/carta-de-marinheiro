import { Arrow, BoatTop, C, Frame, Label, SailboatTop, W } from "./shared";

/** Espias de amarração ao cais */
export function MooringLines() {
  return (
    <Frame sea={false}>
      <rect x={0} y={118} width={W} height={82} fill={C.sea} />
      {/* cais */}
      <rect x={0} y={0} width={W} height={56} fill={C.sand} stroke={C.ink} strokeWidth={1.6} />
      {/* barco de topo, proa para a direita */}
      <g transform="translate(160 96) rotate(90)">
        <path d="M0 -56 C 13 -38 15 -14 15 12 L 15 44 L -15 44 L -15 12 C -15 -14 -13 -38 0 -56 Z" fill={C.ink} />
        <rect x={-6} y={-30} width={12} height={14} rx={2} fill={C.paper} opacity={0.85} />
      </g>
      {/* cunhos no cais */}
      {[70, 250].map((x) => (
        <rect key={x} x={x - 8} y={50} width={16} height={8} rx={3} fill={C.ink} />
      ))}
      {/* espia de vante (proa → cunho à vante) */}
      <line x1={208} y1={82} x2={250} y2={56} stroke={C.green} strokeWidth={2.6} />
      {/* espia de ré (popa → cunho à ré) */}
      <line x1={112} y1={82} x2={70} y2={56} stroke={C.red} strokeWidth={2.6} />
      {/* traseiras (tracejado) */}
      <line x1={204} y1={106} x2={70} y2={56} stroke={C.inkSoft} strokeWidth={1.8} strokeDasharray="6 4" />
      <line x1={116} y1={106} x2={250} y2={56} stroke={C.inkSoft} strokeWidth={1.8} strokeDasharray="6 4" />
      <Label x={284} y={86} size={9} color={C.green} anchor="middle">espia</Label>
      <Label x={284} y={98} size={9} color={C.green} anchor="middle">de vante</Label>
      <Label x={36} y={86} size={9} color={C.red} anchor="middle">espia</Label>
      <Label x={36} y={98} size={9} color={C.red} anchor="middle">de ré</Label>
      <Label x={160} y={150} size={8} color={C.paper}>traseiras a tracejado</Label>
    </Frame>
  );
}

/** Massame, chicote e seio */
export function RopeParts() {
  return (
    <Frame sea={false}>
      {/* cabo com curva */}
      <path d="M40 100 C 90 60 140 140 190 100 C 220 76 250 84 280 100" fill="none" stroke={C.ink} strokeWidth={6} strokeLinecap="round" />
      {/* chicotes */}
      <circle cx={40} cy={100} r={9} fill={C.red} stroke={C.ink} strokeWidth={1.6} />
      <circle cx={280} cy={100} r={9} fill={C.red} stroke={C.ink} strokeWidth={1.6} />
      {/* seio */}
      <path d="M120 118 L 200 118" stroke={C.green} strokeWidth={2.4} />
      <line x1={120} y1={112} x2={120} y2={124} stroke={C.green} strokeWidth={2.4} />
      <line x1={200} y1={112} x2={200} y2={124} stroke={C.green} strokeWidth={2.4} />
      <Label x={40} y={132} size={9} color={C.red}>chicote</Label>
      <Label x={280} y={132} size={9} color={C.red}>chicote</Label>
      <Label x={160} y={136} size={9} color={C.green}>seio</Label>
      <Label x={W / 2} y={40} size={9} color={C.inkSoft}>massame = conjunto dos cabos a bordo</Label>
    </Frame>
  );
}

/** Alar e folgar */
export function HeaveSlack() {
  return (
    <Frame sea={false}>
      <rect x={0} y={128} width={W} height={72} fill={C.sea} />
      {/* cabeço */}
      <rect x={150} y={100} width={20} height={34} rx={4} fill={C.ink} />
      {/* alar */}
      <path d="M60 116 L 150 116" stroke={C.ink} strokeWidth={4} />
      <Arrow x1={86} y1={108} x2={112} y2={108} color={C.green} />
      <Label x={86} y={96} size={9} color={C.green}>alar (puxar)</Label>
      {/* folgar */}
      <path d="M170 116 C 210 116 230 132 250 148" fill="none" stroke={C.ink} strokeWidth={4} />
      <Arrow x1={204} y1={130} x2={228} y2={142} color={C.red} />
      <Label x={252} y={108} size={9} color={C.red}>folgar (deixar correr)</Label>
      <Label x={160} y={168} size={8} color={C.inkSoft}>sem largar o chicote</Label>
    </Frame>
  );
}

/** Lais de guia (bowline) */
export function Bowline() {
  return (
    <Frame sea={false}>
      {/* anzois: gaza + nó */}
      <g stroke={C.ink} strokeWidth={5} fill="none" strokeLinecap="round">
        {/* gaza grande */}
        <circle cx={150} cy={92} r={42} />
        {/* volta pequena */}
        <circle cx={150} cy={150} r={14} />
      </g>
      {/* chicote que sobe por baixo */}
      <path d="M216 168 C 190 160 172 158 164 152 L 164 108 C 164 96 158 90 150 88" fill="none" stroke={C.red} strokeWidth={5} strokeLinecap="round" />
      {/* seio que sai para a esquerda */}
      <path d="M108 92 C 78 92 60 104 48 122" fill="none" stroke={C.ink} strokeWidth={5} strokeLinecap="round" />
      <path d="M164 108 C 176 104 188 106 196 116" fill="none" stroke={C.ink} strokeWidth={5} strokeLinecap="round" />
      <Label x={150} y={44} size={9}>gaza fixa — não corre</Label>
      <Label x={232} y={172} size={9} color={C.red} anchor="start">chicote</Label>
      <Label x={44} y={140} size={9} anchor="start">seio</Label>
    </Frame>
  );
}

/** Volta de cunho */
export function CleatHitch() {
  return (
    <Frame sea={false}>
      {/* cunho */}
      <g transform="translate(160 108)">
        <rect x={-10} y={6} width={20} height={40} fill={C.ink} />
        <path d="M-56 -4 L -18 -12 L -14 0 L -52 8 Z" fill={C.ink} />
        <path d="M56 -4 L 18 -12 L 14 0 L 52 8 Z" fill={C.ink} />
      </g>
      {/* cabo em oitos */}
      <path
        d="M40 150 C 70 148 96 140 118 118 L 202 96 M118 96 L 202 118"
        fill="none"
        stroke={C.red}
        strokeWidth={4.4}
        strokeLinecap="round"
      />
      <path d="M202 96 C 214 100 214 114 202 118" fill="none" stroke={C.red} strokeWidth={4.4} />
      <Label x={160} y={56} size={9}>oitos cruzados sobre o cunho</Label>
      <Label x={40} y={168} size={9} anchor="start" color={C.red}>cabo</Label>
    </Frame>
  );
}

/** Guinar: cana do leme para BB → proa para EB */
export function Helm() {
  return (
    <Frame>
      <BoatTop x={160} y={108} scale={0.95} />
      {/* leme */}
      <rect x={154} y={138} width={12} height={20} rx={3} fill={C.inkSoft} />
      {/* cana do leme para BB */}
      <line x1={160} y1={140} x2={134} y2={152} stroke={C.red} strokeWidth={4} strokeLinecap="round" />
      <Arrow x1={150} y1={146} x2={136} y2={152} color={C.red} width={2.4} />
      {/* guinada para EB */}
      <path d="M160 82 C 176 70 196 68 214 76" fill="none" stroke={C.green} strokeWidth={2.6} />
      <Arrow x1={214} y1={76} x2={224} y2={82} color={C.green} />
      <Label x={96} y={164} size={9} color={C.red}>cana a BB</Label>
      <Label x={236} y={66} size={9} color={C.green}>guina a EB</Label>
    </Frame>
  );
}

/** Hélice de passo direito */
export function Propeller() {
  return (
    <Frame sea={false}>
      <rect x={0} y={120} width={W} height={80} fill={C.sea} />
      <g transform="translate(160 112)">
        {[0, 120, 240].map((a) => (
          <path
            key={a}
            d="M0 0 C 18 -6 30 -20 28 -38 C 12 -34 2 -18 0 0 Z"
            fill={C.ink}
            transform={`rotate(${a})`}
          />
        ))}
        <circle cx={0} cy={0} r={10} fill={C.yellow} stroke={C.ink} strokeWidth={2} />
      </g>
      {/* seta de rotação: sentido dos ponteiros do relógio */}
      <path d="M196 76 A 46 46 0 0 1 204 150" fill="none" stroke={C.red} strokeWidth={2.6} />
      <Arrow x1={204} y1={150} x2={200} y2={162} color={C.red} />
      <Label x={W / 2} y={180} size={9} color={C.inkSoft}>marcha avante: sentido dos ponteiros do relógio</Label>
    </Frame>
  );
}

/** Bordejar: ziguezague contra o vento */
export function Tacking() {
  return (
    <Frame>
      {/* vento de cima */}
      <path d="M160 30 L 160 46 M150 38 L 160 46 L 170 38" stroke={C.inkSoft} strokeWidth={2} fill="none" />
      <Label x={160} y={24} size={9} color={C.inkSoft}>vento</Label>
      {/* cone de impossibilidade */}
      <path d="M160 150 L 108 40 M160 150 L 212 40" stroke={C.seaLine} strokeWidth={1.6} strokeDasharray="5 4" />
      {/* percurso em ziguezague */}
      <path d="M160 158 L 92 118 L 176 84 L 116 48" fill="none" stroke={C.red} strokeWidth={2.6} />
      <Arrow x1={116} y1={48} x2={104} y2={42} color={C.red} />
      <SailboatTop x={160} y={158} scale={0.5} rotate={135} />
      <SailboatTop x={92} y={118} scale={0.5} rotate={45} />
      <SailboatTop x={176} y={84} scale={0.5} rotate={120} />
      <Label x={W / 2} y={188} size={8} color={C.inkSoft}>bordos sucessivos para ganhar barlavento</Label>
    </Frame>
  );
}

/** Atracagem: aproximação lenta, ângulo pequeno */
export function Docking() {
  return (
    <Frame sea={false}>
      <rect x={0} y={104} width={W} height={96} fill={C.sea} />
      {/* cais */}
      <rect x={0} y={0} width={W} height={52} fill={C.sand} stroke={C.ink} strokeWidth={1.6} />
      <Label x={12} y={30} anchor="start" size={9} color={C.inkSoft}>cais</Label>
      {/* trajetória de aproximação */}
      <Arrow x1={72} y1={156} x2={150} y2={118} color={C.red} dashed width={2.2} />
      {/* barco de topo quase paralelo ao cais */}
      <g transform="translate(204 100) rotate(72)">
        <path d="M0 -50 C 12 -34 14 -12 14 10 L 14 40 L -14 40 L -14 10 C -14 -12 -12 -34 0 -50 Z" fill={C.ink} />
        <rect x={-5} y={-26} width={10} height={12} rx={2} fill={C.paper} opacity={0.85} />
      </g>
      {/* defensas do lado do cais */}
      {[ -14, 6, 26 ].map((d, i) => (
        <circle key={i} cx={196 + d * 1.9} cy={72 - d * 0.6} r={7} fill={C.yellow} stroke={C.ink} strokeWidth={1.6} />
      ))}
      {/* ângulo pequeno com o cais */}
      <path d="M150 104 L 190 104" stroke={C.inkSoft} strokeWidth={1.2} strokeDasharray="3 3" />
      <path d="M150 104 L 178 96" stroke={C.red} strokeWidth={1.8} />
      <path d="M168 104 A 18 18 0 0 0 166 101" fill="none" stroke={C.red} strokeWidth={1.4} />
      <Label x={120} y={96} size={8} color={C.red}>ângulo pequeno</Label>
      <Label x={W / 2} y={180} size={9} color={C.inkSoft}>velocidade baixa · defensas e espias prontos</Label>
    </Frame>
  );
}

export { BoatTop };
