import type { ComponentType } from "react";
import {
  Aground,
  Bearing,
  BellGong,
  CollisionBearing,
  DayShapes,
  MotorVessel,
  Overtaking,
  RieamCrossing,
  ShapesNuc,
  ShapesRam,
  SoundBlasts,
  Whistle,
} from "./rieam";
import {
  Bleeding,
  Butakow,
  Extinguisher,
  ExtinctionMethods,
  FireTriangle,
  Flares,
  Hydrocussion,
  Hypothermia,
  Lifebuoy,
  Lifejacket,
  Liferaft,
  Pls,
  Sunstroke,
  Vitals,
} from "./safety";
import {
  Abeam,
  AnchorIll,
  Draft,
  Drogue,
  Fender,
  HoldingGround,
  HullWorks,
  Keel,
  Luff,
  PortStarboard,
  Rode,
  ShipRegions,
  Windward,
} from "./hull";
import {
  Bowline,
  CleatHitch,
  Docking,
  HeaveSlack,
  Helm,
  MooringLines,
  Propeller,
  RopeParts,
  Tacking,
} from "./ropes";
import {
  Beaufort,
  Breeze,
  CardinalMarks,
  Cavitation,
  ChartDatum,
  Harbour,
  IsolatedDanger,
  LateralMarks,
  Recreio,
  SafeWater,
  SiglaThing,
  SpecialMark,
  Syzygy,
  TideCurve,
  TideSlack,
  VesselTypes,
} from "./misc";
import { AnchorPart, Dims, HullPart, HullTopPart, Miuda, Palamenta, Quality } from "./families-hull";
import {
  AidThing,
  ExtMethod,
  FirePart,
  KnotThing,
  ManobraThing,
  RieamThing,
  RopeThing,
  SafetyThing,
  WeatherThing,
} from "./families-work";
import { CloudThing, LegThing, MarksThing, MotorThing, NavThing, RadioThing, TideThing } from "./families-nav";

export const ILLUSTRATIONS: Record<string, ComponentType> = {
  "rieam-crossing": RieamCrossing,
  overtaking: Overtaking,
  "collision-bearing": CollisionBearing,
  bearing: Bearing,
  "shapes-nuc": ShapesNuc,
  "shapes-ram": ShapesRam,
  "motor-vessel": MotorVessel,
  "day-shapes": DayShapes,
  aground: Aground,
  whistle: Whistle,
  bell: BellGong,
  "sound-blasts": SoundBlasts,
  liferaft: Liferaft,
  lifejacket: Lifejacket,
  lifebuoy: Lifebuoy,
  flares: Flares,
  butakow: Butakow,
  hypothermia: Hypothermia,
  sunstroke: Sunstroke,
  hydrocussion: Hydrocussion,
  pls: Pls,
  vitals: Vitals,
  bleeding: Bleeding,
  "fire-triangle": FireTriangle,
  "extinction-methods": ExtinctionMethods,
  extinguisher: Extinguisher,
  keel: Keel,
  "port-starboard": PortStarboard,
  "ship-regions": ShipRegions,
  abeam: Abeam,
  windward: Windward,
  luff: Luff,
  "hull-works": HullWorks,
  draft: Draft,
  anchor: AnchorIll,
  rode: Rode,
  "holding-ground": HoldingGround,
  drogue: Drogue,
  fender: Fender,
  "mooring-lines": MooringLines,
  "rope-parts": RopeParts,
  "heave-slack": HeaveSlack,
  bowline: Bowline,
  "cleat-hitch": CleatHitch,
  helm: Helm,
  propeller: Propeller,
  tacking: Tacking,
  docking: Docking,
  recreio: Recreio,
  harbour: Harbour,
  "vessel-types": VesselTypes,
  "lateral-marks": LateralMarks,
  "cardinal-marks": CardinalMarks,
  "isolated-danger": IsolatedDanger,
  "safe-water": SafeWater,
  "special-mark": SpecialMark,
  "tide-curve": TideCurve,
  "tide-slack": TideSlack,
  syzygy: Syzygy,
  "chart-datum": ChartDatum,
  breeze: Breeze,
  beaufort: Beaufort,
  cavitation: Cavitation,
};

const FAMILIES: Record<string, ComponentType<{ [k: string]: string }>> = {
  hull: HullPart as ComponentType<{ [k: string]: string }>,
  hulltop: HullTopPart as ComponentType<{ [k: string]: string }>,
  dims: Dims as ComponentType<{ [k: string]: string }>,
  anchor: AnchorPart as ComponentType<{ [k: string]: string }>,
  miuda: Miuda as ComponentType<{ [k: string]: string }>,
  palamenta: Palamenta as ComponentType<{ [k: string]: string }>,
  quality: Quality as ComponentType<{ [k: string]: string }>,
  rope: RopeThing as ComponentType<{ [k: string]: string }>,
  knot: KnotThing as ComponentType<{ [k: string]: string }>,
  manobra: ManobraThing as ComponentType<{ [k: string]: string }>,
  rieam: RieamThing as ComponentType<{ [k: string]: string }>,
  safety: SafetyThing as ComponentType<{ [k: string]: string }>,
  aid: AidThing as ComponentType<{ [k: string]: string }>,
  fire: FirePart as ComponentType<{ [k: string]: string }>,
  ext: ExtMethod as ComponentType<{ [k: string]: string }>,
  weather: WeatherThing as ComponentType<{ [k: string]: string }>,
  marks: MarksThing as ComponentType<{ [k: string]: string }>,
  radio: RadioThing as ComponentType<{ [k: string]: string }>,
  tide: TideThing as ComponentType<{ [k: string]: string }>,
  cloud: CloudThing as ComponentType<{ [k: string]: string }>,
  motor: MotorThing as ComponentType<{ [k: string]: string }>,
  nav: NavThing as ComponentType<{ [k: string]: string }>,
  leg: LegThing as ComponentType<{ [k: string]: string }>,
  sigla: SiglaThing as ComponentType<{ [k: string]: string }>,
};

export function TermIllustration({ name }: { name: string }) {
  if (name.includes(":")) {
    const [family, param] = name.split(":", 2);
    const Fam = FAMILIES[family];
    if (Fam) {
      const propKey = { hull: "part", hulltop: "part", dims: "dim", anchor: "part", fire: "part", ext: "m" }[family] ?? "type";
      const props = { [propKey]: param } as { [k: string]: string };
      return <Fam {...props} />;
    }
  }
  const Cmp = ILLUSTRATIONS[name];
  if (!Cmp) {
    return (
      <div className="flex h-full w-full items-center justify-center bg-[#f7f2e6] text-xs text-[#3d647c]">
        sem esquema
      </div>
    );
  }
  return <Cmp />;
}
