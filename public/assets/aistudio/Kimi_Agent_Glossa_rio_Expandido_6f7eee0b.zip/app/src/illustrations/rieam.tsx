import { Arrow, BoatSide, BoatTop, C, Frame, Label, W } from "./shared";

/** Duas embarcações em rotas de cruzamento */
export function RieamCrossing() {
  return (
    <Frame>
      <BoatTop x={110} y={120} scale={0.85} />
      <BoatTop x={225} y={80} scale={0.85} rotate={-60} fill={C.inkSoft} />
      <Arrow x1={110} y1={100} x2={110} y2={52} color={C.red} dashed />
      <Arrow x1={210} y1={92} x2={158} y2={120} color={C.red} dashed />
      <circle cx={110} cy={52} r={5} fill="none" stroke={C.red} strokeWidth={2} />
      <circle cx={110} cy={52} r={10} fill="none" stroke={C.red} strokeWidth={1} strokeDasharray="3 3" />
      <Label x={W / 2} y={26}>Risco de colisão</Label>
    </Frame>
  );
}

/** Setores de alcançante: 22,5° para ré do través */
export function Overtaking() {
  const cx = 160, cy = 105;
  return (
    <Frame>
      {/* setores das luzes */}
      <path d={`M${cx} ${cy} L ${cx - 72} ${cy - 40} A 82 82 0 0 0 ${cx + 72} ${cy - 40} Z`} fill={C.white} stroke={C.seaLine} />
      <path d={`M${cx} ${cy} L ${cx - 95} ${cy - 22} A 98 98 0 0 1 ${cx - 20} ${cy + 96} Z`} fill="#e8c9c3" stroke={C.red} strokeWidth={1} />
      <path d={`M${cx} ${cy} L ${cx + 95} ${cy - 22} A 98 98 0 0 0 ${cx + 20} ${cy + 96} Z`} fill="#cfe3d4" stroke={C.green} strokeWidth={1} />
      <path d={`M${cx} ${cy} L ${cx - 20} ${cy + 96} A 98 98 0 0 0 ${cx + 20} ${cy + 96} Z`} fill="#f3e9c8" stroke={C.yellow} strokeWidth={1.2} />
      <BoatTop x={cx} y={cy} scale={0.8} />
      {/* alcançante no setor de popa */}
      <BoatTop x={cx + 8} y={cy + 70} scale={0.6} fill={C.red} />
      <Arrow x1={cx + 8} y1={cy + 55} x2={cx + 3} y2={cy + 30} color={C.red} dashed width={1.6} />
      <Label x={cx} y={cy + 92} size={9}>Alcançante — mais de 22,5° para ré do través</Label>
      <Label x={cx - 62} y={cy - 52} size={9} color={C.red}>BB 112,5°</Label>
      <Label x={cx + 62} y={cy - 52} size={9} color={C.green}>EB 112,5°</Label>
      <Label x={cx} y={24} size={9} color={C.inkSoft}>Vante 225°</Label>
    </Frame>
  );
}

/** Marcação constante, distância diminui */
export function CollisionBearing() {
  return (
    <Frame>
      <BoatTop x={90} y={120} scale={0.8} />
      <BoatTop x={230} y={70} scale={0.7} rotate={120} fill={C.inkSoft} />
      {/* três posições com a mesma marcação */}
      <line x1={90} y1={120} x2={238} y2={62} stroke={C.red} strokeWidth={1.6} strokeDasharray="6 4" />
      <circle cx={140} cy={102} r={4} fill={C.red} />
      <circle cx={185} cy={86} r={4} fill={C.red} />
      <circle cx={228} cy={70} r={4} fill={C.red} />
      <Label x={160} y={30}>Marcação constante + distância a diminuir</Label>
      <Label x={160} y={44} size={9} color={C.red}>= risco de abalroamento</Label>
    </Frame>
  );
}

/** Marcação — rosa dos ventos */
export function Bearing() {
  const cx = 120, cy = 110;
  return (
    <Frame>
      <circle cx={cx} cy={cy} r={64} fill={C.white} stroke={C.ink} strokeWidth={1.4} />
      {[0, 45, 90, 135, 180, 225, 270, 315].map((a) => {
        const r = (a * Math.PI) / 180;
        return (
          <line
            key={a}
            x1={cx + 56 * Math.sin(r)}
            y1={cy - 56 * Math.cos(r)}
            x2={cx + 64 * Math.sin(r)}
            y2={cy - 64 * Math.cos(r)}
            stroke={C.ink}
            strokeWidth={1.6}
          />
        );
      })}
      <Label x={cx} y={cy - 70} size={10}>N</Label>
      <BoatTop x={cx} y={cy} scale={0.55} />
      <line x1={cx} y1={cy} x2={cx + 50} y2={cy - 40} stroke={C.red} strokeWidth={2} />
      <path d={`M${cx + 24} ${cy} A 24 24 0 0 0 ${cx + 20} ${cy - 16}`} fill="none" stroke={C.red} strokeWidth={1.4} />
      <Label x={cx + 46} y={cy + 4} size={9} color={C.red}>045°</Label>
      <Label x={230} y={70} anchor="middle">Objeto avistado</Label>
      <circle cx={cx + 50} cy={cy - 40} r={4} fill={C.inkSoft} />
    </Frame>
  );
}

function DayShape({ kind, x, y }: { kind: "sphere" | "bicone" | "cylinder" | "cone"; x: number; y: number }) {
  if (kind === "sphere") return <circle cx={x} cy={y} r={9} fill={C.black} />;
  if (kind === "bicone")
    // dois cones unidos pelos vértices (pontas a tocar-se no centro)
    return (
      <g fill={C.black}>
        <path d={`M${x - 10} ${y - 12} L ${x} ${y} L ${x + 10} ${y - 12} Z`} />
        <path d={`M${x - 10} ${y + 12} L ${x} ${y} L ${x + 10} ${y + 12} Z`} />
      </g>
    );
  if (kind === "cylinder") return <rect x={x - 8} y={y - 12} width={16} height={24} fill={C.black} />;
  // cónico com o vértice para baixo (Regra 25e)
  return <path d={`M${x - 10} ${y - 20} L ${x} ${y} L ${x + 10} ${y - 20} Z`} fill={C.black} />;
}

/** Navio sem governo: duas esferas verticais */
export function ShapesNuc() {
  return (
    <Frame>
      <BoatSide x={120} />
      <line x1={100} y1={122} x2={100} y2={52} stroke={C.ink} strokeWidth={2.4} />
      <DayShape kind="sphere" x={100} y={66} />
      <DayShape kind="sphere" x={100} y={88} />
      <Label x={200} y={80} anchor="middle">2 balões esféricos</Label>
      <Label x={200} y={94} anchor="middle" size={9} color={C.inkSoft}>na vertical — de dia</Label>
    </Frame>
  );
}

/** Capacidade de manobra reduzida: esfera–bicónico–esfera */
export function ShapesRam() {
  return (
    <Frame>
      <BoatSide x={120} />
      <line x1={100} y1={122} x2={100} y2={42} stroke={C.ink} strokeWidth={2.4} />
      <DayShape kind="sphere" x={100} y={54} />
      <DayShape kind="bicone" x={100} y={78} />
      <DayShape kind="sphere" x={100} y={104} />
      <Label x={205} y={78} anchor="middle">Esfera – bicónico – esfera</Label>
      <Label x={205} y={92} anchor="middle" size={9} color={C.inkSoft}>na vertical — de dia</Label>
    </Frame>
  );
}

/** Propulsão mecânica (+ cónico para baixo quando à vela e motor) */
export function MotorVessel() {
  return (
    <Frame>
      <BoatSide x={100} />
      <SailboatIcon x={225} y={148} />
      <g transform="translate(222 88) rotate(180)">
        <DayShape kind="cone" x={0} y={0} />
      </g>
      <line x1={222} y1={100} x2={222} y2={122} stroke={C.ink} strokeWidth={2} />
      <Label x={100} y={52}>Motor</Label>
      <Label x={222} y={52}>Vela + motor</Label>
      <Label x={222} y={64} size={8} color={C.inkSoft}>cónico, vértice p/ baixo</Label>
    </Frame>
  );
}

function SailboatIcon({ x, y }: { x: number; y: number }) {
  return (
    <g transform={`translate(${x} ${y})`}>
      <path d="M-34 -10 L 24 -10 L 34 -1 L 34 2 L -34 2 Z" fill={C.ink} />
      <line x1={-2} y1={-10} x2={-2} y2={-52} stroke={C.ink} strokeWidth={2.4} />
      <path d="M0 -50 L 0 -12 L 22 -12 Z" fill={C.white} stroke={C.ink} strokeWidth={1.4} />
      {/* escape de fumo / motor */}
      <path d="M-22 -14 q -6 -6 0 -12 q 6 -6 10 -1" fill="none" stroke={C.grey} strokeWidth={1.6} />
    </g>
  );
}

/** Os quatro tipos de balões */
export function DayShapes() {
  const items: { kind: "sphere" | "bicone" | "cylinder" | "cone"; label: string }[] = [
    { kind: "sphere", label: "Esfera" },
    { kind: "bicone", label: "Bicónico" },
    { kind: "cylinder", label: "Cilindro" },
    { kind: "cone", label: "Cónico" },
  ];
  return (
    <Frame sea={false}>
      {items.map((it, i) => (
        <g key={it.kind}>
          <DayShape kind={it.kind} x={52 + i * 72} y={95} />
          <Label x={52 + i * 72} y={130}>{it.label}</Label>
        </g>
      ))}
      <Label x={W / 2} y={40} size={10}>Marcas diurnas pretas</Label>
    </Frame>
  );
}

/** Encalhada: três esferas verticais */
export function Aground() {
  return (
    <Frame>
      <rect x={40} y={150} width={240} height={14} fill={C.sand} />
      <g transform="translate(120 152)">
        <path d="M-46 -14 L 32 -14 L 46 -1 L 46 2 L -46 2 Z" fill={C.ink} />
      </g>
      <line x1={100} y1={138} x2={100} y2={50} stroke={C.ink} strokeWidth={2.4} />
      <DayShape kind="sphere" x={100} y={62} />
      <DayShape kind="sphere" x={100} y={84} />
      <DayShape kind="sphere" x={100} y={106} />
      <Label x={205} y={88} anchor="middle">3 balões esféricos</Label>
      <Label x={205} y={102} anchor="middle" size={9} color={C.inkSoft}>na vertical — de dia</Label>
    </Frame>
  );
}

/** Apito: sons de manobra */
export function Whistle() {
  return (
    <Frame sea={false}>
      {/* apito */}
      <g transform="translate(70 95)">
        <path d="M-30 0 L 18 0 L 30 -10 L 30 6 L 18 14 L -24 14 Q -34 14 -34 4 Z" fill={C.ink} />
        <rect x={-38} y={-8} width={10} height={20} rx={3} fill={C.inkSoft} />
        <circle cx={30} cy={-2} r={3} fill={C.paper} />
      </g>
      <g>
        <SoundMark x={150} y={70} n={1} />
        <SoundMark x={205} y={70} n={2} />
        <SoundMark x={260} y={70} n={3} />
        <Label x={150} y={110} size={8}>EB</Label>
        <Label x={205} y={110} size={8}>BB</Label>
        <Label x={260} y={110} size={8}>Ré</Label>
      </g>
      <Label x={W / 2} y={150} size={9} color={C.inkSoft}>1 curto: guino a EB · 2 curtos: BB · 3 curtos: máquinas a ré</Label>
    </Frame>
  );
}

function SoundMark({ x, y, n }: { x: number; y: number; n: number }) {
  return (
    <g>
      {Array.from({ length: n }).map((_, i) => (
        <path
          key={i}
          d={`M${x + i * 7} ${y + 12} q 4 -12 0 -24`}
          fill="none"
          stroke={C.red}
          strokeWidth={2.4}
          strokeLinecap="round"
        />
      ))}
    </g>
  );
}

/** Sino e gongo por comprimento */
export function BellGong() {
  return (
    <Frame sea={false}>
      <g transform="translate(85 78)">
        <path d="M0 -22 C 14 -22 18 -6 18 8 L -18 8 C -18 -6 -14 -22 0 -22 Z" fill={C.yellow} stroke={C.ink} strokeWidth={1.6} />
        <rect x={-21} y={8} width={42} height={6} rx={3} fill={C.ink} />
        <circle cx={0} cy={18} r={4} fill={C.ink} />
      </g>
      <Label x={85} y={120}>Sino</Label>
      <g transform="translate(215 78)">
        <circle cx={0} cy={-2} r={26} fill={C.yellow} stroke={C.ink} strokeWidth={1.6} />
        <circle cx={0} cy={-2} r={16} fill="none" stroke={C.ink} strokeWidth={1.2} />
        <line x1={-30} y1={-34} x2={30} y2={-34} stroke={C.ink} strokeWidth={2.4} />
      </g>
      <Label x={215} y={120}>Gongo</Label>
      <Label x={W / 2} y={156} size={9} color={C.inkSoft}>20–100 m: apito + sino · ≥ 100 m: + gongo</Label>
    </Frame>
  );
}

/** Som curto vs prolongado */
export function SoundBlasts() {
  return (
    <Frame sea={false}>
      {/* curto */}
      <rect x={40} y={66} width={34} height={18} rx={4} fill={C.red} />
      <Label x={57} y={104} size={9}>Curto</Label>
      <Label x={57} y={118} size={9} color={C.inkSoft}>≈ 1 s</Label>
      {/* prolongado */}
      <rect x={150} y={66} width={130} height={18} rx={4} fill={C.ink} />
      <Label x={215} y={104} size={9}>Prolongado</Label>
      <Label x={215} y={118} size={9} color={C.inkSoft}>4–6 s</Label>
      <Label x={W / 2} y={152} size={9} color={C.inkSoft}>nevoeiro: 1 prolongado a cada ≤ 2 min (com seguimento)</Label>
    </Frame>
  );
}
