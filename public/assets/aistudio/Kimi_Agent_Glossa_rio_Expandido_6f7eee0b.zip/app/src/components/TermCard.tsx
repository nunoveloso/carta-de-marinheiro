import { TermIllustration } from "@/illustrations";
import { categoryColor, categorySoft, isForeign, matchSnippet, titleMatches, type Term } from "@/lib/glossary";

export function TermCard({
  term,
  onOpen,
  query,
}: {
  term: Term;
  onOpen: (slug: string) => void;
  query?: string;
}) {
  const q = (query ?? "").trim();
  const snippet = q.length >= 2 && !titleMatches(term.term, q) ? matchSnippet(term.definition, q) : null;
  return (
    <button
      type="button"
      onClick={() => onOpen(term.slug)}
      className="group flex w-full cursor-pointer flex-col border border-border bg-card text-left transition-all duration-200 hover:-translate-y-0.5 hover:border-primary hover:shadow-[4px_4px_0_0_#0b3a55] focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring"
    >
      <div className="aspect-[8/5] w-full border-b border-border">
        <TermIllustration name={term.illustration} />
      </div>
      <div className="flex flex-1 flex-col gap-2 p-4">
        <h3 className="text-[19px] font-semibold leading-snug tracking-tight">
          <span className={isForeign(term.slug) ? "italic" : ""}>{term.term}</span>
        </h3>
        {snippet && (
          <p className="line-clamp-2 border-l-2 border-[#b3402f]/50 pl-2 text-[13px] leading-snug text-muted-foreground">
            {snippet.text.slice(0, snippet.matchStart)}
            <mark className="bg-[#e3b505]/40 font-medium text-foreground">
              {snippet.text.slice(snippet.matchStart, snippet.matchEnd)}
            </mark>
            {snippet.text.slice(snippet.matchEnd)}
          </p>
        )}
        <div className="mt-auto flex flex-wrap items-center gap-2 pt-1">
          <span
            className="font-mono-naut px-1.5 py-0.5 text-[10px] font-semibold uppercase tracking-[0.1em]"
            style={{ background: categorySoft(term.category), color: categoryColor(term.category) }}
          >
            {term.category}
          </span>
          <span className="font-mono-naut text-[10px] uppercase tracking-[0.1em] text-muted-foreground">
            {term.subcategory}
          </span>
        </div>
      </div>
    </button>
  );
}
