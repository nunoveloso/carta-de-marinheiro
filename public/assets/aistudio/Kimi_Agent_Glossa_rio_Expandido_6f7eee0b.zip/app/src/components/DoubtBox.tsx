import { useEffect, useRef, useState } from "react";
import type { RieamScenario } from "@/data/rieam-scenarios";
import { answerQuestion, type InstructorAnswer } from "@/lib/instructor";
import type { Term } from "@/lib/glossary";
import { trpc } from "@/providers/trpc";
import { Flag, MessagesSquare, Send } from "lucide-react";

interface Msg {
  id: number;
  role: "bot" | "user";
  text: string;
  answer?: InstructorAnswer;
}

/**
 * Caixa de dúvidas pós-resposta de um cenário R.I.E.A.M.
 * O instrutor responde com base no glossário/manual e conhece o próprio cenário.
 */
export function DoubtBox({
  scenario,
  terms,
  onOpenSlug,
}: {
  scenario: RieamScenario;
  terms: Term[];
  onOpenSlug: (slug: string) => void;
}) {
  const feedback = trpc.rieam.feedback.useMutation();

  const [messages, setMessages] = useState<Msg[]>([]);
  const [input, setInput] = useState("");
  const [disagreeOpen, setDisagreeOpen] = useState(false);
  const [disagreeText, setDisagreeText] = useState("");
  const [sentFlag, setSentFlag] = useState(false);
  const nextId = useRef(1);

  // recomeçar a conversa em cada cenário
  useEffect(() => {
    setMessages([]);
    setInput("");
    setDisagreeOpen(false);
    setDisagreeText("");
    setSentFlag(false);
  }, [scenario.id]);

  const termBySlug = new Map(terms.map((t) => [t.slug, t]));

  // termo sintético com a explicação do próprio cenário, para o instrutor
  // conseguir responder a «porquê?» sobre a situação
  const contextTerm: Term = {
    id: -1,
    slug: `__cenario-${scenario.id}`,
    term: `Este cenário (${scenario.rule})`,
    definition: `${scenario.prompt} ${scenario.explanation}`,
    section: "R.I.E.A.M.",
    subsection: null,
    category: "R.I.E.A.M.",
    subcategory: "R.I.E.A.M.",
    illustration: "",
    wikiUrl: null,
    photoUrl: null,
    photoPage: null,
    sortOrder: 0,
    createdAt: "",
  };

  const ask = (raw: string) => {
    const q = raw.trim();
    if (!q) return;
    const answer = answerQuestion(q, terms, contextTerm);
    // nunca sugerir o termo sintético como ficha
    answer.termSlugs = answer.termSlugs.filter((s) => !s.startsWith("__cenario-"));
    setMessages((m) => [
      ...m,
      { id: nextId.current++, role: "user", text: q },
      { id: nextId.current++, role: "bot", text: answer.text, answer },
    ]);
    setInput("");
  };

  const sendDisagree = () => {
    const msg = disagreeText.trim();
    if (msg.length < 3 || feedback.isPending) return;
    feedback.mutate(
      { scenarioId: scenario.id, message: msg },
      {
        onSuccess: () => {
          setSentFlag(true);
          setDisagreeOpen(false);
          setDisagreeText("");
        },
      },
    );
  };

  return (
    <div className="mt-4 border border-border bg-background">
      <div className="flex items-center gap-2 border-b border-border px-4 py-3">
        <MessagesSquare className="h-4 w-4 text-primary" />
        <p className="font-mono-naut text-[11px] font-semibold uppercase tracking-[0.14em]">
          Ainda tens dúvidas? Pergunta ao instrutor
        </p>
      </div>

      <div className="space-y-4 p-4">
        {messages.map((m) => (
          <div key={m.id} className={m.role === "user" ? "text-right" : ""}>
            <div
              className={`inline-block max-w-[92%] border px-3.5 py-2.5 text-left text-[14px] leading-relaxed whitespace-pre-line ${
                m.role === "bot"
                  ? "border-border bg-card"
                  : "border-primary bg-primary text-primary-foreground"
              }`}
            >
              {m.text}
            </div>
            {m.answer && m.answer.termSlugs.length > 0 && (
              <div className="mt-1.5 flex flex-wrap gap-1.5">
                {m.answer.termSlugs.map((slug) => {
                  const t = termBySlug.get(slug);
                  if (!t) return null;
                  return (
                    <button
                      key={slug}
                      type="button"
                      onClick={() => onOpenSlug(slug)}
                      className="font-mono-naut border border-primary/60 bg-background px-2 py-1 text-[10px] font-medium uppercase tracking-[0.1em] text-primary transition-colors hover:bg-primary hover:text-primary-foreground"
                    >
                      {t.term}
                    </button>
                  );
                })}
              </div>
            )}
          </div>
        ))}

        {messages.length === 0 && (
          <p className="text-[13px] text-muted-foreground">
            Por exemplo: «Porque é que me tenho de afastar?» ou «O que é uma marcação constante?»
          </p>
        )}

        <form
          className="flex gap-2"
          onSubmit={(e) => {
            e.preventDefault();
            ask(input);
          }}
        >
          <input
            value={input}
            onChange={(e) => setInput(e.target.value)}
            placeholder="Escreve a tua dúvida sobre este cenário…"
            className="min-h-10 flex-1 border border-border bg-card px-3 text-[14px] outline-none placeholder:text-muted-foreground focus:border-primary focus-visible:ring-2 focus-visible:ring-ring"
          />
          <button
            type="submit"
            disabled={!input.trim()}
            className="flex min-h-10 min-w-10 items-center justify-center border border-primary bg-primary px-3 text-primary-foreground transition-opacity disabled:opacity-40"
            aria-label="Enviar dúvida"
          >
            <Send className="h-4 w-4" />
          </button>
        </form>

        {/* discordar da resposta oficial */}
        {sentFlag ? (
          <p className="border border-[#1e7d4f] bg-[#dcebe1] px-3.5 py-2.5 text-[13px] text-[#14563a]">
            Obrigado — a tua observação ficou registada. Se tiveres razão, corrijo este cenário na próxima revisão.
          </p>
        ) : disagreeOpen ? (
          <div className="border border-[#b3402f] bg-[#f3ded9]/40 p-3.5">
            <p className="text-[13px] font-medium text-foreground">
              Achas que a resposta certa devia ser outra? Explica porquê — se tiveres razão, corrijo o cenário.
            </p>
            <textarea
              value={disagreeText}
              onChange={(e) => setDisagreeText(e.target.value)}
              rows={3}
              placeholder="Ex.: Neste caso o B está sem governo, logo…"
              className="mt-2 w-full border border-border bg-background px-3 py-2 text-[14px] outline-none placeholder:text-muted-foreground focus:border-primary focus-visible:ring-2 focus-visible:ring-ring"
            />
            {feedback.isError && (
              <p className="mt-1.5 text-[12.5px] text-[#b3402f]">
                Não consegui registar agora — tenta outra vez daqui a pouco.
              </p>
            )}
            <div className="mt-2 flex justify-end gap-2">
              <button
                type="button"
                onClick={() => setDisagreeOpen(false)}
                className="font-mono-naut min-h-9 border border-border bg-background px-3 text-[10.5px] font-medium uppercase tracking-[0.1em] transition-colors hover:bg-secondary"
              >
                Cancelar
              </button>
              <button
                type="button"
                onClick={sendDisagree}
                disabled={disagreeText.trim().length < 3 || feedback.isPending}
                className="font-mono-naut min-h-9 border border-[#b3402f] bg-[#b3402f] px-3 text-[10.5px] font-semibold uppercase tracking-[0.1em] text-white transition-opacity disabled:opacity-40"
              >
                {feedback.isPending ? "A enviar…" : "Enviar observação"}
              </button>
            </div>
          </div>
        ) : (
          <button
            type="button"
            onClick={() => setDisagreeOpen(true)}
            className="font-mono-naut flex min-h-9 items-center gap-1.5 border border-border bg-background px-3 text-[10.5px] font-medium uppercase tracking-[0.1em] text-muted-foreground transition-colors hover:border-[#b3402f] hover:text-[#b3402f]"
          >
            <Flag className="h-3.5 w-3.5" />
            Discordo desta resposta
          </button>
        )}
      </div>
    </div>
  );
}
