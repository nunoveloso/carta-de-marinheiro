import { useEffect, useMemo, useRef } from "react";
import { Link } from "react-router";
import { Dialog, DialogContent, DialogTitle } from "@/components/ui/dialog";
import { TermIllustration } from "@/illustrations";
import {
  categoryColor,
  categorySoft,
  isForeign,
  linkedSlugs,
  linkify,
  manualSectionFor,
  type Term,
  type TermIndexEntry,
} from "@/lib/glossary";
import { ArrowLeft, ArrowRight, BookMarked, ExternalLink, Link2, Tag, X } from "lucide-react";

export function TermDetail({
  term,
  open,
  onOpenChange,
  onPrev,
  onNext,
  position,
  total,
  index = [],
  onNavigate,
}: {
  term: Term | null;
  open: boolean;
  onOpenChange: (open: boolean) => void;
  onPrev: () => void;
  onNext: () => void;
  position: number;
  total: number;
  index?: TermIndexEntry[];
  onNavigate?: (slug: string) => void;
}) {
  const scrollRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    scrollRef.current?.scrollTo({ top: 0 });
  }, [term?.slug]);

  const segments = useMemo(
    () => (term ? linkify(term.definition, index, term.slug) : []),
    [term, index],
  );
  const related = useMemo(() => {
    if (!term) return [];
    const slugs = linkedSlugs(term.definition, index, term.slug);
    return slugs
      .map((s) => index.find((e) => e.slug === s))
      .filter((e): e is TermIndexEntry => !!e);
  }, [term, index]);

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent
        ref={scrollRef}
        className="max-h-[92dvh] w-[calc(100vw-2rem)] max-w-2xl gap-0 overflow-y-auto rounded-none border-primary bg-card p-0 [&>button:last-child]:hidden"
        aria-describedby={undefined}
      >
        {term && (
          <div>
            <div className="flex items-start justify-between gap-3 border-b border-border p-4 sm:p-5">
              <div className="min-w-0">
                <DialogTitle className="text-2xl font-semibold leading-tight tracking-tight sm:text-[28px]">
                  <span className={isForeign(term.slug) ? "italic" : ""}>{term.term}</span>
                </DialogTitle>
                <div className="mt-2 flex flex-wrap items-center gap-2">
                  <span
                    className="font-mono-naut px-1.5 py-0.5 text-[10px] font-semibold uppercase tracking-[0.1em]"
                    style={{
                      background: categorySoft(term.category),
                      color: categoryColor(term.category),
                    }}
                  >
                    {term.category}
                  </span>
                  <span className="font-mono-naut text-[11px] uppercase tracking-[0.1em] text-muted-foreground">
                    {term.subcategory}
                  </span>
                </div>
              </div>
              <button
                type="button"
                onClick={() => onOpenChange(false)}
                aria-label="Fechar"
                className="flex h-11 w-11 shrink-0 cursor-pointer items-center justify-center border border-border text-foreground transition-colors hover:bg-secondary focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring"
              >
                <X className="h-5 w-5" />
              </button>
            </div>

            <div className="aspect-[8/5] w-full border-b border-border">
              <TermIllustration name={term.illustration} />
            </div>

            <div className="space-y-5 p-4 sm:p-6">
              <p className="text-[16.5px] leading-[1.75]">
                {segments.map((seg, i) =>
                  seg.slug ? (
                    <button
                      key={i}
                      type="button"
                      onClick={() => onNavigate?.(seg.slug!)}
                      className="cursor-pointer font-medium text-primary underline decoration-[#b3402f]/60 decoration-2 underline-offset-4 transition-colors hover:decoration-[#b3402f] focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring"
                    >
                      {seg.text}
                    </button>
                  ) : (
                    <span key={i}>{seg.text}</span>
                  ),
                )}
              </p>

              {term.photoUrl && (
                <figure className="border border-border">
                  <img
                    src={term.photoUrl}
                    alt={`Fotografia: ${term.term}`}
                    loading="lazy"
                    className="max-h-72 w-full object-contain bg-secondary/30"
                  />
                  <figcaption className="border-t border-border bg-secondary/40 px-3.5 py-2 font-mono-naut text-[10px] uppercase tracking-[0.12em] text-muted-foreground">
                    Fonte:{" "}
                    <a
                      href={term.photoPage ?? "https://commons.wikimedia.org"}
                      target="_blank"
                      rel="noreferrer"
                      className="underline decoration-1 underline-offset-2 transition-colors hover:text-primary"
                    >
                      Wikimedia Commons
                    </a>
                  </figcaption>
                </figure>
              )}

              {related.length > 0 && (
                <div className="border border-border bg-secondary/40 p-3.5">
                  <p className="font-mono-naut mb-2 flex items-center gap-1.5 text-[10px] uppercase tracking-[0.14em] text-muted-foreground">
                    <Link2 className="h-3 w-3" /> Ver também
                  </p>
                  <div className="flex flex-wrap gap-1.5">
                    {related.map((r) => (
                      <button
                        key={r.slug}
                        type="button"
                        onClick={() => onNavigate?.(r.slug)}
                        className="font-mono-naut min-h-9 cursor-pointer border border-border bg-card px-2.5 text-[11px] font-medium uppercase tracking-[0.06em] transition-colors hover:border-primary hover:bg-primary hover:text-primary-foreground focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring"
                      >
                        {r.term}
                      </button>
                    ))}
                  </div>
                </div>
              )}

              <dl className="border border-border">
                <div className="flex gap-3 border-b border-border p-3.5">
                  <span className="mt-0.5 text-muted-foreground">
                    <Tag className="h-3.5 w-3.5" />
                  </span>
                  <div>
                    <dt className="font-mono-naut text-[10px] uppercase tracking-[0.14em] text-muted-foreground">
                      Categoria
                    </dt>
                    <dd className="mt-0.5 text-[15px] font-medium leading-snug">
                      <Link
                        to={`/?categoria=${encodeURIComponent(term.category)}`}
                        onClick={() => onOpenChange(false)}
                        className="text-primary underline decoration-2 underline-offset-4 transition-colors hover:decoration-[#b3402f] focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring"
                      >
                        {term.category}
                      </Link>
                      <span className="text-foreground/70"> · {term.subcategory}</span>
                    </dd>
                  </div>
                </div>
                <div className={`flex gap-3 p-3.5 ${term.wikiUrl ? "border-b border-border" : ""}`}>
                  <span className="mt-0.5 text-muted-foreground">
                    <BookMarked className="h-3.5 w-3.5" />
                  </span>
                  <div>
                    <dt className="font-mono-naut text-[10px] uppercase tracking-[0.14em] text-muted-foreground">
                      Secção do manual
                    </dt>
                    <dd className="mt-0.5 text-[15px] font-medium leading-snug">
                      {manualSectionFor(term.section) ? (
                        <Link
                          to={`/manual#manual-${manualSectionFor(term.section)}`}
                          onClick={() => onOpenChange(false)}
                          className="text-primary underline decoration-2 underline-offset-4 transition-colors hover:decoration-[#b3402f] focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring"
                        >
                          {term.section}
                        </Link>
                      ) : (
                        term.section
                      )}
                      {term.subsection && (
                        <span className="mt-0.5 block text-[13.5px] font-normal text-muted-foreground">
                          {term.subsection}
                        </span>
                      )}
                    </dd>
                  </div>
                </div>
                {term.wikiUrl && (
                  <div className="flex gap-3 p-3.5">
                    <span className="mt-0.5 text-muted-foreground">
                      <ExternalLink className="h-3.5 w-3.5" />
                    </span>
                    <div>
                      <dt className="font-mono-naut text-[10px] uppercase tracking-[0.14em] text-muted-foreground">
                        Saber mais
                      </dt>
                      <dd className="mt-0.5 text-[15px] font-medium leading-snug">
                        <a
                          href={term.wikiUrl}
                          target="_blank"
                          rel="noreferrer"
                          className="text-primary underline decoration-2 underline-offset-4 transition-colors hover:decoration-[#b3402f]"
                        >
                          Artigo na Wikipédia ↗
                        </a>
                      </dd>
                    </div>
                  </div>
                )}
              </dl>

              {total > 1 && (
                <div className="flex items-center justify-between gap-3 pt-1">
                  <NavButton dir="prev" onClick={onPrev} disabled={total < 2} />
                  <span className="font-mono-naut text-[11px] uppercase tracking-[0.14em] text-muted-foreground">
                    {position + 1} / {total}
                  </span>
                  <NavButton dir="next" onClick={onNext} disabled={total < 2} />
                </div>
              )}
            </div>
          </div>
        )}
      </DialogContent>
    </Dialog>
  );
}

function NavButton({
  dir,
  onClick,
  disabled,
}: {
  dir: "prev" | "next";
  onClick: () => void;
  disabled: boolean;
}) {
  return (
    <button
      type="button"
      onClick={onClick}
      disabled={disabled}
      className="font-mono-naut flex min-h-11 cursor-pointer items-center gap-2 border border-primary px-3 text-[11px] font-semibold uppercase tracking-[0.12em] text-primary transition-colors hover:bg-primary hover:text-primary-foreground disabled:cursor-not-allowed disabled:opacity-40 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring"
    >
      {dir === "prev" ? <ArrowLeft className="h-4 w-4" /> : null}
      {dir === "prev" ? "Anterior" : "Seguinte"}
      {dir === "next" ? <ArrowRight className="h-4 w-4" /> : null}
    </button>
  );
}
