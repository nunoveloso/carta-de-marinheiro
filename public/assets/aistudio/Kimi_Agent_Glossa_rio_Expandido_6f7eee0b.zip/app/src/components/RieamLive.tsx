// Simulador R.I.E.A.M. interativo — os barcos estão em movimento (vista de
// cima) e o utilizador tem 30 segundos para decidir até ao abalroamento.
// Depois da decisão, a animação mostra o desfecho: manobra correcta e
// passagem em segurança, ou abalroamento.
import { useCallback, useEffect, useMemo, useRef, useState } from "react";
import { ArrowRight, BookOpen, Check, RotateCcw, ShipWheel } from "lucide-react";
import { C } from "@/illustrations/shared";
import { SW, SH, dir, easeInOut, lerpAngle, TopVessel } from "@/components/RieamScene";
import { GlossaryText } from "@/components/GlossaryText";
import { DoubtBox } from "@/components/DoubtBox";
import { RIEAM_SCENARIOS, TOPICS, type RieamScenario, type Vessel } from "@/data/rieam-scenarios";
import type { Term, TermIndexEntry } from "@/lib/glossary";

const LIVE_ROUND = 5;
const DECISION_S = 30;
const HIT_DIST = 42; // distância centro-a-centro que conta como abalroamento

interface LiveVessel {
  x: number;
  y: number;
  heading: number;
  speed: number; // px/s
}

function shuffle<T>(arr: T[]): T[] {
  const a = [...arr];
  for (let i = a.length - 1; i > 0; i--) {
    const j = Math.floor(Math.random() * (i + 1));
    [a[i], a[j]] = [a[j], a[i]];
  }
  return a;
}

/** rumo (graus, convenção dir()) que aponta de (x,y) para (tx,ty) */
function headingTo(x: number, y: number, tx: number, ty: number): number {
  return (Math.atan2(ty - y, tx - x) * 180) / Math.PI + 90;
}

/**
 * Atribui velocidades iniciais para que os dois barcos convirjam para um
 * ponto de abalroamento sensivelmente ao fim de DECISION_S segundos
 * (quando a geometria o permite).
 */
function planCourse(vessels: Vessel[]): LiveVessel[] {
  const out: LiveVessel[] = vessels.map((v) => ({
    x: v.x,
    y: v.y,
    heading: v.heading,
    speed: v.stopped ? 0 : 7,
  }));
  if (vessels.length !== 2) return out;
  const [a, b] = vessels;
  const [la, lb] = out;
  if (b.stopped || a.stopped) {
    // alvo parado: o que se move chega lá ao fim de DECISION_S
    const mov = b.stopped ? la : lb;
    const tgt = b.stopped ? b : a;
    const [dx, dy] = dir(mov.heading);
    const wx = tgt.x - mov.x;
    const wy = tgt.y - mov.y;
    const along = Math.max(50, wx * dx + wy * dy);
    mov.speed = along / (DECISION_S + 2);
    return out;
  }
  const [d1x, d1y] = dir(a.heading);
  const [d2x, d2y] = dir(b.heading);
  const cross = d1x * d2y - d1y * d2x;
  const wx = b.x - a.x;
  const wy = b.y - a.y;
  if (Math.abs(cross) > 1e-4) {
    const t = (wx * d2y - wy * d2x) / cross;
    const s = (wx * d1y - wy * d1x) / cross;
    if (t > 40 && s > 40) {
      la.speed = t / (DECISION_S + 2);
      lb.speed = s / (DECISION_S + 2);
      return out;
    }
  }
  // rumos paralelos (alcance): quem vem de trás anda mais depressa
  const alongAhead = wx * d1x + wy * d1y; // > 0 → B está à frente de A
  if (alongAhead > 0) {
    la.speed = 8.5;
    lb.speed = 4.5;
  } else {
    la.speed = 4.5;
    lb.speed = 8.5;
  }
  return out;
}

/** estrela de explosão para o abalroamento */
function burstPath(r1: number, r2: number, n = 12): string {
  let d = "";
  for (let i = 0; i < n * 2; i++) {
    const r = i % 2 === 0 ? r1 : r2;
    const ang = (Math.PI * i) / n - Math.PI / 2;
    d += `${i === 0 ? "M" : "L"}${(r * Math.cos(ang)).toFixed(1)} ${(r * Math.sin(ang)).toFixed(1)} `;
  }
  return d + "Z";
}

const KIND_LABEL: Record<Vessel["kind"], string> = {
  motor: "motor",
  vela: "vela",
  "vela-motor": "veleiro a motor",
  pesca: "pesca",
  "sem-governo": "sem governo",
};

type Phase = "decidir" | "desfecho" | "fim";
type Outcome = "certo" | "errado" | "tempo";

/* ---------------- cenário interativo ---------------- */

function RieamLiveScenario({
  scenario,
  index,
  all,
  termBySlug,
  onOpenSlug,
  onResult,
  onNext,
  isLast,
}: {
  scenario: RieamScenario;
  index: TermIndexEntry[];
  all: Term[];
  termBySlug: Map<string, string>;
  onOpenSlug: (slug: string) => void;
  onResult: (ok: boolean) => void;
  onNext: () => void;
  isLast: boolean;
}) {
  const whoMode = scenario.ask === "who";
  const meIdx = Math.max(0, scenario.vessels.findIndex((v) => v.id === scenario.you));
  const me = scenario.vessels[meIdx];

  const [phase, setPhase] = useState<Phase>("decidir");
  const [outcome, setOutcome] = useState<Outcome | null>(null);
  const [timeLeft, setTimeLeft] = useState(DECISION_S);
  const [vs, setVs] = useState<LiveVessel[]>(() => planCourse(scenario.vessels));
  const [turns, setTurns] = useState<Record<number, { from: number; to: number; t0: number }>>({});
  const [hit, setHit] = useState<[number, number] | null>(null);
  const [pickedOpt, setPickedOpt] = useState<number | null>(null);
  const badSince = useRef<number | null>(null);
  const reported = useRef(false);

  /* loop principal de animação */
  useEffect(() => {
    if (phase === "fim") return;
    const scale = phase === "desfecho" ? 4.5 : 1;
    const bad = phase === "desfecho" && outcome !== "certo";
    let raf = 0;
    let last = performance.now();
    const step = (now: number) => {
      const dt = Math.min(0.05, (now - last) / 1000);
      last = now;
      if (phase === "decidir") setTimeLeft((t) => Math.max(0, t - dt));
      setVs((prev) => {
        const next = prev.map((v, i) => {
          let h = v.heading;
          let sp = v.speed;
          const tv = turns[i];
          if (tv) {
            const p = Math.min(1, (now - tv.t0) / 1200);
            h = lerpAngle(tv.from, tv.to, easeInOut(p));
          }
          return { x: v.x, y: v.y, heading: h, speed: sp };
        });
        if (bad && next.length === 2) {
          // decisão errada / tempo esgotado: os dois convergem para o impacto
          const t0 = badSince.current ?? now;
          badSince.current = t0;
          const deadline = t0 + 1500;
          const mx = (next[0].x + next[1].x) / 2;
          const my = (next[0].y + next[1].y) / 2;
          for (const v of next) {
            const want = headingTo(v.x, v.y, mx, my);
            v.heading = lerpAngle(v.heading, want, Math.min(1, dt * 3.2));
            const dist = Math.hypot(mx - v.x, my - v.y);
            v.speed = dist / Math.max(0.12, (deadline - now) / 1000) / scale;
          }
        }
        return next.map((v) => {
          const [dx, dy] = dir(v.heading);
          return { ...v, x: v.x + dx * v.speed * dt * scale, y: v.y + dy * v.speed * dt * scale };
        });
      });
      raf = requestAnimationFrame(step);
    };
    raf = requestAnimationFrame(step);
    return () => cancelAnimationFrame(raf);
  }, [phase, turns, outcome]);

  /* detectar o abalroamento no desfecho mau */
  useEffect(() => {
    if (phase !== "desfecho" || outcome === "certo" || vs.length !== 2) return;
    const d = Math.hypot(vs[0].x - vs[1].x, vs[0].y - vs[1].y);
    if (d < HIT_DIST) {
      setHit([(vs[0].x + vs[1].x) / 2, (vs[0].y + vs[1].y) / 2]);
      setPhase("fim");
    }
  }, [vs, phase, outcome]);

  /* salvaguarda: forçar o impacto se a homing falhar */
  useEffect(() => {
    if (phase !== "desfecho" || outcome === "certo") return;
    const t = window.setTimeout(() => {
      setVs((cur) => {
        setHit([(cur[0].x + cur[1].x) / 2, (cur[0].y + cur[1].y) / 2]);
        return cur;
      });
      setPhase("fim");
    }, 4200);
    return () => window.clearTimeout(t);
  }, [phase, outcome]);

  /* comunicar o resultado (uma vez) */
  useEffect(() => {
    if (phase === "fim" && !reported.current) {
      reported.current = true;
      onResult(outcome === "certo");
    }
  }, [phase, outcome, onResult]);

  const decide = useCallback(
    (choice: number | null) => {
      setPhase((p) => {
        if (p !== "decidir") return p;
        const ok = choice !== null && choice === scenario.correct;
        setPickedOpt(choice);
        setOutcome(ok ? "certo" : choice === null ? "tempo" : "errado");
        if (ok && scenario.resolution) {
          const t0 = performance.now();
          const tr: Record<number, { from: number; to: number; t0: number }> = {};
          scenario.resolution.forEach((r) => {
            tr[r.idx] = { from: vs[r.idx].heading, to: r.heading, t0 };
          });
          setTurns(tr);
          window.setTimeout(() => setPhase("fim"), 3600);
        } else {
          badSince.current = null;
        }
        return "desfecho";
      });
    },
    [scenario.correct, scenario.resolution, vs],
  );

  /* tempo esgotado */
  useEffect(() => {
    if (phase === "decidir" && timeLeft <= 0) decide(null);
  }, [timeLeft, phase, decide]);

  const decided = phase !== "decidir";
  const wasCorrect = outcome === "certo";
  const lowTime = phase === "decidir" && timeLeft <= 10;
  const frac = Math.max(0, timeLeft / DECISION_S);
  const ringR = 24;
  const ringC = 2 * Math.PI * ringR;

  const wave =
    "M0 0 q 8 -5 16 0 t 16 0 t 16 0 t 16 0 t 16 0 t 16 0 t 16 0 t 16 0 t 16 0 t 16 0 t 16 0 t 16 0 t 16 0 t 16 0 t 16 0 t 16 0 t 16 0 t 16 0 t 16 0 t 16 0 t 16 0 t 16 0 t 16 0 t 16 0 t 16 0 t 16 0 t 16 0 t 16 0 t 16 0 t 16 0 t 16 0 t 16 0 t 16 0 t 16 0 t 16 0 t 16 0 t 16 0 t 16 0 t 16 0 t 16 0";

  return (
    <>
      <div className="mt-6 border border-primary bg-card shadow-[6px_6px_0_0_#0b3a55]">
        <div className="flex items-center justify-between gap-2 border-b border-border bg-primary px-4 py-2.5">
          <div className="flex items-center gap-2">
            <span className="font-mono-naut flex h-6 w-6 items-center justify-center border border-white/60 text-[11px] font-bold text-primary-foreground">
              {me.id}
            </span>
            <p className="font-mono-naut text-[11px] font-semibold uppercase tracking-[0.14em] text-primary-foreground">
              Tu és a embarcação {me.id} · {me.tag ?? KIND_LABEL[me.kind]}
            </p>
          </div>
          <p className="font-mono-naut flex items-center gap-1.5 text-[10px] uppercase tracking-[0.14em] text-white/80">
            <span className="inline-block h-2 w-2 animate-pulse rounded-full bg-[#e8b93e]" />
            em movimento
          </p>
        </div>

        <div className="aspect-[16/9] w-full border-b border-border">
          <svg viewBox={`0 0 ${SW} ${SH}`} className="h-full w-full" role="img" aria-label="Situação de navegação em movimento">
            <rect x={0} y={0} width={SW} height={SH} fill={C.sea} />

            {/* canal marítimo balizado */}
            {scenario.channel && (
              <g>
                <line x1={232} y1={0} x2={232} y2={SH} stroke={C.inkSoft} strokeWidth={1.6} strokeDasharray="8 6" />
                <line x1={408} y1={0} x2={408} y2={SH} stroke={C.inkSoft} strokeWidth={1.6} strokeDasharray="8 6" />
                {([60, 180, 300] as const).map((y) => (
                  <g key={y}>
                    <path d={`M232 ${y + 7} L 226 ${y - 5} L 238 ${y - 5} Z`} fill="#b3402f" stroke={C.ink} strokeWidth={0.8} />
                    <path d={`M408 ${y + 7} L 402 ${y - 5} L 414 ${y - 5} Z`} fill="#1e7d4f" stroke={C.ink} strokeWidth={0.8} />
                  </g>
                ))}
                <text x={320} y={22} textAnchor="middle" fontSize={10.5} fontWeight={600} fill={C.inkSoft} style={{ fontFamily: "'IBM Plex Mono', monospace", textTransform: "uppercase", letterSpacing: "0.1em" }}>canal</text>
              </g>
            )}
            {!scenario.channel && (
              <g stroke={C.seaLine} strokeWidth={1.3} fill="none" opacity={0.9}>
                <path d={wave} transform="translate(10 60)" />
                <path d={wave} transform="translate(-30 170)" />
                <path d={wave} transform="translate(24 285)" />
              </g>
            )}

            {/* rosa dos ventos */}
            <g transform="translate(600 42)">
              <circle r={17} fill={C.paper} stroke={C.ink} strokeWidth={1.4} />
              <path d="M0 9 L 0 -11 M0 -11 L -4 -4 M0 -11 L 4 -4" stroke={C.ink} strokeWidth={1.6} fill="none" />
              <text y={-22} textAnchor="middle" fontSize={11} fontWeight={700} fill={C.ink} style={{ fontFamily: "'IBM Plex Mono', monospace" }}>N</text>
            </g>

            {/* vento (em baixo à esquerda, longe do cronómetro) */}
            {scenario.wind !== undefined && (
              <g transform={scenario.channel ? "translate(322 322)" : "translate(96 306)"}>
                {(() => {
                  const [dx, dy] = dir(scenario.wind + 180);
                  const ang = Math.atan2(dy, dx);
                  return (
                    <g>
                      <line x1={0} y1={0} x2={dx * 36} y2={dy * 36} stroke={C.inkSoft} strokeWidth={2.4} />
                      <path
                        d={`M${dx * 44} ${dy * 44} L ${dx * 36 + 6.5 * Math.cos(ang + Math.PI * 0.8)} ${dy * 36 + 6.5 * Math.sin(ang + Math.PI * 0.8)} L ${dx * 36 + 6.5 * Math.cos(ang - Math.PI * 0.8)} ${dy * 36 + 6.5 * Math.sin(ang - Math.PI * 0.8)} Z`}
                        fill={C.inkSoft}
                      />
                    </g>
                  );
                })()}
                <text x={0} y={26} textAnchor="middle" fontSize={10.5} fontWeight={600} fill={C.inkSoft} style={{ fontFamily: "'IBM Plex Mono', monospace", textTransform: "uppercase", letterSpacing: "0.08em" }}>vento</text>
              </g>
            )}

            {/* embarcações em movimento */}
            {scenario.vessels.map((v, i) => {
              const lv = vs[i];
              const [dx, dy] = dir(lv.heading);
              const moving = lv.speed > 0.15 && !(scenario.vessels[i].stopped);
              const sternX = lv.x - dx * 30;
              const sternY = lv.y - dy * 30;
              const [ldx, ldy] = dir(v.heading + 140);
              const lx = Math.min(Math.max(lv.x + ldx * 46, 28), SW - 28);
              const ly = Math.min(Math.max(lv.y + ldy * 46, 28), SH - 24);
              const clickable = whoMode && !decided;
              const isCorrectVessel = whoMode && decided && i === scenario.correct;
              return (
                <g key={v.id}>
                  {/* esteira */}
                  {moving && (
                    <path
                      d={`M${sternX} ${sternY} L${sternX - dx * 42 - dy * 9} ${sternY - dy * 42 + dx * 9} M${sternX} ${sternY} L${sternX - dx * 42 + dy * 9} ${sternY - dy * 42 - dx * 9}`}
                      stroke="#ffffff"
                      strokeWidth={1.8}
                      opacity={0.4}
                      fill="none"
                      strokeLinecap="round"
                    />
                  )}
                  {/* seta de rumo */}
                  {moving && (
                    <line
                      x1={lv.x + dx * 36}
                      y1={lv.y + dy * 36}
                      x2={lv.x + dx * (52 + lv.speed * 3.2)}
                      y2={lv.y + dy * (52 + lv.speed * 3.2)}
                      stroke={C.inkSoft}
                      strokeWidth={2}
                      strokeDasharray="6 5"
                    />
                  )}
                  <g transform={`translate(${lv.x} ${lv.y}) rotate(${lv.heading})`}>
                    <TopVessel v={v} />
                  </g>
                  {isCorrectVessel && <circle cx={lv.x} cy={lv.y} r={42} fill="none" stroke={C.green} strokeWidth={3} />}

                  {/* etiqueta: apenas a letra */}
                  <g transform={`translate(${lx} ${ly})`}>
                    <circle r={12.5} fill={C.paper} stroke={isCorrectVessel ? C.green : C.ink} strokeWidth={1.6} />
                    <text y={4.5} textAnchor="middle" fontSize={13} fontWeight={700} fill={C.ink} style={{ fontFamily: "'IBM Plex Mono', monospace" }}>{v.id}</text>
                  </g>

                  {/* alvo de clique (modo «who») */}
                  {clickable && (
                    <circle
                      cx={lv.x}
                      cy={lv.y}
                      r={42}
                      fill="transparent"
                      style={{ cursor: "pointer" }}
                      onClick={() => decide(i)}
                    >
                      <title>{`Escolher a embarcação ${v.id}`}</title>
                    </circle>
                  )}
                  {clickable && (
                    <circle cx={lv.x} cy={lv.y} r={42} fill="none" stroke={C.ink} strokeWidth={1.2} strokeDasharray="3 6" opacity={0.45} pointerEvents="none" />
                  )}
                </g>
              );
            })}

            {/* contagem decrescente até ao abalroamento */}
            {phase === "decidir" && (
              <g transform="translate(82 48)">
                <circle r={ringR + 4} fill={C.paper} stroke={lowTime ? "#b3402f" : C.ink} strokeWidth={1.6} />
                <circle
                  r={ringR}
                  fill="none"
                  stroke={lowTime ? "#b3402f" : "#0b3a55"}
                  strokeWidth={3.4}
                  strokeDasharray={ringC}
                  strokeDashoffset={ringC * (1 - frac)}
                  transform="rotate(-90)"
                  strokeLinecap="round"
                />
                <text y={5.5} textAnchor="middle" fontSize={16} fontWeight={700} fill={lowTime ? "#b3402f" : C.ink} style={{ fontFamily: "'IBM Plex Mono', monospace" }}>
                  {Math.ceil(timeLeft)}
                </text>
                <text y={ringR + 18} textAnchor="middle" fontSize={9} fontWeight={600} fill={lowTime ? "#b3402f" : C.inkSoft} style={{ fontFamily: "'IBM Plex Mono', monospace", textTransform: "uppercase", letterSpacing: "0.06em" }}>
                  até ao abalroamento
                </text>
              </g>
            )}

            {/* abalroamento */}
            {hit && (
              <g>
                <g transform={`translate(${hit[0]} ${hit[1]})`}>
                  <path d={burstPath(48, 20)} fill="#b3402f" stroke="#7c2418" strokeWidth={2}>
                    <animateTransform attributeName="transform" type="scale" from="0.2" to="1" dur="0.25s" fill="freeze" />
                  </path>
                  <path d={burstPath(27, 11)} fill="#e8b93e" />
                </g>
                <g transform={`translate(${SW / 2} 34)`}>
                  <rect x={-132} y={-17} width={264} height={32} fill="#b3402f" />
                  <text y={5} textAnchor="middle" fontSize={14} fontWeight={700} fill="#fff" style={{ fontFamily: "'IBM Plex Mono', monospace", letterSpacing: "0.12em" }}>
                    ABALROAMENTO!
                  </text>
                </g>
              </g>
            )}

            {/* passagem em segurança */}
            {phase === "fim" && wasCorrect && (
              <g transform={`translate(${SW / 2} 34)`}>
                <rect x={-160} y={-17} width={320} height={32} fill="#1e7d4f" />
                <text y={5} textAnchor="middle" fontSize={14} fontWeight={700} fill="#fff" style={{ fontFamily: "'IBM Plex Mono', monospace", letterSpacing: "0.12em" }}>
                  PASSARAM EM SEGURANÇA
                </text>
              </g>
            )}

            <rect x={1} y={1} width={SW - 2} height={SH - 2} fill="none" stroke={lowTime ? "#b3402f" : C.ink} strokeWidth={2} />
          </svg>
        </div>

        <div className="p-5 sm:p-6">
          <div className="flex items-center justify-between gap-3">
            <p className="font-mono-naut text-[10px] uppercase tracking-[0.18em] text-muted-foreground">
              {whoMode ? "clica na embarcação — antes do abalroamento" : "decide a manobra — antes do abalroamento"}
            </p>
            <span className="font-mono-naut border border-primary px-2 py-0.5 text-[10px] uppercase tracking-[0.12em] text-primary">
              {TOPICS.find((t) => t.id === scenario.topic)?.label}
            </span>
          </div>
          <h2 className="mt-2 text-lg font-semibold leading-snug tracking-tight sm:text-xl">
            <GlossaryText text={scenario.prompt} index={index} onOpen={onOpenSlug} />
          </h2>
        </div>

        {/* opções (modo «do») */}
        {!whoMode && scenario.options && (
          <div className="flex flex-col gap-2 border-t border-border p-4 sm:p-5">
            {scenario.options.map((opt, i) => {
              const isCorrect = i === scenario.correct;
              const isPicked = i === pickedOpt;
              let cls = "border-border bg-background hover:border-primary hover:bg-secondary";
              if (decided && isCorrect) cls = "border-[#1e7d4f] bg-[#dcebe1]";
              else if (decided && isPicked) cls = "border-[#b3402f] bg-[#f3ded9]";
              else if (decided) cls = "border-border bg-background opacity-60";
              return (
                <button
                  key={i}
                  type="button"
                  disabled={decided}
                  onClick={() => decide(i)}
                  className={`flex min-h-11 w-full cursor-pointer items-start gap-3 border p-3 text-left transition-colors focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring disabled:cursor-default ${cls}`}
                >
                  <span className="font-mono-naut mt-0.5 flex h-5 w-5 shrink-0 items-center justify-center border border-current text-[10px] font-semibold">
                    {decided && isCorrect ? <Check className="h-3.5 w-3.5 text-[#1e7d4f]" /> : String.fromCharCode(65 + i)}
                  </span>
                  <span className="text-[14px] leading-snug font-medium">
                    <GlossaryText text={opt} index={index} onOpen={onOpenSlug} />
                  </span>
                </button>
              );
            })}
          </div>
        )}

        {/* feedback + explicação */}
        {phase === "fim" && (
          <div className="border-t border-border p-4 sm:p-5">
            <p className={`font-mono-naut text-[11px] font-semibold uppercase tracking-[0.16em] ${wasCorrect ? "text-[#1e7d4f]" : "text-[#b3402f]"}`}>
              {wasCorrect
                ? "certo! manobra executada a tempo"
                : outcome === "tempo"
                  ? "o tempo esgotou-se — abalroamento por indecisão"
                  : whoMode
                    ? `não — quem se afasta é ${scenario.vessels[scenario.correct].id}`
                    : "manobra errada — abalroamento!"}
            </p>
            <div className="mt-2 flex items-start gap-3">
              <span className="font-mono-naut mt-0.5 shrink-0 border border-[#b3402f] px-2 py-1 text-[10px] uppercase tracking-[0.1em] text-[#b3402f]">
                {scenario.rule}
              </span>
              <p className="text-[14px] leading-relaxed text-foreground">
                <GlossaryText text={scenario.explanation} index={index} onOpen={onOpenSlug} />
              </p>
            </div>
            {scenario.slugs.length > 0 && (
              <div className="mt-3 flex flex-wrap items-center gap-2">
                <span className="font-mono-naut text-[10px] uppercase tracking-[0.14em] text-muted-foreground">
                  saber mais:
                </span>
                {scenario.slugs.map((slug) => (
                  <button
                    key={slug}
                    type="button"
                    onClick={() => onOpenSlug(slug)}
                    className="font-mono-naut flex min-h-9 cursor-pointer items-center gap-1.5 border border-[#b3402f] px-2.5 text-[10px] font-medium uppercase tracking-[0.1em] text-[#b3402f] transition-colors hover:bg-[#b3402f] hover:text-white focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring"
                  >
                    <BookOpen className="h-3 w-3" />
                    {termBySlug.get(slug) ?? slug}
                  </button>
                ))}
              </div>
            )}
          </div>
        )}
      </div>

      {/* dúvidas */}
      {phase === "fim" && <DoubtBox scenario={scenario} terms={all} onOpenSlug={onOpenSlug} />}

      {/* seguinte */}
      {phase === "fim" && (
        <div className="mt-4 flex justify-end">
          <button
            type="button"
            onClick={onNext}
            className="font-mono-naut flex min-h-11 cursor-pointer items-center gap-2 border border-primary bg-primary px-4 text-[11px] font-semibold uppercase tracking-[0.12em] text-primary-foreground transition-colors hover:bg-[#0d4767] focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring"
          >
            {isLast ? "Ver resultado" : "Seguinte"}
            <ArrowRight className="h-4 w-4" />
          </button>
        </div>
      )}
    </>
  );
}

/* ---------------- ronda interativa ---------------- */

export function RieamLiveRound({
  index,
  all,
  termBySlug,
  onOpenSlug,
  onExit,
}: {
  index: TermIndexEntry[];
  all: Term[];
  termBySlug: Map<string, string>;
  onOpenSlug: (slug: string) => void;
  onExit: () => void;
}) {
  const pool = useMemo(
    () =>
      RIEAM_SCENARIOS.filter(
        (s) =>
          s.you &&
          s.resolution &&
          s.resolution.length > 0 &&
          s.vessels.length === 2 &&
          !s.vessels[Math.max(0, s.vessels.findIndex((v) => v.id === s.you))].stopped,
      ),
    [],
  );
  const [round, setRound] = useState<RieamScenario[]>([]);
  const [current, setCurrent] = useState(0);
  const [score, setScore] = useState(0);
  const [failed, setFailed] = useState<string[]>([]);
  const [finished, setFinished] = useState(false);
  const [best, setBest] = useState<number | null>(null);

  const rebuild = useCallback(() => {
    setRound(shuffle(pool).slice(0, Math.min(LIVE_ROUND, pool.length)));
    setCurrent(0);
    setScore(0);
    setFailed([]);
    setFinished(false);
  }, [pool]);

  useEffect(() => {
    rebuild();
    const b = Number(localStorage.getItem("rieam-live-best"));
    setBest(Number.isFinite(b) && b > 0 ? b : null);
  }, [rebuild]);

  const sc = round[current] ?? null;

  const handleResult = useCallback(
    (ok: boolean) => {
      if (!sc) return;
      if (ok) setScore((s) => s + 1);
      else setFailed((f) => [...f, sc.id]);
    },
    [sc],
  );

  const next = () => {
    if (current + 1 >= round.length) {
      setFinished(true);
      const prev = Number(localStorage.getItem("rieam-live-best")) || 0;
      if (score > prev) {
        localStorage.setItem("rieam-live-best", String(score));
        setBest(score);
      }
    } else {
      setCurrent((c) => c + 1);
    }
  };

  const failedScenarios = failed.map((id) => RIEAM_SCENARIOS.find((s) => s.id === id)!).filter(Boolean);

  if (!sc) return null;

  if (finished) {
    return (
      <div className="mt-6 flex flex-col items-center gap-4 border border-primary bg-card px-6 py-12 text-center shadow-[6px_6px_0_0_#0b3a55]">
        <ShipWheel className="h-9 w-9 text-primary" strokeWidth={1.5} />
        <p className="text-2xl font-semibold tracking-tight sm:text-3xl">
          {score} em {round.length}
        </p>
        <p className="font-mono-naut text-[12px] uppercase tracking-[0.2em] text-[#b3402f]">
          {Math.round((score / round.length) * 100)}% de abalroamentos evitados
        </p>
        <p className="max-w-md text-[15px] text-muted-foreground">
          No mar, decidir tarde é decidir mal: a manobra certa feita cedo é quase sempre pequena e segura.
        </p>
        {best !== null && (
          <p className="font-mono-naut text-[11px] uppercase tracking-[0.14em] text-muted-foreground">
            melhor resultado: {best} / {round.length}
          </p>
        )}
        <div className="flex flex-wrap justify-center gap-3">
          <button
            type="button"
            onClick={rebuild}
            className="font-mono-naut flex min-h-11 cursor-pointer items-center gap-2 border border-primary bg-primary px-4 text-[11px] font-semibold uppercase tracking-[0.12em] text-primary-foreground transition-colors hover:bg-[#0d4767] focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring"
          >
            <RotateCcw className="h-4 w-4" />
            Nova ronda
          </button>
          <button
            type="button"
            onClick={onExit}
            className="font-mono-naut flex min-h-11 cursor-pointer items-center gap-2 border border-primary bg-card px-4 text-[11px] font-semibold uppercase tracking-[0.12em] text-primary transition-colors hover:bg-secondary focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring"
          >
            Mudar de modo
          </button>
        </div>

        {failedScenarios.length > 0 && (
          <div className="mt-4 w-full max-w-2xl border-t border-border pt-5 text-left">
            <p className="font-mono-naut mb-3 text-[11px] uppercase tracking-[0.16em] text-muted-foreground">
              para rever · {failedScenarios.length}
            </p>
            <div className="flex flex-col gap-3">
              {failedScenarios.map((s) => (
                <div key={s.id} className="border border-border bg-background p-4">
                  <div className="flex items-center justify-between gap-3">
                    <p className="text-[14px] font-semibold leading-snug">{s.prompt}</p>
                    <span className="font-mono-naut shrink-0 border border-[#b3402f] px-2 py-1 text-[10px] uppercase tracking-[0.1em] text-[#b3402f]">
                      {s.rule}
                    </span>
                  </div>
                  <p className="mt-2 text-[13px] leading-relaxed text-muted-foreground">{s.explanation}</p>
                </div>
              ))}
            </div>
          </div>
        )}
      </div>
    );
  }

  return (
    <>
      <div className="mt-5 flex items-center justify-between gap-3">
        <p className="font-mono-naut text-[11px] uppercase tracking-[0.14em] text-muted-foreground">
          situação {current + 1} de {round.length} · <span className="text-primary">{score} certas</span>
        </p>
        <button
          type="button"
          onClick={onExit}
          className="font-mono-naut min-h-9 cursor-pointer border border-border bg-card px-3 text-[10px] font-medium uppercase tracking-[0.1em] text-muted-foreground transition-colors hover:border-primary hover:text-primary focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring"
        >
          Mudar de modo
        </button>
      </div>
      <RieamLiveScenario
        key={sc.id}
        scenario={sc}
        index={index}
        all={all}
        termBySlug={termBySlug}
        onOpenSlug={onOpenSlug}
        onResult={handleResult}
        onNext={next}
        isLast={current + 1 >= round.length}
      />
      {/* progresso */}
      <div className="mt-5">
        <div className="h-1.5 w-full bg-secondary">
          <div
            className="h-full bg-primary transition-all duration-300"
            style={{ width: `${(current / round.length) * 100}%` }}
          />
        </div>
      </div>
    </>
  );
}
