import { useEffect, useState } from "react";
import { C } from "@/illustrations/shared";
import type { RieamScenario, Vessel } from "@/data/rieam-scenarios";

export const SW = 640;
export const SH = 360;

export function dir(deg: number): [number, number] {
  const r = ((deg - 90) * Math.PI) / 180;
  return [Math.cos(r), Math.sin(r)];
}

/** interpola um rumo pelo caminho mais curto (graus) */
export function lerpAngle(from: number, to: number, t: number): number {
  const d = ((to - from + 540) % 360) - 180;
  return from + d * t;
}

export function easeInOut(t: number): number {
  return t < 0.5 ? 2 * t * t : 1 - Math.pow(-2 * t + 2, 2) / 2;
}

/* ---------------- desenho das embarcações (vista de cima, proa para cima) ---------------- */

function Hull({ children }: { children?: React.ReactNode }) {
  return (
    <g>
      <path
        d="M0 -34 C 9 -22 11 -8 11 6 L 11 30 L -11 30 L -11 6 C -11 -8 -9 -22 0 -34 Z"
        fill={C.ink}
      />
      {children}
    </g>
  );
}

/** Balão diurno içado, desenhado acima do convés */
function Shape({ kind }: { kind: NonNullable<Vessel["shape"]> }) {
  const black = "#111";
  if (kind === "esfera") return <circle cx={0} cy={-46} r={5.2} fill={black} />;
  if (kind === "esferas")
    return (
      <g fill={black}>
        <circle cx={0} cy={-42} r={4.6} />
        <circle cx={0} cy={-54} r={4.6} />
      </g>
    );
  if (kind === "bicone")
    // dois cones unidos pelos vértices: o de cima com a ponta para baixo,
    // o de baixo com a ponta para cima — as pontas tocam-se
    return (
      <g fill={black}>
        <path d="M-5.5 -52 L 0 -43 L 5.5 -52 Z" />
        <path d="M-5.5 -34 L 0 -43 L 5.5 -34 Z" />
      </g>
    );
  // cone-down: cónico com o vértice para baixo (vela + motor)
  return <path d="M-6 -52 L 0 -38 L 6 -52 Z" fill={black} />;
}

export function TopVessel({ v }: { v: Vessel }) {
  return (
    <g>
      {v.kind === "vela" || v.kind === "vela-motor" ? (
        <Hull>
          <line x1={0} y1={-26} x2={0} y2={26} stroke={C.paper} strokeWidth={2.2} />
          {v.kind === "vela" && v.boom && (
            <line
              x1={0}
              y1={6}
              x2={v.boom === "eb" ? 17 : -17}
              y2={30}
              stroke={C.paper}
              strokeWidth={2.2}
            />
          )}
          {v.kind === "vela-motor" && (
            <g>
              <circle cx={0} cy={30} r={3.2} fill={C.paper} />
              <path d="M-6 36 q 6 4 12 0" stroke={C.inkSoft} strokeWidth={1.6} fill="none" />
            </g>
          )}
        </Hull>
      ) : (
        <Hull>
          <path d="M-7 6 h14 M-7 14 h14" stroke={C.paper} strokeWidth={2} fill="none" />
          <rect x={-5} y={-16} width={10} height={12} rx={2} fill={C.paper} opacity={0.85} />
        </Hull>
      )}
      {v.kind === "pesca" && (
        <g stroke={C.inkSoft} strokeWidth={1.6} strokeDasharray="4 3" fill={C.inkSoft}>
          <line x1={-7} y1={30} x2={-24} y2={54} />
          <line x1={7} y1={30} x2={24} y2={54} />
          <circle cx={-24} cy={54} r={2.6} stroke="none" />
          <circle cx={24} cy={54} r={2.6} stroke="none" />
        </g>
      )}
      {v.kind === "sem-governo" && (
        <g fill="#111">
          <circle cx={22} cy={-8} r={4.6} />
          <circle cx={22} cy={10} r={4.6} />
        </g>
      )}
      {v.shape && <Shape kind={v.shape} />}
      {v.flagA && (
        <g>
          <line x1={0} y1={-28} x2={0} y2={-64} stroke={C.ink} strokeWidth={2} />
          <path d="M0 -64 h 26 v 18 l -7 -4.5 l -7 4.5 l -12 -4.5 Z" fill="#fff" stroke={C.ink} strokeWidth={1.2} />
          <path d="M13 -64 h 13 v 18 l -7 -4.5 Z" fill="#1d4f91" />
        </g>
      )}
    </g>
  );
}

/* ---------------- setas e arcos ---------------- */

function SceneArrow({ x1, y1, x2, y2, color, dashed = true, width = 2 }: {
  x1: number; y1: number; x2: number; y2: number; color: string; dashed?: boolean; width?: number;
}) {
  const angle = Math.atan2(y2 - y1, x2 - x1);
  const hx = x2 - 8 * Math.cos(angle);
  const hy = y2 - 8 * Math.sin(angle);
  const a1 = angle + Math.PI * 0.8;
  const a2 = angle - Math.PI * 0.8;
  return (
    <g>
      <line x1={x1} y1={y1} x2={hx} y2={hy} stroke={color} strokeWidth={width} strokeDasharray={dashed ? "6 5" : undefined} />
      <path
        d={`M${x2} ${y2} L ${hx + 6.5 * Math.cos(a1)} ${hy + 6.5 * Math.sin(a1)} L ${hx + 6.5 * Math.cos(a2)} ${hy + 6.5 * Math.sin(a2)} Z`}
        fill={color}
      />
    </g>
  );
}

function TurnArc({ cx, cy, from, to, color, radius = 52, dashed = true }: {
  cx: number; cy: number; from: number; to: number; color: string; radius?: number; dashed?: boolean;
}) {
  const r = radius;
  const a1 = ((from - 90) * Math.PI) / 180;
  const a2 = ((to - 90) * Math.PI) / 180;
  const p = (a: number) => [cx + r * Math.cos(a), cy + r * Math.sin(a)];
  const [x1, y1] = p(a1);
  const [x2, y2] = p(a2);
  let delta = ((to - from) % 360 + 360) % 360;
  const sweep = delta <= 180 ? 1 : 0;
  const large = delta > 180 ? 1 : 0;
  const tangent = a2 + (sweep ? Math.PI / 2 : -Math.PI / 2);
  return (
    <g>
      <path d={`M${x1} ${y1} A ${r} ${r} 0 ${large} ${sweep} ${x2} ${y2}`} fill="none" stroke={color} strokeWidth={2.2} strokeDasharray={dashed ? "5 4" : undefined} />
      <path
        d={`M${x2} ${y2} L ${x2 - 8 * Math.cos(tangent - 0.42)} ${y2 - 8 * Math.sin(tangent - 0.42)} L ${x2 - 8 * Math.cos(tangent + 0.42)} ${y2 - 8 * Math.sin(tangent + 0.42)} Z`}
        fill={color}
      />
    </g>
  );
}

/* ---------------- cena ---------------- */

export function RieamScene({ scenario, answered, picked, onVesselPick }: {
  scenario: RieamScenario;
  answered: boolean;
  picked: number | null;
  onVesselPick?: (idx: number) => void;
}) {
  const whoMode = scenario.ask === "who";
  const resMap = new Map((answered ? scenario.resolution ?? [] : []).map((r) => [r.idx, r]));

  /* animação da resolução: a embarcação guina suavemente para o novo rumo
     em vez de «saltar» instantaneamente (0 = rumo antigo, 1 = rumo novo) */
  const [anim, setAnim] = useState(0);
  useEffect(() => {
    if (!answered) {
      setAnim(0);
      return;
    }
    if (typeof window !== "undefined" && window.matchMedia?.("(prefers-reduced-motion: reduce)").matches) {
      setAnim(1);
      return;
    }
    let raf = 0;
    const t0 = performance.now();
    const DURATION = 1300;
    const tick = (now: number) => {
      const t = Math.min(1, (now - t0) / DURATION);
      setAnim(t);
      if (t < 1) raf = requestAnimationFrame(tick);
    };
    raf = requestAnimationFrame(tick);
    return () => cancelAnimationFrame(raf);
  }, [answered, scenario.id]);
  const eased = easeInOut(anim);
  const wave = "M0 0 q 8 -5 16 0 t 16 0 t 16 0 t 16 0 t 16 0 t 16 0 t 16 0 t 16 0 t 16 0 t 16 0 t 16 0 t 16 0 t 16 0 t 16 0 t 16 0 t 16 0 t 16 0 t 16 0 t 16 0 t 16 0 t 16 0 t 16 0 t 16 0 t 16 0 t 16 0 t 16 0 t 16 0 t 16 0 t 16 0 t 16 0 t 16 0 t 16 0 t 16 0 t 16 0 t 16 0 t 16 0 t 16 0";

  return (
    <svg viewBox={`0 0 ${SW} ${SH}`} className="h-full w-full" role="img" aria-label="Esquema da situação de navegação">
      <rect x={0} y={0} width={SW} height={SH} fill={C.sea} />

      {/* canal marítimo balizado (não é um canal físico com terra) */}
      {scenario.channel && (
        <g>
          <line x1={232} y1={0} x2={232} y2={SH} stroke={C.inkSoft} strokeWidth={1.6} strokeDasharray="8 6" />
          <line x1={408} y1={0} x2={408} y2={SH} stroke={C.inkSoft} strokeWidth={1.6} strokeDasharray="8 6" />
          {/* balizas laterais do canal */}
          {([60, 180, 300] as const).map((y) => (
            <g key={y}>
              <path d={`M232 ${y + 7} L 226 ${y - 5} L 238 ${y - 5} Z`} fill="#b3402f" stroke={C.ink} strokeWidth={0.8} />
              <path d={`M408 ${y + 7} L 402 ${y - 5} L 414 ${y - 5} Z`} fill="#1e7d4f" stroke={C.ink} strokeWidth={0.8} />
            </g>
          ))}
          <text x={320} y={22} textAnchor="middle" fontSize={10.5} fontWeight={600} fill={C.inkSoft} style={{ fontFamily: "'IBM Plex Mono', monospace", textTransform: "uppercase", letterSpacing: "0.1em" }}>canal</text>
          <g stroke={C.seaLine} strokeWidth={1.3} fill="none" opacity={0.9}>
            <path d={wave} transform="translate(10 120)" />
            <path d={wave} transform="translate(410 250)" />
          </g>
        </g>
      )}
      {!scenario.channel && (
        <g stroke={C.seaLine} strokeWidth={1.3} fill="none" opacity={0.9}>
          <path d={wave} transform="translate(10 60)" />
          <path d={wave} transform="translate(-30 170)" />
          <path d={wave} transform="translate(24 285)" />
        </g>
      )}

      {/* rosa dos ventos simples */}
      <g transform="translate(600 42)">
        <circle r={17} fill={C.paper} stroke={C.ink} strokeWidth={1.4} />
        <path d="M0 9 L 0 -11 M0 -11 L -4 -4 M0 -11 L 4 -4" stroke={C.ink} strokeWidth={1.6} fill="none" />
        <text y={-22} textAnchor="middle" fontSize={11} fontWeight={700} fill={C.ink} style={{ fontFamily: "'IBM Plex Mono', monospace" }}>N</text>
      </g>

      {/* vento */}
      {scenario.wind !== undefined && (
        <g transform={scenario.channel ? "translate(322 322)" : "translate(64 46)"}>
          {(() => {
            const to = scenario.wind + 180;
            const [dx, dy] = dir(to);
            return <SceneArrow x1={0} y1={0} x2={dx * 44} y2={dy * 44} color={C.inkSoft} dashed={false} width={2.4} />;
          })()}
          <text x={0} y={scenario.channel ? 26 : -10} textAnchor="middle" fontSize={10.5} fontWeight={600} fill={C.inkSoft} style={{ fontFamily: "'IBM Plex Mono', monospace", textTransform: "uppercase", letterSpacing: "0.08em" }}>vento</text>
        </g>
      )}

      {/* embarcações */}
      {scenario.vessels.map((v, i) => {
        const res = resMap.get(i);
        const newHeading = res?.heading;
        const shownHeading = newHeading !== undefined ? lerpAngle(v.heading, newHeading, eased) : v.heading;
        const [dx, dy] = dir(shownHeading);
        const bowX = v.x + dx * 36;
        const bowY = v.y + dy * 36;
        const endX = v.x + dx * 118;
        const endY = v.y + dy * 118;
        const [odx, ody] = dir(v.heading);
        const isCorrectVessel = whoMode && answered && i === scenario.correct;
        const isWrongPick = whoMode && answered && picked === i && i !== scenario.correct;
        const clickable = whoMode && !answered && !!onVesselPick;
        // posição da etiqueta: a ré, para bombordo (limitada à cena)
        const [ldx, ldy] = dir(v.heading + 140);
        const lx = Math.min(Math.max(v.x + ldx * 46, 28), SW - 28);
        const ly = Math.min(Math.max(v.y + ldy * 46, 28), SH - 24);
        return (
          <g key={v.id}>
            {/* linha de rumo antiga (esbatida quando muda de rumo) */}
            {newHeading !== undefined && !v.stopped && (
              <SceneArrow x1={v.x + odx * 36} y1={v.y + ody * 36} x2={v.x + odx * 96} y2={v.y + ody * 96} color="#b9c7cf" width={1.6} />
            )}
            {!v.stopped && newHeading === undefined && (
              <SceneArrow x1={bowX} y1={bowY} x2={endX} y2={endY} color={C.inkSoft} dashed />
            )}
            {/* novo rumo: aparece e acompanha a guinada animada */}
            {!v.stopped && newHeading !== undefined && (
              <g opacity={anim}>
                <SceneArrow x1={bowX} y1={bowY} x2={endX} y2={endY} color={C.green} dashed={false} />
              </g>
            )}
            {newHeading !== undefined && (
              <g opacity={anim}>
                <TurnArc cx={v.x} cy={v.y} from={v.heading} to={newHeading} color={C.green} />
              </g>
            )}

            {/* rumos alternativos igualmente válidos */}
            {res?.alts?.map((alt) => {
              const [adx, ady] = dir(alt);
              return (
                <g key={alt} opacity={0.55 * anim}>
                  <TurnArc cx={v.x} cy={v.y} from={v.heading} to={alt} color={C.green} radius={74} />
                  <SceneArrow x1={v.x + adx * 36} y1={v.y + ady * 36} x2={v.x + adx * 108} y2={v.y + ady * 108} color={C.green} />
                </g>
              );
            })}

            <g transform={`translate(${v.x} ${v.y}) rotate(${shownHeading})`}>
              <TopVessel v={v} />
            </g>

            {/* anéis de feedback */}
            {isCorrectVessel && <circle cx={v.x} cy={v.y} r={42} fill="none" stroke={C.green} strokeWidth={3} />}
            {isWrongPick && <circle cx={v.x} cy={v.y} r={42} fill="none" stroke={C.red} strokeWidth={3} strokeDasharray="6 4" />}

            {/* etiqueta: apenas a letra (o tipo deduz-se do texto) */}
            <g transform={`translate(${lx} ${ly})`}>
              <circle r={12.5} fill={C.paper} stroke={isCorrectVessel ? C.green : isWrongPick ? C.red : C.ink} strokeWidth={1.6} />
              <text y={4.5} textAnchor="middle" fontSize={13} fontWeight={700} fill={C.ink} style={{ fontFamily: "'IBM Plex Mono', monospace" }}>{v.id}</text>
            </g>

            {/* alvo de clique */}
            <circle
              cx={v.x}
              cy={v.y}
              r={44}
              fill="transparent"
              style={clickable ? { cursor: "pointer" } : undefined}
              onClick={clickable ? () => onVesselPick!(i) : undefined}
            >
              {clickable && <title>{`Escolher a embarcação ${v.id}`}</title>}
            </circle>
            {clickable && (
              <circle cx={v.x} cy={v.y} r={44} fill="none" stroke={C.ink} strokeWidth={1.2} strokeDasharray="3 6" opacity={0.45} pointerEvents="none" />
            )}
          </g>
        );
      })}

      <rect x={1} y={1} width={SW - 2} height={SH - 2} fill="none" stroke={C.ink} strokeWidth={2} />
    </svg>
  );
}
