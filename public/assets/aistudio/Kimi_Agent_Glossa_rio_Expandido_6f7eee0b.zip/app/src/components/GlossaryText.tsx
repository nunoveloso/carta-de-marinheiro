import { useEffect, useMemo, useRef, useState } from "react";
import { linkify, type TermIndexEntry } from "@/lib/glossary";
import { BookMarked } from "lucide-react";

/**
 * Texto em que as palavras presentes no glossário aparecem sublinhadas
 * a pontos. Clicar numa palavra mostra um pequeno pin «Definir»; clicar
 * no pin abre a carta do glossário (via onOpen).
 */
export function GlossaryText({
  text,
  index,
  onOpen,
  excludeSlug = "",
}: {
  text: string;
  index: TermIndexEntry[];
  onOpen: (slug: string) => void;
  excludeSlug?: string;
}) {
  const segments = useMemo(
    () => linkify(text, index, excludeSlug),
    [text, index, excludeSlug],
  );
  const [pin, setPin] = useState<{ slug: string; top: number; left: number } | null>(null);
  const rootRef = useRef<HTMLSpanElement>(null);

  useEffect(() => {
    if (!pin) return;
    const onDoc = (e: MouseEvent) => {
      if (rootRef.current && !rootRef.current.contains(e.target as Node)) setPin(null);
    };
    const onKey = (e: KeyboardEvent) => {
      if (e.key === "Escape") setPin(null);
    };
    document.addEventListener("mousedown", onDoc);
    document.addEventListener("keydown", onKey);
    return () => {
      document.removeEventListener("mousedown", onDoc);
      document.removeEventListener("keydown", onKey);
    };
  }, [pin]);

  const openPin = (e: React.MouseEvent<HTMLElement>, slug: string) => {
    e.stopPropagation();
    e.preventDefault();
    const root = rootRef.current;
    if (!root) return;
    const rr = root.getBoundingClientRect();
    const r = e.currentTarget.getBoundingClientRect();
    setPin((p) =>
      p?.slug === slug
        ? null
        : { slug, top: r.bottom - rr.top + 4, left: Math.max(0, r.left - rr.left) },
    );
  };

  return (
    <span ref={rootRef} className="relative">
      {segments.map((seg, i) =>
        seg.slug ? (
          <span
            key={i}
            role="button"
            tabIndex={0}
            onClick={(e) => openPin(e, seg.slug!)}
            onKeyDown={(e) => {
              if (e.key === "Enter" || e.key === " ") {
                e.preventDefault();
                e.stopPropagation();
                const root = rootRef.current;
                if (!root) return;
                const rr = root.getBoundingClientRect();
                const r = e.currentTarget.getBoundingClientRect();
                setPin({ slug: seg.slug!, top: r.bottom - rr.top + 4, left: Math.max(0, r.left - rr.left) });
              }
            }}
            className="cursor-help underline decoration-primary/70 decoration-dotted decoration-[1.5px] underline-offset-4 transition-colors hover:text-primary focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring"
          >
            {seg.text}
          </span>
        ) : (
          <span key={i}>{seg.text}</span>
        ),
      )}
      {pin && (
        <span className="absolute z-30" style={{ top: pin.top, left: pin.left }}>
          <button
            type="button"
            onClick={(e) => {
              e.stopPropagation();
              const slug = pin.slug;
              setPin(null);
              onOpen(slug);
            }}
            className="font-mono-naut flex min-h-9 cursor-pointer items-center gap-1.5 border border-primary bg-primary px-2.5 text-[10px] font-semibold uppercase tracking-[0.1em] whitespace-nowrap text-primary-foreground shadow-[3px_3px_0_0_rgba(11,58,85,0.35)] transition-colors hover:bg-[#0d4767] focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring"
          >
            <BookMarked className="h-3 w-3" />
            Definir
          </button>
        </span>
      )}
    </span>
  );
}
