import { useCallback, useEffect, useMemo, useState } from "react";
import { AppHeader } from "@/components/AppHeader";
import { GlossaryText } from "@/components/GlossaryText";
import { TermDetail } from "@/components/TermDetail";
import { Skeleton } from "@/components/ui/skeleton";
import { TermIllustration } from "@/illustrations";
import { categoryColor, categorySoft, type Term } from "@/lib/glossary";
import { trpc } from "@/providers/trpc";
import { ArrowRight, BookOpen, Check, ClipboardList, RotateCcw, X } from "lucide-react";

const ROUND_SIZE = 10;

function shuffle<T>(arr: T[]): T[] {
  const a = [...arr];
  for (let i = a.length - 1; i > 0; i--) {
    const j = Math.floor(Math.random() * (i + 1));
    [a[i], a[j]] = [a[j], a[i]];
  }
  return a;
}

interface QuizQuestion {
  term: Term;
  kind: "def" | "term";
  options: string[];
  correctIndex: number;
}

function buildQuestions(pool: Term[]): QuizQuestion[] {
  return shuffle(pool)
    .slice(0, Math.min(ROUND_SIZE, pool.length))
    .map((term) => {
      const kind: QuizQuestion["kind"] = Math.random() < 0.5 ? "def" : "term";
      // distratores: preferir a mesma subcategoria, depois a mesma categoria
      const sameSub = pool.filter((t) => t.slug !== term.slug && t.subcategory === term.subcategory);
      const sameCat = pool.filter(
        (t) => t.slug !== term.slug && t.category === term.category && t.subcategory !== term.subcategory,
      );
      const others = pool.filter((t) => t.slug !== term.slug && t.category !== term.category);
      const distractors = [...shuffle(sameSub), ...shuffle(sameCat), ...shuffle(others)].slice(0, 3);
      const options = shuffle([
        kind === "def" ? term.definition : term.term,
        ...distractors.map((d) => (kind === "def" ? d.definition : d.term)),
      ]);
      const correct = kind === "def" ? term.definition : term.term;
      return { term, kind, options, correctIndex: options.indexOf(correct) };
    });
}

export default function Quiz() {
  const list = trpc.glossary.list.useQuery({});
  const indexQuery = trpc.glossary.index.useQuery();
  const all = useMemo(() => (list.data ?? []) as Term[], [list.data]);
  const index = useMemo(() => indexQuery.data ?? [], [indexQuery.data]);
  const categories = useMemo(() => [...new Set(all.map((t) => t.category))], [all]);

  const [category, setCategory] = useState<string | null>(null);
  const [questions, setQuestions] = useState<QuizQuestion[]>([]);
  const [current, setCurrent] = useState(0);
  const [picked, setPicked] = useState<number | null>(null);
  const [score, setScore] = useState(0);
  const [finished, setFinished] = useState(false);
  const [openSlug, setOpenSlug] = useState<string | null>(null);

  const rebuild = useCallback(
    (cat: string | null) => {
      const pool = cat ? all.filter((t) => t.category === cat) : all;
      setQuestions(buildQuestions(pool));
      setCurrent(0);
      setPicked(null);
      setScore(0);
      setFinished(false);
    },
    [all],
  );

  useEffect(() => {
    if (all.length) rebuild(category);
  }, [all, category, rebuild]);

  const q = questions[current] ?? null;
  const answered = picked !== null;
  const detailTerm = openSlug ? (all.find((t) => t.slug === openSlug) ?? null) : null;

  const pick = (i: number) => {
    if (answered || !q) return;
    setPicked(i);
    if (i === q.correctIndex) setScore((s) => s + 1);
  };

  const next = () => {
    if (current + 1 >= questions.length) setFinished(true);
    else {
      setCurrent((c) => c + 1);
      setPicked(null);
    }
  };

  return (
    <div className="flex min-h-dvh flex-col">
      <AppHeader />

      <main className="mx-auto flex w-full max-w-3xl flex-1 flex-col px-4 py-6 sm:px-6">
        <div className="flex flex-wrap items-center justify-between gap-3">
          <div>
            <h1 className="text-2xl font-semibold tracking-tight sm:text-3xl">Quiz</h1>
            <p className="font-mono-naut mt-1 text-[11px] uppercase tracking-[0.16em] text-muted-foreground">
              escolha múltipla · {ROUND_SIZE} perguntas por ronda
            </p>
          </div>
          {!finished && questions.length > 0 && (
            <div className="font-mono-naut border border-border bg-card px-3 py-2 text-[11px] uppercase tracking-[0.12em]">
              <span className="text-primary">{score}</span>
              <span className="text-muted-foreground"> / {questions.length} certas</span>
            </div>
          )}
        </div>

        {/* filtro de categoria */}
        <div className="mt-5 flex flex-wrap gap-2">
          <Chip active={category === null} onClick={() => setCategory(null)} label="Todas" />
          {categories.map((c) => (
            <Chip
              key={c}
              active={category === c}
              onClick={() => setCategory(category === c ? null : c)}
              label={c}
              color={categoryColor(c)}
              soft={categorySoft(c)}
            />
          ))}
        </div>

        {list.isLoading ? (
          <Skeleton className="mt-6 aspect-[4/3] w-full rounded-none sm:aspect-[16/10]" />
        ) : !q ? (
          <div className="mt-6 flex flex-col items-center gap-3 border border-dashed border-border bg-card px-6 py-16 text-center">
            <BookOpen className="h-8 w-8 text-muted-foreground" strokeWidth={1.5} />
            <p className="text-lg font-semibold">Sem perguntas disponíveis</p>
          </div>
        ) : finished ? (
          /* resultado final */
          <div className="mt-6 flex flex-col items-center gap-4 border border-primary bg-card px-6 py-14 text-center shadow-[6px_6px_0_0_#0b3a55]">
            <ClipboardList className="h-9 w-9 text-primary" strokeWidth={1.5} />
            <p className="text-2xl font-semibold tracking-tight sm:text-3xl">
              {score} em {questions.length}
            </p>
            <p className="max-w-sm text-[15px] text-muted-foreground">
              {score === questions.length
                ? "Impecável — digno de um lobo do mar!"
                : score >= questions.length * 0.7
                  ? "Bom resultado. Revê as cartas que falhaste e tenta outra vez."
                  : "Continua a estudar — o modo de estudo ajuda a fixar as definições."}
            </p>
            <button
              type="button"
              onClick={() => rebuild(category)}
              className="font-mono-naut flex min-h-11 cursor-pointer items-center gap-2 border border-primary bg-primary px-4 text-[11px] font-semibold uppercase tracking-[0.12em] text-primary-foreground transition-colors hover:bg-[#0d4767] focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring"
            >
              <RotateCcw className="h-4 w-4" />
              Nova ronda
            </button>
          </div>
        ) : (
          <>
            {/* pergunta */}
            <div className="mt-6 border border-primary bg-card shadow-[6px_6px_0_0_#0b3a55]">
              {q.kind === "def" && (
                <div className="aspect-[16/7] w-full border-b border-border">
                  <TermIllustration name={q.term.illustration} />
                </div>
              )}
              <div className="p-5 sm:p-6">
                <p className="font-mono-naut text-[10px] uppercase tracking-[0.18em] text-muted-foreground">
                  {q.kind === "def" ? "Que definição corresponde a…" : "Que termo está definido por…"}
                </p>
                <h2 className="mt-2 text-xl font-semibold leading-snug tracking-tight sm:text-2xl">
                  {q.kind === "def" ? (
                    `«${q.term.term}»`
                  ) : (
                    <GlossaryText text={q.term.definition} index={index} onOpen={setOpenSlug} excludeSlug={q.term.slug} />
                  )}
                </h2>
              </div>
              {/* opções */}
              <div className="flex flex-col gap-2 border-t border-border p-4 sm:p-5">
                {q.options.map((opt, i) => {
                  const isCorrect = i === q.correctIndex;
                  const isPicked = i === picked;
                  let cls =
                    "border-border bg-background hover:border-primary hover:bg-secondary";
                  if (answered && isCorrect) cls = "border-[#1e7d4f] bg-[#dcebe1]";
                  else if (answered && isPicked) cls = "border-[#b3402f] bg-[#f3ded9]";
                  else if (answered) cls = "border-border bg-background opacity-60";
                  return (
                    <button
                      key={i}
                      type="button"
                      disabled={answered}
                      onClick={() => pick(i)}
                      className={`flex min-h-11 w-full cursor-pointer items-start gap-3 border p-3 text-left transition-colors focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring disabled:cursor-default ${cls}`}
                    >
                      <span className="font-mono-naut mt-0.5 flex h-5 w-5 shrink-0 items-center justify-center border border-current text-[10px] font-semibold">
                        {answered && isCorrect ? (
                          <Check className="h-3.5 w-3.5 text-[#1e7d4f]" />
                        ) : answered && isPicked ? (
                          <X className="h-3.5 w-3.5 text-[#b3402f]" />
                        ) : (
                          String.fromCharCode(65 + i)
                        )}
                      </span>
                      <span
                        className={`text-[14px] leading-snug ${q.kind === "def" ? "line-clamp-3" : "font-semibold"}`}
                      >
                        <GlossaryText text={opt} index={index} onOpen={setOpenSlug} />
                      </span>
                    </button>
                  );
                })}
              </div>
            </div>

            {/* ações após resposta */}
            {answered && (
              <div className="mt-4 flex flex-wrap items-center justify-between gap-3">
                <button
                  type="button"
                  onClick={() => setOpenSlug(q.term.slug)}
                  className="font-mono-naut flex min-h-11 cursor-pointer items-center gap-2 border border-primary px-4 text-[11px] font-semibold uppercase tracking-[0.12em] text-primary transition-colors hover:bg-primary hover:text-primary-foreground focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring"
                >
                  <BookOpen className="h-4 w-4" />
                  Saber mais — {q.term.term}
                </button>
                <button
                  type="button"
                  onClick={next}
                  className="font-mono-naut flex min-h-11 cursor-pointer items-center gap-2 border border-primary bg-primary px-4 text-[11px] font-semibold uppercase tracking-[0.12em] text-primary-foreground transition-colors hover:bg-[#0d4767] focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring"
                >
                  {current + 1 >= questions.length ? "Ver resultado" : "Seguinte"}
                  <ArrowRight className="h-4 w-4" />
                </button>
              </div>
            )}

            {/* progresso */}
            <div className="mt-5">
              <div className="font-mono-naut mb-1.5 flex justify-between text-[10px] uppercase tracking-[0.14em] text-muted-foreground">
                <span>
                  pergunta {current + 1} de {questions.length}
                </span>
                <span>{Math.round(((current + (answered ? 1 : 0)) / questions.length) * 100)}%</span>
              </div>
              <div className="h-1.5 w-full bg-secondary">
                <div
                  className="h-full bg-primary transition-all duration-300"
                  style={{ width: `${((current + (answered ? 1 : 0)) / questions.length) * 100}%` }}
                />
              </div>
            </div>
          </>
        )}
      </main>

      <TermDetail
        term={detailTerm}
        open={detailTerm !== null}
        onOpenChange={(o) => !o && setOpenSlug(null)}
        onPrev={() => {}}
        onNext={() => {}}
        position={0}
        total={1}
        index={index}
        onNavigate={setOpenSlug}
      />
    </div>
  );
}

function Chip({
  active,
  onClick,
  label,
  color,
  soft,
}: {
  active: boolean;
  onClick: () => void;
  label: string;
  color?: string;
  soft?: string;
}) {
  return (
    <button
      type="button"
      onClick={onClick}
      className="font-mono-naut min-h-11 cursor-pointer border px-3 text-[11px] font-medium uppercase tracking-[0.1em] transition-colors focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring"
      style={
        active
          ? { background: color ?? "#0b3a55", color: "#fbf9f0", borderColor: color ?? "#0b3a55" }
          : { background: soft ?? "#e8e2d2", color: color ?? "#0b3a55", borderColor: "transparent" }
      }
    >
      {label}
    </button>
  );
}
