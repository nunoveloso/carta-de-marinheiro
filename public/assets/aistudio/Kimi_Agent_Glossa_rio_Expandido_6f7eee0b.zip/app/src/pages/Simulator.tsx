import { useCallback, useEffect, useMemo, useRef, useState } from "react";
import { AppHeader } from "@/components/AppHeader";
import { GlossaryText } from "@/components/GlossaryText";
import { RieamScene } from "@/components/RieamScene";
import { TermDetail } from "@/components/TermDetail";
import { RIEAM_SCENARIOS } from "@/data/rieam-scenarios";
import {
  EXAM_QUESTIONS,
  EXAM_SECTION_LABEL,
  type ExamQuestion,
  type ExamSection,
} from "@/data/exam-questions";
import { type Term, type TermIndexEntry } from "@/lib/glossary";
import { normalizeText } from "@/lib/instructor";
import { trpc } from "@/providers/trpc";
import {
  AlarmClock,
  ArrowLeft,
  ArrowRight,
  Check,
  ClipboardCheck,
  Eye,
  Flag,
  Lightbulb,
  RotateCcw,
  X,
} from "lucide-react";

const DURATION_S = 60 * 60; // 1 hora, como no exame
const QUOTA: Record<ExamSection, number> = {
  RIEAM: 6,
  "Segurança": 5,
  Marinharia: 12,
  Outras: 7,
};

function shuffle<T>(arr: T[]): T[] {
  const a = [...arr];
  for (let i = a.length - 1; i > 0; i--) {
    const j = Math.floor(Math.random() * (i + 1));
    [a[i], a[j]] = [a[j], a[i]];
  }
  return a;
}

function buildExam(): ExamQuestion[] {
  const out: ExamQuestion[] = [];
  for (const sec of Object.keys(QUOTA) as ExamSection[]) {
    const pool = shuffle(EXAM_QUESTIONS.filter((q) => q.section === sec && !q.scenario));
    let picks = pool.slice(0, QUOTA[sec]);
    if (sec === "RIEAM") {
      // garantir sempre uma pergunta com esquema de navegação
      const withScene = shuffle(EXAM_QUESTIONS.filter((q) => q.section === sec && q.scenario));
      if (withScene.length) picks = [withScene[0], ...picks.slice(0, QUOTA[sec] - 1)];
    }
    out.push(...picks);
  }
  return out;
}

function norm(s: string): string {
  return normalizeText(s)
    .replace(/[^\p{L}\p{N}\s]/gu, " ")
    .replace(/\s+/g, " ")
    .trim();
}

function fillCorrect(q: ExamQuestion & { type: "fill" }, value: string): boolean {
  const v = norm(value);
  if (!v) return false;
  return q.answers.some((a) => norm(a) === v);
}

type SelfMark = "right" | "wrong" | null;

interface ExamState {
  questions: ExamQuestion[];
  /** respostas: mc = índice · fill/open = texto */
  answers: (number | string)[];
  selfMarks: SelfMark[];
}

function blankState(questions: ExamQuestion[]): ExamState {
  return {
    questions,
    answers: questions.map(() => ""),
    selfMarks: questions.map(() => null),
  };
}

/** pontos obtidos: mc/fill automáticos; open depende da auto-avaliação */
function scoreOf(st: ExamState) {
  let got = 0;
  let possible = 0;
  const perSection: Record<ExamSection, { got: number; possible: number }> = {
    RIEAM: { got: 0, possible: 0 },
    "Segurança": { got: 0, possible: 0 },
    Marinharia: { got: 0, possible: 0 },
    Outras: { got: 0, possible: 0 },
  };
  const pendingOpen: number[] = [];
  st.questions.forEach((q, i) => {
    possible += q.points;
    perSection[q.section].possible += q.points;
    let g = 0;
    if (q.type === "mc") {
      if (st.answers[i] === q.correct) g = q.points;
    } else if (q.type === "fill") {
      if (fillCorrect(q, String(st.answers[i] ?? ""))) g = q.points;
    } else {
      const m = st.selfMarks[i];
      if (m === "right") g = q.points;
      else if (m === null) pendingOpen.push(i);
    }
    got += g;
    perSection[q.section].got += g;
  });
  return { got, possible, perSection, pendingOpen };
}

function fmtTime(s: number): string {
  const m = Math.floor(s / 60);
  const ss = s % 60;
  return `${String(m).padStart(2, "0")}:${String(ss).padStart(2, "0")}`;
}

export default function Simulator() {
  const [phase, setPhase] = useState<"intro" | "run" | "review" | "result">("intro");
  const [st, setSt] = useState<ExamState | null>(null);
  const [current, setCurrent] = useState(0);
  const [timeLeft, setTimeLeft] = useState(DURATION_S);
  const [best, setBest] = useState<number | null>(() => {
    const b = Number(localStorage.getItem("simulador-best"));
    return Number.isFinite(b) && b > 0 ? b : null;
  });
  const timerRef = useRef<ReturnType<typeof setInterval> | null>(null);

  // glossário (palavras sublinhadas + cartas)
  const list = trpc.glossary.list.useQuery({});
  const indexQuery = trpc.glossary.index.useQuery();
  const all = useMemo(() => (list.data ?? []) as Term[], [list.data]);
  const gIndex = useMemo(() => indexQuery.data ?? [], [indexQuery.data]);
  const [openSlug, setOpenSlug] = useState<string | null>(null);
  const detailTerm = openSlug ? (all.find((t) => t.slug === openSlug) ?? null) : null;

  const finish = useCallback(() => {
    if (timerRef.current) clearInterval(timerRef.current);
    timerRef.current = null;
    setPhase((p) => (p === "run" ? "review" : p));
  }, []);

  useEffect(() => {
    if (phase !== "run") return;
    timerRef.current = setInterval(() => {
      setTimeLeft((t) => {
        if (t <= 1) {
          finish();
          return 0;
        }
        return t - 1;
      });
    }, 1000);
    return () => {
      if (timerRef.current) clearInterval(timerRef.current);
    };
  }, [phase, finish]);

  const start = () => {
    setSt(blankState(buildExam()));
    setCurrent(0);
    setTimeLeft(DURATION_S);
    setPhase("run");
  };

  const score = useMemo(() => (st ? scoreOf(st) : null), [st]);

  // guardar melhor nota quando se chega ao resultado
  useEffect(() => {
    if (phase === "result" && score && score.pendingOpen.length === 0) {
      const nota = (score.got / score.possible) * 20;
      if (best === null || nota > best) {
        setBest(nota);
        localStorage.setItem("simulador-best", String(nota));
      }
    }
  }, [phase, score, best]);

  /* ── introdução ── */
  if (phase === "intro") {
    return (
      <div className="min-h-svh bg-background">
        <AppHeader />
        <main className="mx-auto max-w-3xl px-4 py-10 sm:px-6">
          <p className="font-mono-naut text-[11px] font-semibold uppercase tracking-[0.14em] text-muted-foreground">
            Simulador de testes
          </p>
          <h1 className="mt-1 text-3xl font-bold tracking-tight">Simulador de Teste DGRM</h1>
          <p className="mt-3 text-[15px] leading-relaxed text-muted-foreground">
            Um teste completo, com o mesmo formato dos exames teóricos da DGRM: 30 perguntas em 1
            hora, distribuídas pelas matérias oficiais.
          </p>

          <div className="mt-6 border border-border bg-card">
            <div className="border-b border-border px-5 py-3">
              <p className="font-mono-naut text-[11px] font-semibold uppercase tracking-[0.14em]">
                Estrutura do teste
              </p>
            </div>
            <dl className="divide-y divide-border">
              {(Object.keys(QUOTA) as ExamSection[]).map((sec) => (
                <div key={sec} className="flex items-center justify-between px-5 py-3">
                  <dt className="text-[14px] font-medium">{EXAM_SECTION_LABEL[sec]}</dt>
                  <dd className="font-mono-naut text-[12px] text-muted-foreground">
                    {QUOTA[sec]} perguntas
                  </dd>
                </div>
              ))}
            </dl>
          </div>

          <div className="mt-4 border border-border bg-card p-5">
            <p className="font-mono-naut text-[11px] font-semibold uppercase tracking-[0.14em]">
              Critérios de avaliação (iguais ao exame)
            </p>
            <ul className="mt-2 list-disc space-y-1.5 pl-5 text-[14px] leading-relaxed text-muted-foreground">
              <li>Nota final igual ou superior a <strong className="text-foreground">12 valores</strong> (em 20).</li>
              <li>Nas perguntas de R.I.E.A.M., resultado não inferior a <strong className="text-foreground">75%</strong>.</li>
              <li>Em Segurança e Primeiros Socorros, resultado não inferior a <strong className="text-foreground">60%</strong>.</li>
              <li>
                Nas perguntas abertas, no fim comparas a tua resposta com a resposta modelo e
                auto-avalias-te — como faria o júri.
              </li>
            </ul>
          </div>

          <div className="mt-6 flex items-center gap-4">
            <button
              type="button"
              onClick={start}
              className="font-mono-naut flex min-h-12 cursor-pointer items-center gap-2 border border-primary bg-primary px-6 text-[12px] font-semibold uppercase tracking-[0.12em] text-primary-foreground transition-colors hover:bg-[#0d4767]"
            >
              <AlarmClock className="h-4.5 w-4.5" />
              Começar simulacro · 60 min
            </button>
            {best !== null && (
              <p className="font-mono-naut text-[11px] uppercase tracking-[0.12em] text-muted-foreground">
                Melhor nota: <span className="font-bold text-foreground">{best.toFixed(1)}</span> / 20
              </p>
            )}
          </div>
        </main>
      <TermDetail
        term={detailTerm}
        open={detailTerm !== null}
        onOpenChange={(o) => !o && setOpenSlug(null)}
        onPrev={() => {}}
        onNext={() => {}}
        position={0}
        total={1}
        index={gIndex}
        onNavigate={setOpenSlug}
      />
    </div>
    );
  }

  if (!st || !score) return null;
  const q = st.questions[current];

  /* ── resultado ── */
  if (phase === "result") {
    const nota = (score.got / score.possible) * 20;
    const rieamPct = score.perSection.RIEAM.possible
      ? score.perSection.RIEAM.got / score.perSection.RIEAM.possible
      : 1;
    const segPct = score.perSection["Segurança"].possible
      ? score.perSection["Segurança"].got / score.perSection["Segurança"].possible
      : 1;
    const aprovado = nota >= 12 && rieamPct >= 0.75 && segPct >= 0.6;
    return (
      <div className="min-h-svh bg-background">
        <AppHeader />
        <main className="mx-auto max-w-3xl px-4 py-10 sm:px-6">
          <p className="font-mono-naut text-[11px] font-semibold uppercase tracking-[0.14em] text-muted-foreground">
            Resultado do simulacro
          </p>
          <div className={`mt-3 border p-6 sm:p-8 ${aprovado ? "border-[#1e7d4f] bg-[#dcebe1]" : "border-[#b3402f] bg-[#f3ded9]"}`}>
            <p className={`font-mono-naut text-[12px] font-bold uppercase tracking-[0.16em] ${aprovado ? "text-[#14563a]" : "text-[#7d2a1e]"}`}>
              {aprovado ? "Apto" : "Não apto"}
            </p>
            <p className="mt-1 text-5xl font-bold tracking-tight">
              {nota.toFixed(1)} <span className="text-xl font-semibold text-muted-foreground">/ 20 valores</span>
            </p>
            {!aprovado && (
              <ul className="mt-3 list-disc space-y-1 pl-5 text-[13.5px] leading-relaxed">
                {nota < 12 && <li>Nota final inferior a 12 valores.</li>}
                {rieamPct < 0.75 && (
                  <li>R.I.E.A.M. abaixo do mínimo de 75% ({Math.round(rieamPct * 100)}%).</li>
                )}
                {segPct < 0.6 && (
                  <li>Segurança e Primeiros Socorros abaixo do mínimo de 60% ({Math.round(segPct * 100)}%).</li>
                )}
              </ul>
            )}
          </div>

          <div className="mt-5 border border-border bg-card">
            <div className="border-b border-border px-5 py-3">
              <p className="font-mono-naut text-[11px] font-semibold uppercase tracking-[0.14em]">
                Por matéria
              </p>
            </div>
            <dl className="divide-y divide-border">
              {(Object.keys(QUOTA) as ExamSection[]).map((sec) => {
                const s = score.perSection[sec];
                const pct = s.possible ? s.got / s.possible : 0;
                return (
                  <div key={sec} className="flex items-center justify-between gap-4 px-5 py-3">
                    <dt className="text-[14px] font-medium">{EXAM_SECTION_LABEL[sec]}</dt>
                    <dd className="flex items-center gap-3">
                      <span className="h-1.5 w-28 bg-secondary">
                        <span
                          className={`block h-full ${pct >= 0.6 ? "bg-[#1e7d4f]" : "bg-[#b3402f]"}`}
                          style={{ width: `${pct * 100}%` }}
                        />
                      </span>
                      <span className="font-mono-naut text-[12px] text-muted-foreground">
                        {s.got.toFixed(1)} / {s.possible.toFixed(1)}
                      </span>
                    </dd>
                  </div>
                );
              })}
            </dl>
          </div>

          <div className="mt-6 flex flex-wrap gap-3">
            <button
              type="button"
              onClick={() => {
                setCurrent(0);
                setPhase("review");
              }}
              className="font-mono-naut flex min-h-11 cursor-pointer items-center gap-2 border border-border bg-background px-4 text-[11px] font-semibold uppercase tracking-[0.12em] transition-colors hover:bg-secondary"
            >
              <Eye className="h-4 w-4" />
              Rever as respostas
            </button>
            <button
              type="button"
              onClick={start}
              className="font-mono-naut flex min-h-11 cursor-pointer items-center gap-2 border border-primary bg-primary px-4 text-[11px] font-semibold uppercase tracking-[0.12em] text-primary-foreground transition-colors hover:bg-[#0d4767]"
            >
              <RotateCcw className="h-4 w-4" />
              Novo simulacro
            </button>
          </div>
        </main>
      <TermDetail
        term={detailTerm}
        open={detailTerm !== null}
        onOpenChange={(o) => !o && setOpenSlug(null)}
        onPrev={() => {}}
        onNext={() => {}}
        position={0}
        total={1}
        index={gIndex}
        onNavigate={setOpenSlug}
      />
    </div>
    );
  }

  /* ── revisão (depois de terminar: corrigir abertas + ver tudo) ── */
  if (phase === "review") {
    const answeredAll = score.pendingOpen.length === 0;
    return (
      <div className="min-h-svh bg-background">
        <AppHeader />
        <main className="mx-auto max-w-3xl px-4 py-8 sm:px-6">
          <p className="font-mono-naut text-[11px] font-semibold uppercase tracking-[0.14em] text-muted-foreground">
            Correção
          </p>
          <h1 className="mt-1 text-2xl font-bold tracking-tight">Rever e corrigir</h1>
          {!answeredAll && (
            <p className="mt-2 border border-primary bg-secondary/60 px-4 py-3 text-[13.5px] leading-relaxed">
              Tens <strong>{score.pendingOpen.length}</strong> pergunta(s) aberta(s) por corrigir.
              Compara a tua resposta com a resposta modelo e marca se acertaste — como o júri faz no
              exame.
            </p>
          )}

          <div className="mt-6 space-y-5">
            {st.questions.map((qq, i) => (
              <ReviewCard
                key={qq.id}
                index={i}
                q={qq}
                answer={st.answers[i]}
                selfMark={st.selfMarks[i]}
                gIndex={gIndex}
                onOpenTerm={setOpenSlug}
                onSelfMark={(m) =>
                  setSt((prev) =>
                    prev
                      ? {
                          ...prev,
                          selfMarks: prev.selfMarks.map((x, j) => (j === i ? m : x)),
                        }
                      : prev,
                  )
                }
              />
            ))}
          </div>

          <div className="sticky bottom-0 mt-6 flex justify-end border-t border-border bg-background py-4">
            <button
              type="button"
              disabled={!answeredAll}
              onClick={() => setPhase("result")}
              className="font-mono-naut flex min-h-12 cursor-pointer items-center gap-2 border border-primary bg-primary px-6 text-[12px] font-semibold uppercase tracking-[0.12em] text-primary-foreground transition-opacity disabled:opacity-40"
            >
              <ClipboardCheck className="h-4.5 w-4.5" />
              {answeredAll ? "Ver resultado final" : `Faltam corrigir ${score.pendingOpen.length}`}
            </button>
          </div>
        </main>
      <TermDetail
        term={detailTerm}
        open={detailTerm !== null}
        onOpenChange={(o) => !o && setOpenSlug(null)}
        onPrev={() => {}}
        onNext={() => {}}
        position={0}
        total={1}
        index={gIndex}
        onNavigate={setOpenSlug}
      />
    </div>
    );
  }

  /* ── a decorrer ── */
  const answeredCount = st.answers.filter((a) => String(a) !== "").length;
  const lowTime = timeLeft <= 5 * 60;
  return (
    <div className="flex min-h-svh flex-col bg-background">
      <AppHeader />
      <main className="mx-auto flex w-full max-w-3xl flex-1 flex-col px-4 py-6 sm:px-6">
        <div className="flex items-center justify-between gap-4">
          <p className="font-mono-naut text-[11px] font-semibold uppercase tracking-[0.14em] text-muted-foreground">
            Pergunta {current + 1} de {st.questions.length} · {EXAM_SECTION_LABEL[q.section]}
          </p>
          <p
            className={`font-mono-naut flex items-center gap-1.5 border px-2.5 py-1.5 text-[12px] font-bold ${
              lowTime ? "border-[#b3402f] text-[#b3402f]" : "border-border text-foreground"
            }`}
          >
            <AlarmClock className="h-4 w-4" />
            {fmtTime(timeLeft)}
          </p>
        </div>
        <div className="mt-2 h-1.5 w-full bg-secondary">
          <div
            className="h-full bg-primary transition-all duration-300"
            style={{ width: `${((current + 1) / st.questions.length) * 100}%` }}
          />
        </div>

        <div className="mt-5 border border-border bg-card p-5 sm:p-6">
          <p className="font-mono-naut text-[10px] uppercase tracking-[0.16em] text-muted-foreground">
            {q.type === "mc"
              ? "escolha múltipla — uma só resposta certa"
              : q.type === "fill"
                ? "preenche o espaço em branco"
                : "responde por extenso"}{" "}
            · {q.points.toFixed(1).replace(".", ",")} valores
          </p>
          <h2 className="mt-2 text-lg font-semibold leading-snug tracking-tight">
            <GlossaryText text={q.question} index={gIndex} onOpen={setOpenSlug} />
          </h2>

          {q.scenario && (
            <div className="mt-4 border border-border">
              <div className="aspect-[16/9] w-full">
                <RieamScene
                  scenario={{ ...q.scenario, you: undefined, resolution: undefined }}
                  answered={false}
                  picked={null}
                />
              </div>
              <p className="border-t border-border bg-secondary/50 px-3 py-2 font-mono-naut text-[10px] uppercase tracking-[0.12em] text-muted-foreground">
                Esquema de navegação — deduz o tipo de cada embarcação pelo texto e pelos sinais
              </p>
            </div>
          )}

          {q.type === "mc" && (
            <div className="mt-4 flex flex-col gap-2">
              {q.options.map((opt, i) => {
                const sel = st.answers[current] === i;
                return (
                  <button
                    key={i}
                    type="button"
                    onClick={() =>
                      setSt((prev) =>
                        prev
                          ? { ...prev, answers: prev.answers.map((a, j) => (j === current ? i : a)) }
                          : prev,
                      )
                    }
                    className={`flex min-h-11 w-full cursor-pointer items-start gap-3 border p-3 text-left transition-colors focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring ${
                      sel
                        ? "border-primary bg-primary text-primary-foreground"
                        : "border-border bg-background hover:border-primary hover:bg-secondary"
                    }`}
                  >
                    <span className="font-mono-naut mt-0.5 flex h-5 w-5 shrink-0 items-center justify-center border border-current text-[10px] font-semibold">
                      {String.fromCharCode(65 + i)}
                    </span>
                    <span className="text-[14px] font-medium leading-snug">
                      <GlossaryText text={opt} index={gIndex} onOpen={setOpenSlug} />
                    </span>
                  </button>
                );
              })}
            </div>
          )}

          {q.type === "fill" && (
            <div className="mt-4">
              <input
                value={String(st.answers[current] ?? "")}
                onChange={(e) =>
                  setSt((prev) =>
                    prev
                      ? {
                          ...prev,
                          answers: prev.answers.map((a, j) => (j === current ? e.target.value : a)),
                        }
                      : prev,
                  )
                }
                placeholder="Escreve aqui a palavra ou expressão que falta…"
                className="min-h-12 w-full border border-border bg-background px-3.5 text-[15px] outline-none placeholder:text-muted-foreground focus:border-primary focus-visible:ring-2 focus-visible:ring-ring"
              />
              <p className="mt-1.5 text-[12.5px] text-muted-foreground">
                No exame em papel escreverias à mão no espaço do enunciado.
              </p>
            </div>
          )}

          {q.type === "open" && (
            <div className="mt-4">
              <textarea
                value={String(st.answers[current] ?? "")}
                onChange={(e) =>
                  setSt((prev) =>
                    prev
                      ? {
                          ...prev,
                          answers: prev.answers.map((a, j) => (j === current ? e.target.value : a)),
                        }
                      : prev,
                  )
                }
                rows={5}
                placeholder="Desenvolve a tua resposta por extenso…"
                className="w-full border border-border bg-background px-3.5 py-3 text-[15px] leading-relaxed outline-none placeholder:text-muted-foreground focus:border-primary focus-visible:ring-2 focus-visible:ring-ring"
              />
              <p className="mt-1.5 text-[12.5px] text-muted-foreground">
                No fim, vais comparar a tua resposta com a resposta modelo e auto-avaliar-te.
              </p>
            </div>
          )}
        </div>

        <div className="mt-4 flex items-center justify-between gap-3">
          <button
            type="button"
            disabled={current === 0}
            onClick={() => setCurrent((c) => Math.max(0, c - 1))}
            className="font-mono-naut flex min-h-11 cursor-pointer items-center gap-2 border border-border bg-background px-4 text-[11px] font-semibold uppercase tracking-[0.12em] transition-colors hover:bg-secondary disabled:opacity-40"
          >
            <ArrowLeft className="h-4 w-4" />
            Anterior
          </button>
          <div className="flex items-center gap-3">
            <span className="font-mono-naut text-[11px] uppercase tracking-[0.12em] text-muted-foreground">
              {answeredCount}/{st.questions.length} respondidas
            </span>
            {current + 1 < st.questions.length ? (
              <button
                type="button"
                onClick={() => setCurrent((c) => Math.min(st.questions.length - 1, c + 1))}
                className="font-mono-naut flex min-h-11 cursor-pointer items-center gap-2 border border-primary bg-primary px-4 text-[11px] font-semibold uppercase tracking-[0.12em] text-primary-foreground transition-colors hover:bg-[#0d4767]"
              >
                Seguinte
                <ArrowRight className="h-4 w-4" />
              </button>
            ) : (
              <button
                type="button"
                onClick={finish}
                className="font-mono-naut flex min-h-11 cursor-pointer items-center gap-2 border border-[#b3402f] bg-[#b3402f] px-4 text-[11px] font-semibold uppercase tracking-[0.12em] text-white transition-colors hover:bg-[#93331f]"
              >
                <Flag className="h-4 w-4" />
                Terminar teste
              </button>
            )}
          </div>
        </div>

        {current + 1 < st.questions.length && (
          <div className="mt-3 flex justify-end">
            <button
              type="button"
              onClick={finish}
              className="font-mono-naut text-[10.5px] uppercase tracking-[0.12em] text-muted-foreground underline decoration-1 underline-offset-4 transition-colors hover:text-[#b3402f]"
            >
              Terminar teste agora
            </button>
          </div>
        )}
      </main>
      <TermDetail
        term={detailTerm}
        open={detailTerm !== null}
        onOpenChange={(o) => !o && setOpenSlug(null)}
        onPrev={() => {}}
        onNext={() => {}}
        position={0}
        total={1}
        index={gIndex}
        onNavigate={setOpenSlug}
      />
    </div>
  );
}

/* ── cartão de revisão ── */

function ReviewCard({
  index,
  q,
  answer,
  selfMark,
  onSelfMark,
  gIndex,
  onOpenTerm,
}: {
  index: number;
  q: ExamQuestion;
  answer: number | string;
  selfMark: SelfMark;
  onSelfMark: (m: Exclude<SelfMark, null>) => void;
  gIndex: TermIndexEntry[];
  onOpenTerm: (slug: string) => void;
}) {
  const [showExplain, setShowExplain] = useState(false);
  let ok: boolean | null = null;
  if (q.type === "mc") ok = answer === q.correct;
  else if (q.type === "fill") ok = fillCorrect(q, String(answer ?? ""));
  else if (selfMark !== null) ok = selfMark === "right";

  // cartas do glossário sugeridas por esta pergunta
  const slugs = useMemo(() => {
    const seen = new Set<string>();
    if (q.scenario) for (const s of q.scenario.slugs) seen.add(s);
    const text = `${q.question} ${q.explain ?? ""} ${q.type === "open" ? q.modelAnswer : ""}`;
    for (const e of gIndex) {
      const t = e.term.toLowerCase();
      if (t.length >= 4 && text.toLowerCase().includes(t)) seen.add(e.slug);
    }
    return [...seen].slice(0, 4);
  }, [q, gIndex]);

  return (
    <div
      className={`border bg-card ${
        ok === true ? "border-[#1e7d4f]" : ok === false ? "border-[#b3402f]" : "border-border"
      }`}
    >
      <div className="flex items-start justify-between gap-3 border-b border-border px-4 py-3">
        <p className="text-[14px] font-semibold leading-snug">
          <span className="font-mono-naut mr-2 text-[11px] text-muted-foreground">
            {index + 1}.
          </span>
          {q.question}
        </p>
        <span
          className={`font-mono-naut mt-0.5 flex h-6 w-6 shrink-0 items-center justify-center border ${
            ok === true
              ? "border-[#1e7d4f] text-[#1e7d4f]"
              : ok === false
                ? "border-[#b3402f] text-[#b3402f]"
                : "border-border text-muted-foreground"
          }`}
        >
          {ok === true ? <Check className="h-3.5 w-3.5" /> : ok === false ? <X className="h-3.5 w-3.5" /> : "?"}
        </span>
      </div>

      {q.scenario && (
        <div className="border-b border-border">
          <div className="aspect-[16/9] w-full">
            <RieamScenarioReview scenario={q.scenario} />
          </div>
        </div>
      )}

      <div className="px-4 py-3">
        {q.type === "mc" && (
          <ul className="space-y-1.5">
            {q.options.map((opt, i) => (
              <li
                key={i}
                className={`flex items-start gap-2 text-[13.5px] leading-snug ${
                  i === q.correct
                    ? "font-semibold text-[#14563a]"
                    : answer === i
                      ? "text-[#b3402f] line-through"
                      : "text-muted-foreground"
                }`}
              >
                <span className="font-mono-naut mt-0.5 text-[10px]">{String.fromCharCode(65 + i)})</span>
                {opt}
                {i === q.correct && <Check className="mt-0.5 h-3.5 w-3.5 shrink-0 text-[#1e7d4f]" />}
              </li>
            ))}
          </ul>
        )}

        {q.type === "fill" && (
          <div className="text-[13.5px] leading-relaxed">
            <p>
              <span className="text-muted-foreground">A tua resposta: </span>
              <span className={ok ? "font-semibold text-[#14563a]" : "font-semibold text-[#b3402f]"}>
                {String(answer ?? "").trim() || "—"}
              </span>
            </p>
            {!ok && (
              <p className="mt-1">
                <span className="text-muted-foreground">Resposta certa: </span>
                <span className="font-semibold text-[#14563a]">{q.answers[0]}</span>
              </p>
            )}
          </div>
        )}

        {q.type === "open" && (
          <div className="text-[13.5px] leading-relaxed">
            <p className="text-muted-foreground">A tua resposta:</p>
            <p className="mt-0.5 whitespace-pre-line border border-border bg-background px-3 py-2">
              {String(answer ?? "").trim() || "—"}
            </p>
            <p className="mt-2 text-muted-foreground">Resposta modelo:</p>
            <p className="mt-0.5 whitespace-pre-line border border-[#1e7d4f]/50 bg-[#dcebe1]/50 px-3 py-2">
              {q.modelAnswer}
            </p>
            <div className="mt-3 flex flex-wrap items-center gap-2">
              <span className="font-mono-naut text-[10px] uppercase tracking-[0.12em] text-muted-foreground">
                Auto-avaliação:
              </span>
              <button
                type="button"
                onClick={() => onSelfMark("right")}
                className={`font-mono-naut min-h-9 cursor-pointer border px-3 text-[10.5px] font-semibold uppercase tracking-[0.1em] transition-colors ${
                  selfMark === "right"
                    ? "border-[#1e7d4f] bg-[#1e7d4f] text-white"
                    : "border-[#1e7d4f] text-[#1e7d4f] hover:bg-[#dcebe1]"
                }`}
              >
                Acertei · {q.points.toFixed(1).replace(".", ",")} val.
              </button>
              <button
                type="button"
                onClick={() => onSelfMark("wrong")}
                className={`font-mono-naut min-h-9 cursor-pointer border px-3 text-[10.5px] font-semibold uppercase tracking-[0.1em] transition-colors ${
                  selfMark === "wrong"
                    ? "border-[#b3402f] bg-[#b3402f] text-white"
                    : "border-[#b3402f] text-[#b3402f] hover:bg-[#f3ded9]"
                }`}
              >
                Falhei · 0 val.
              </button>
            </div>
          </div>
        )}

        {/* [1] saber mais — explicação curta · [2] cartas do glossário */}
        <div className="mt-3 flex flex-wrap items-center gap-2 border-t border-border/70 pt-3">
          {q.explain && (
            <button
              type="button"
              onClick={() => setShowExplain((v) => !v)}
              aria-expanded={showExplain}
              className={`font-mono-naut flex min-h-9 cursor-pointer items-center gap-1.5 border px-3 text-[10.5px] font-semibold uppercase tracking-[0.1em] transition-colors ${
                showExplain
                  ? "border-primary bg-primary text-primary-foreground"
                  : "border-primary text-primary hover:bg-secondary"
              }`}
            >
              <Lightbulb className="h-3.5 w-3.5" />
              Saber mais
            </button>
          )}
          {slugs.map((slug) => {
            const term = gIndex.find((e) => e.slug === slug);
            if (!term) return null;
            return (
              <button
                key={slug}
                type="button"
                onClick={() => onOpenTerm(slug)}
                className="font-mono-naut flex min-h-9 cursor-pointer items-center gap-1.5 border border-border px-2.5 text-[10px] font-medium uppercase tracking-[0.08em] text-foreground/80 transition-colors hover:border-primary hover:text-primary"
              >
                {term.term}
              </button>
            );
          })}
        </div>
        {showExplain && q.explain && (
          <p className="mt-2 border-l-2 border-primary bg-secondary/50 px-3 py-2 text-[13.5px] leading-relaxed text-foreground/90">
            {q.explain}
          </p>
        )}
      </div>
    </div>
  );
}

/** esquema na revisão: mostra a resolução (rumo correto + alternativas) */
function RieamScenarioReview({ scenario }: { scenario: NonNullable<ExamQuestion["scenario"]> }) {
  const full = RIEAM_SCENARIOS.find((s) => s.id === scenario.id) ?? scenario;
  return (
    <RieamScene
      scenario={{ ...full, you: undefined }}
      answered={true}
      picked={null}
    />
  );
}
