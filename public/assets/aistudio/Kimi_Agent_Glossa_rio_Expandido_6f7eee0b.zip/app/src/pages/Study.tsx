import { useCallback, useEffect, useMemo, useState } from "react";
import { Link } from "react-router";
import { AppHeader } from "@/components/AppHeader";
import { Skeleton } from "@/components/ui/skeleton";
import { TermIllustration } from "@/illustrations";
import { categoryColor, categorySoft, isForeign, type Term } from "@/lib/glossary";
import { trpc } from "@/providers/trpc";
import { ArrowLeft, ArrowRight, BookOpen, Check, RotateCcw, Shuffle } from "lucide-react";

function shuffle<T>(arr: T[]): T[] {
  const a = [...arr];
  for (let i = a.length - 1; i > 0; i--) {
    const j = Math.floor(Math.random() * (i + 1));
    [a[i], a[j]] = [a[j], a[i]];
  }
  return a;
}

export default function Study() {
  const list = trpc.glossary.list.useQuery({});
  const all = useMemo(() => (list.data ?? []) as Term[], [list.data]);
  const categories = useMemo(() => [...new Set(all.map((t) => t.category))], [all]);

  const [category, setCategory] = useState<string | null>(null);
  const [deck, setDeck] = useState<Term[]>([]);
  const [index, setIndex] = useState(0);
  const [flipped, setFlipped] = useState(false);
  const [known, setKnown] = useState<Set<string>>(new Set());

  const rebuild = useCallback(
    (cat: string | null, doShuffle = true) => {
      const base = cat ? all.filter((t) => t.category === cat) : all;
      const d = doShuffle ? shuffle(base) : [...base];
      setDeck(d);
      setIndex(0);
      setFlipped(false);
    },
    [all],
  );

  // construir baralho quando os dados chegam ou muda a categoria
  useEffect(() => {
    if (all.length) rebuild(category);
  }, [all, category, rebuild]);

  const current = deck[index] ?? null;
  const isKnown = current ? known.has(current.slug) : false;

  const go = useCallback(
    (dir: 1 | -1) => {
      if (!deck.length) return;
      setFlipped(false);
      setIndex((i) => (i + dir + deck.length) % deck.length);
    },
    [deck.length],
  );

  const mark = useCallback(
    (knew: boolean) => {
      if (!current) return;
      setKnown((prev) => {
        const n = new Set(prev);
        if (knew) n.add(current.slug);
        else n.delete(current.slug);
        return n;
      });
      go(1);
    },
    [current, go],
  );

  useEffect(() => {
    const onKey = (e: KeyboardEvent) => {
      if (e.key === " " || e.key === "Enter") {
        e.preventDefault();
        setFlipped((f) => !f);
      } else if (e.key === "ArrowRight") go(1);
      else if (e.key === "ArrowLeft") go(-1);
    };
    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
  }, [go]);

  return (
    <div className="flex min-h-dvh flex-col">
      <AppHeader />

      <main className="mx-auto flex w-full max-w-3xl flex-1 flex-col px-4 py-6 sm:px-6">
        <div className="flex flex-wrap items-center justify-between gap-3">
          <div>
            <h1 className="text-2xl font-semibold tracking-tight sm:text-3xl">Fichas de estudo</h1>
            <p className="font-mono-naut mt-1 text-[11px] uppercase tracking-[0.16em] text-muted-foreground">
              flashcards · espaço para virar · setas para navegar
            </p>
          </div>
          <div className="font-mono-naut border border-border bg-card px-3 py-2 text-[11px] uppercase tracking-[0.12em]">
            <span className="text-primary">{known.size}</span>
            <span className="text-muted-foreground"> / {deck.length} sabidos</span>
          </div>
        </div>

        {/* filtro de categoria */}
        <div className="mt-5 flex flex-wrap gap-2">
          <Chip active={category === null} onClick={() => setCategory(null)} label="Todas" />
          {categories.map((c) => (
            <Chip
              key={c}
              active={category === c}
              onClick={() => setCategory(category === c ? null : c)}
              label={c}
              color={categoryColor(c)}
              soft={categorySoft(c)}
            />
          ))}
        </div>

        {list.isLoading ? (
          <Skeleton className="mt-6 aspect-[4/3] w-full rounded-none sm:aspect-[16/10]" />
        ) : !current ? (
          <div className="mt-6 flex flex-col items-center gap-3 border border-dashed border-border bg-card px-6 py-16 text-center">
            <BookOpen className="h-8 w-8 text-muted-foreground" strokeWidth={1.5} />
            <p className="text-lg font-semibold">Sem cartas neste baralho</p>
            <Link
              to="/"
              className="font-mono-naut min-h-11 text-[11px] font-semibold uppercase tracking-[0.12em] text-primary underline underline-offset-4"
            >
              Voltar ao glossário
            </Link>
          </div>
        ) : (
          <>
            {/* carta */}
            <div className="persp mt-6">
              <button
                type="button"
                aria-label={flipped ? "Ver termo" : "Ver definição"}
                onClick={() => setFlipped((f) => !f)}
                className={`flip-inner relative block aspect-[4/3] w-full cursor-pointer text-left focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring sm:aspect-[16/10] ${flipped ? "flipped" : ""}`}
              >
                {/* frente */}
                <div className="flip-face absolute inset-0 flex flex-col border border-primary bg-card shadow-[6px_6px_0_0_#0b3a55]">
                  <div className="min-h-0 flex-1 border-b border-border">
                    <TermIllustration name={current.illustration} />
                  </div>
                  <div className="flex items-center justify-between gap-3 p-4 sm:p-5">
                    <h2 className="text-xl font-semibold leading-tight tracking-tight sm:text-2xl">
                      <span className={isForeign(current.slug) ? "italic" : ""}>{current.term}</span>
                    </h2>
                    <span
                      className="font-mono-naut shrink-0 px-1.5 py-0.5 text-[10px] font-semibold uppercase tracking-[0.1em]"
                      style={{
                        background: categorySoft(current.category),
                        color: categoryColor(current.category),
                      }}
                    >
                      {current.subcategory}
                    </span>
                  </div>
                </div>
                {/* verso */}
                <div className="flip-face flip-back absolute inset-0 flex flex-col border border-primary bg-primary text-primary-foreground shadow-[6px_6px_0_0_rgba(11,58,85,0.35)]">
                  <div className="flex-1 overflow-y-auto p-5 sm:p-7">
                    <p className="font-mono-naut text-[10px] uppercase tracking-[0.18em] opacity-70">
                      {current.category} · {current.subcategory}
                    </p>
                    <h2 className="mt-2 text-xl font-semibold tracking-tight sm:text-2xl">
                      <span className={isForeign(current.slug) ? "italic" : ""}>{current.term}</span>
                    </h2>
                    <p className="mt-4 text-[15.5px] leading-[1.7] sm:text-[17px]">
                      {current.definition}
                    </p>
                    <p className="font-mono-naut mt-4 text-[10px] uppercase tracking-[0.16em] opacity-70">
                      {current.section}
                      {current.subsection ? ` — ${current.subsection}` : ""}
                    </p>
                  </div>
                </div>
              </button>
            </div>

            {/* controlos */}
            <div className="mt-5 flex items-center justify-between gap-2">
              <CtrlButton onClick={() => go(-1)} label="Anterior" icon={<ArrowLeft className="h-4 w-4" />} />
              <div className="flex items-center gap-2">
                <button
                  type="button"
                  onClick={() => mark(false)}
                  title="Marcar para rever"
                  className="flex min-h-11 cursor-pointer items-center gap-2 border border-destructive px-3 text-destructive transition-colors hover:bg-destructive hover:text-destructive-foreground focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring sm:px-4"
                >
                  <RotateCcw className="h-4 w-4" />
                  <span className="font-mono-naut hidden text-[11px] font-semibold uppercase tracking-[0.12em] sm:inline">
                    Rever
                  </span>
                </button>
                <button
                  type="button"
                  onClick={() => mark(true)}
                  title="Marcar como sabido"
                  className={`flex min-h-11 cursor-pointer items-center gap-2 border px-3 transition-colors focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring sm:px-4 ${
                    isKnown
                      ? "border-[#1e7d4f] bg-[#1e7d4f] text-white"
                      : "border-[#1e7d4f] text-[#1e7d4f] hover:bg-[#1e7d4f] hover:text-white"
                  }`}
                >
                  <Check className="h-4 w-4" />
                  <span className="font-mono-naut hidden text-[11px] font-semibold uppercase tracking-[0.12em] sm:inline">
                    Sei
                  </span>
                </button>
                <button
                  type="button"
                  onClick={() => rebuild(category)}
                  title="Baralhar"
                  className="flex min-h-11 cursor-pointer items-center gap-2 border border-border px-3 text-foreground transition-colors hover:bg-secondary focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring sm:px-4"
                >
                  <Shuffle className="h-4 w-4" />
                  <span className="font-mono-naut hidden text-[11px] font-semibold uppercase tracking-[0.12em] sm:inline">
                    Baralhar
                  </span>
                </button>
              </div>
              <CtrlButton onClick={() => go(1)} label="Seguinte" icon={<ArrowRight className="h-4 w-4" />} right />
            </div>

            {/* progresso */}
            <div className="mt-4">
              <div className="font-mono-naut mb-1.5 flex justify-between text-[10px] uppercase tracking-[0.14em] text-muted-foreground">
                <span>
                  carta {index + 1} de {deck.length}
                </span>
                <span>{Math.round(((index + 1) / deck.length) * 100)}%</span>
              </div>
              <div className="h-1.5 w-full bg-secondary">
                <div
                  className="h-full bg-primary transition-all duration-300"
                  style={{ width: `${((index + 1) / deck.length) * 100}%` }}
                />
              </div>
            </div>
          </>
        )}
      </main>
    </div>
  );
}

function Chip({
  active,
  onClick,
  label,
  color,
  soft,
}: {
  active: boolean;
  onClick: () => void;
  label: string;
  color?: string;
  soft?: string;
}) {
  return (
    <button
      type="button"
      onClick={onClick}
      className="font-mono-naut min-h-11 cursor-pointer border px-3 text-[11px] font-medium uppercase tracking-[0.1em] transition-colors focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring"
      style={
        active
          ? { background: color ?? "#0b3a55", color: "#fbf9f0", borderColor: color ?? "#0b3a55" }
          : { background: soft ?? "#e8e2d2", color: color ?? "#0b3a55", borderColor: "transparent" }
      }
    >
      {label}
    </button>
  );
}

function CtrlButton({
  onClick,
  label,
  icon,
  right,
}: {
  onClick: () => void;
  label: string;
  icon: React.ReactNode;
  right?: boolean;
}) {
  return (
    <button
      type="button"
      onClick={onClick}
      className="font-mono-naut flex min-h-11 cursor-pointer items-center gap-2 border border-primary px-3 text-[11px] font-semibold uppercase tracking-[0.12em] text-primary transition-colors hover:bg-primary hover:text-primary-foreground focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring sm:px-4"
    >
      {!right && icon}
      <span className="hidden sm:inline">{label}</span>
      {right && icon}
    </button>
  );
}
