import { useCallback, useEffect, useMemo, useState } from "react";
import { AppHeader } from "@/components/AppHeader";
import { DoubtBox } from "@/components/DoubtBox";
import { GlossaryText } from "@/components/GlossaryText";
import { RieamScene } from "@/components/RieamScene";
import { RieamLiveRound } from "@/components/RieamLive";
import { TermDetail } from "@/components/TermDetail";
import { type Term } from "@/lib/glossary";
import { trpc } from "@/providers/trpc";
import { RIEAM_SCENARIOS, TOPICS, type RieamScenario, type TopicId, type Vessel } from "@/data/rieam-scenarios";
import { ArrowRight, BookOpen, Check, ClipboardList, Radar, RotateCcw, ShipWheel, X } from "lucide-react";

const ROUND_SIZE = 10;

type GameMode = "menu" | "teste" | "interativo";

const KIND_LABEL: Record<Vessel["kind"], string> = {
  motor: "motor",
  vela: "vela",
  "vela-motor": "veleiro a motor",
  pesca: "pesca",
  "sem-governo": "sem governo",
};

function shuffle<T>(arr: T[]): T[] {
  const a = [...arr];
  for (let i = a.length - 1; i > 0; i--) {
    const j = Math.floor(Math.random() * (i + 1));
    [a[i], a[j]] = [a[j], a[i]];
  }
  return a;
}

/* ---------------- página do jogo ---------------- */

export default function RieamGame() {
  const list = trpc.glossary.list.useQuery({});
  const indexQuery = trpc.glossary.index.useQuery();
  const all = useMemo(() => (list.data ?? []) as Term[], [list.data]);
  const index = useMemo(() => indexQuery.data ?? [], [indexQuery.data]);
  const termBySlug = useMemo(() => new Map(index.map((e) => [e.slug, e.term])), [index]);

  const [topic, setTopic] = useState<TopicId | null>(null);
  const [mode, setMode] = useState<GameMode>("menu");
  const [round, setRound] = useState<RieamScenario[]>([]);
  const [current, setCurrent] = useState(0);
  const [picked, setPicked] = useState<number | null>(null);
  const [score, setScore] = useState(0);
  const [failed, setFailed] = useState<string[]>([]);
  const [finished, setFinished] = useState(false);
  const [openSlug, setOpenSlug] = useState<string | null>(null);
  const [best, setBest] = useState<number | null>(null);

  const bestKey = `rieam-best:${topic ?? "todas"}`;

  const rebuild = useCallback((t: TopicId | null) => {
    const pool = t ? RIEAM_SCENARIOS.filter((s) => s.topic === t) : RIEAM_SCENARIOS;
    setRound(shuffle(pool).slice(0, Math.min(ROUND_SIZE, pool.length)));
    setCurrent(0);
    setPicked(null);
    setScore(0);
    setFailed([]);
    setFinished(false);
  }, []);

  useEffect(() => {
    rebuild(topic);
    const b = Number(localStorage.getItem(`rieam-best:${topic ?? "todas"}`));
    setBest(Number.isFinite(b) && b > 0 ? b : null);
  }, [topic, rebuild]);

  const sc = round[current] ?? null;
  const answered = picked !== null;
  const wasCorrect = sc !== null && picked === sc.correct;
  const detailTerm = openSlug ? (all.find((t) => t.slug === openSlug) ?? null) : null;

  const pick = (i: number) => {
    if (answered || !sc) return;
    setPicked(i);
    if (i === sc.correct) setScore((s) => s + 1);
    else setFailed((f) => [...f, sc.id]);
  };

  const next = () => {
    if (current + 1 >= round.length) {
      setFinished(true);
      const finalScore = score;
      const prev = Number(localStorage.getItem(bestKey)) || 0;
      if (finalScore > prev) {
        localStorage.setItem(bestKey, String(finalScore));
        setBest(finalScore);
      }
    } else {
      setCurrent((c) => c + 1);
      setPicked(null);
    }
  };

  const failedScenarios = failed.map((id) => RIEAM_SCENARIOS.find((s) => s.id === id)!).filter(Boolean);

  return (
    <div className="flex min-h-dvh flex-col">
      <AppHeader />

      <main className="mx-auto flex w-full max-w-4xl flex-1 flex-col px-4 py-6 sm:px-6">
        <div className="flex flex-wrap items-center justify-between gap-3">
          <div>
            <h1 className="text-2xl font-semibold tracking-tight sm:text-3xl">Simulador R.I.E.A.M.</h1>
            <p className="font-mono-naut mt-1 text-[11px] uppercase tracking-[0.16em] text-muted-foreground">
              situações reais · regras do dia · dois modos de treino
            </p>
          </div>
          {mode === "teste" && !finished && round.length > 0 && (
            <div className="font-mono-naut border border-border bg-card px-3 py-2 text-[11px] uppercase tracking-[0.12em]">
              <span className="text-primary">{score}</span>
              <span className="text-muted-foreground"> / {round.length} certas</span>
            </div>
          )}
        </div>

        {/* escolha de modo */}
        {mode === "menu" && (
          <div className="mt-6 grid gap-4 sm:grid-cols-2">
            <ModeCard
              icon={<ClipboardList className="h-7 w-7" strokeWidth={1.6} />}
              title="Esquema de teste"
              desc="Esquemas estáticos, como no exame: analisa a situação, responde sem pressas e vê a resolução desenhada na cena."
              meta="10 cenários por ronda · filtros por situação"
              onClick={() => setMode("teste")}
            />
            <ModeCard
              icon={<Radar className="h-7 w-7" strokeWidth={1.6} />}
              title="Interativo"
              desc="Os barcos estão em movimento, vistos de cima: tens 30 segundos até ao abalroamento para decidir — e depois vês a manobra, ou o estrago, a acontecer."
              meta={`${5} situações por ronda · contra o relógio`}
              onClick={() => setMode("interativo")}
            />
          </div>
        )}

        {/* modo interativo */}
        {mode === "interativo" && (
          <RieamLiveRound
            index={index}
            all={all}
            termBySlug={termBySlug}
            onOpenSlug={setOpenSlug}
            onExit={() => setMode("menu")}
          />
        )}

        {/* filtro de situação (modo esquema de teste) */}
        {mode === "teste" && (
          <div className="mt-5 flex flex-wrap items-center gap-2">
            <Chip active={topic === null} onClick={() => setTopic(null)} label="Todas" />
            {TOPICS.map((t) => (
              <Chip
                key={t.id}
                active={topic === t.id}
                onClick={() => setTopic(topic === t.id ? null : t.id)}
                label={t.label}
                color="#0b3a55"
                soft="#e8e2d2"
              />
            ))}
            <button
              type="button"
              onClick={() => setMode("menu")}
              className="font-mono-naut ml-auto min-h-11 cursor-pointer border border-border bg-card px-3 text-[10px] font-medium uppercase tracking-[0.1em] text-muted-foreground transition-colors hover:border-primary hover:text-primary focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring"
            >
              Mudar de modo
            </button>
          </div>
        )}

        {mode !== "teste" || !sc ? null : finished ? (
          /* resultado final */
          <div className="mt-6 flex flex-col items-center gap-4 border border-primary bg-card px-6 py-12 text-center shadow-[6px_6px_0_0_#0b3a55]">
            <ShipWheel className="h-9 w-9 text-primary" strokeWidth={1.5} />
            <p className="text-2xl font-semibold tracking-tight sm:text-3xl">
              {score} em {round.length}
            </p>
            <p className="font-mono-naut text-[12px] uppercase tracking-[0.2em] text-[#b3402f]">
              {Math.round((score / round.length) * 100)}% certas
            </p>
            <p className="max-w-md text-[15px] text-muted-foreground">
              No exame, as perguntas de R.I.E.A.M. exigem pelo menos 75% de respostas certas.
            </p>
            {best !== null && (
              <p className="font-mono-naut text-[11px] uppercase tracking-[0.14em] text-muted-foreground">
                melhor resultado neste filtro: {best} / {round.length}
              </p>
            )}
            <button
              type="button"
              onClick={() => rebuild(topic)}
              className="font-mono-naut flex min-h-11 cursor-pointer items-center gap-2 border border-primary bg-primary px-4 text-[11px] font-semibold uppercase tracking-[0.12em] text-primary-foreground transition-colors hover:bg-[#0d4767] focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring"
            >
              <RotateCcw className="h-4 w-4" />
              Nova ronda
            </button>

            {failedScenarios.length > 0 && (
              <div className="mt-4 w-full max-w-2xl border-t border-border pt-5 text-left">
                <p className="font-mono-naut mb-3 text-[11px] uppercase tracking-[0.16em] text-muted-foreground">
                  para rever · {failedScenarios.length}
                </p>
                <div className="flex flex-col gap-3">
                  {failedScenarios.map((s) => (
                    <div key={s.id} className="border border-border bg-background p-4">
                      <div className="flex items-center justify-between gap-3">
                        <p className="text-[14px] font-semibold leading-snug">{s.prompt}</p>
                        <span className="font-mono-naut shrink-0 border border-[#b3402f] px-2 py-1 text-[10px] uppercase tracking-[0.1em] text-[#b3402f]">
                          {s.rule}
                        </span>
                      </div>
                      <p className="mt-2 text-[13px] leading-relaxed text-muted-foreground">{s.explanation}</p>
                    </div>
                  ))}
                </div>
              </div>
            )}
          </div>
        ) : (
          <>
            {/* cena */}
            <div className="mt-6 border border-primary bg-card shadow-[6px_6px_0_0_#0b3a55]">
              {(() => {
                const me = sc.vessels.find((v) => v.id === sc.you);
                return me ? (
                  <div className="flex items-center gap-2 border-b border-border bg-primary px-4 py-2.5">
                    <span className="font-mono-naut flex h-6 w-6 items-center justify-center border border-white/60 text-[11px] font-bold text-primary-foreground">
                      {me.id}
                    </span>
                    <p className="font-mono-naut text-[11px] font-semibold uppercase tracking-[0.14em] text-primary-foreground">
                      Tu és a embarcação {me.id} · {me.tag ?? KIND_LABEL[me.kind]}
                    </p>
                  </div>
                ) : null;
              })()}
              <div className="aspect-[16/9] w-full border-b border-border">
                <RieamScene scenario={sc} answered={answered} picked={picked} onVesselPick={pick} />
              </div>

              <div className="p-5 sm:p-6">
                <div className="flex items-center justify-between gap-3">
                  <p className="font-mono-naut text-[10px] uppercase tracking-[0.18em] text-muted-foreground">
                    {sc.ask === "who" ? "clica na embarcação" : "escolhe a manobra"}
                  </p>
                  <span className="font-mono-naut border border-primary px-2 py-0.5 text-[10px] uppercase tracking-[0.12em] text-primary">
                    {TOPICS.find((t) => t.id === sc.topic)?.label}
                  </span>
                </div>
                <h2 className="mt-2 text-lg font-semibold leading-snug tracking-tight sm:text-xl">
                  <GlossaryText text={sc.prompt} index={index} onOpen={setOpenSlug} />
                </h2>
              </div>

              {/* opções (modo «do») */}
              {sc.ask === "do" && sc.options && (
                <div className="flex flex-col gap-2 border-t border-border p-4 sm:p-5">
                  {sc.options.map((opt, i) => {
                    const isCorrect = i === sc.correct;
                    const isPicked = i === picked;
                    let cls = "border-border bg-background hover:border-primary hover:bg-secondary";
                    if (answered && isCorrect) cls = "border-[#1e7d4f] bg-[#dcebe1]";
                    else if (answered && isPicked) cls = "border-[#b3402f] bg-[#f3ded9]";
                    else if (answered) cls = "border-border bg-background opacity-60";
                    return (
                      <button
                        key={i}
                        type="button"
                        disabled={answered}
                        onClick={() => pick(i)}
                        className={`flex min-h-11 w-full cursor-pointer items-start gap-3 border p-3 text-left transition-colors focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring disabled:cursor-default ${cls}`}
                      >
                        <span className="font-mono-naut mt-0.5 flex h-5 w-5 shrink-0 items-center justify-center border border-current text-[10px] font-semibold">
                          {answered && isCorrect ? (
                            <Check className="h-3.5 w-3.5 text-[#1e7d4f]" />
                          ) : answered && isPicked ? (
                            <X className="h-3.5 w-3.5 text-[#b3402f]" />
                          ) : (
                            String.fromCharCode(65 + i)
                          )}
                        </span>
                        <span className="text-[14px] leading-snug font-medium">
                          <GlossaryText text={opt} index={index} onOpen={setOpenSlug} />
                        </span>
                      </button>
                    );
                  })}
                </div>
              )}

              {/* feedback + explicação */}
              {answered && (
                <div className="border-t border-border p-4 sm:p-5">
                  <p className={`font-mono-naut text-[11px] font-semibold uppercase tracking-[0.16em] ${wasCorrect ? "text-[#1e7d4f]" : "text-[#b3402f]"}`}>
                    {wasCorrect ? "certo!" : sc.ask === "who" ? `não — quem se afasta é ${sc.vessels[sc.correct].id}` : "não era essa manobra"}
                  </p>
                  <div className="mt-2 flex items-start gap-3">
                    <span className="font-mono-naut mt-0.5 shrink-0 border border-[#b3402f] px-2 py-1 text-[10px] uppercase tracking-[0.1em] text-[#b3402f]">
                      {sc.rule}
                    </span>
                    <p className="text-[14px] leading-relaxed text-foreground">
                      <GlossaryText text={sc.explanation} index={index} onOpen={setOpenSlug} />
                    </p>
                  </div>
                  {sc.slugs.length > 0 && (
                    <div className="mt-3 flex flex-wrap items-center gap-2">
                      <span className="font-mono-naut text-[10px] uppercase tracking-[0.14em] text-muted-foreground">
                        saber mais:
                      </span>
                      {sc.slugs.map((slug) => (
                        <button
                          key={slug}
                          type="button"
                          onClick={() => setOpenSlug(slug)}
                          className="font-mono-naut flex min-h-9 cursor-pointer items-center gap-1.5 border border-[#b3402f] px-2.5 text-[10px] font-medium uppercase tracking-[0.1em] text-[#b3402f] transition-colors hover:bg-[#b3402f] hover:text-white focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring"
                        >
                          <BookOpen className="h-3 w-3" />
                          {termBySlug.get(slug) ?? slug}
                        </button>
                      ))}
                    </div>
                  )}
                </div>
              )}
            </div>

            {/* dúvidas + discordar */}
            {answered && (
              <DoubtBox scenario={sc} terms={all} onOpenSlug={setOpenSlug} />
            )}

            {/* ações após resposta */}
            {answered && (
              <div className="mt-4 flex justify-end">
                <button
                  type="button"
                  onClick={next}
                  className="font-mono-naut flex min-h-11 cursor-pointer items-center gap-2 border border-primary bg-primary px-4 text-[11px] font-semibold uppercase tracking-[0.12em] text-primary-foreground transition-colors hover:bg-[#0d4767] focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring"
                >
                  {current + 1 >= round.length ? "Ver resultado" : "Seguinte"}
                  <ArrowRight className="h-4 w-4" />
                </button>
              </div>
            )}

            {/* progresso */}
            <div className="mt-5">
              <div className="font-mono-naut mb-1.5 flex justify-between text-[10px] uppercase tracking-[0.14em] text-muted-foreground">
                <span>cenário {current + 1} de {round.length}</span>
                <span>{Math.round(((current + (answered ? 1 : 0)) / round.length) * 100)}%</span>
              </div>
              <div className="h-1.5 w-full bg-secondary">
                <div
                  className="h-full bg-primary transition-all duration-300"
                  style={{ width: `${((current + (answered ? 1 : 0)) / round.length) * 100}%` }}
                />
              </div>
            </div>
          </>
        )}
      </main>

      <TermDetail
        term={detailTerm}
        open={detailTerm !== null}
        onOpenChange={(o) => !o && setOpenSlug(null)}
        onPrev={() => {}}
        onNext={() => {}}
        position={0}
        total={1}
        index={index}
        onNavigate={setOpenSlug}
      />
    </div>
  );
}

function ModeCard({ icon, title, desc, meta, onClick }: {
  icon: React.ReactNode;
  title: string;
  desc: string;
  meta: string;
  onClick: () => void;
}) {
  return (
    <button
      type="button"
      onClick={onClick}
      className="group flex cursor-pointer flex-col items-start gap-3 border border-primary bg-card p-6 text-left shadow-[6px_6px_0_0_#0b3a55] transition-transform hover:-translate-y-0.5 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring"
    >
      <span className="flex h-12 w-12 items-center justify-center border border-primary bg-primary text-primary-foreground">
        {icon}
      </span>
      <span className="text-xl font-semibold tracking-tight">{title}</span>
      <span className="text-[14px] leading-relaxed text-muted-foreground">{desc}</span>
      <span className="font-mono-naut mt-auto border border-border px-2 py-1 text-[10px] uppercase tracking-[0.12em] text-muted-foreground group-hover:border-primary group-hover:text-primary">
        {meta}
      </span>
    </button>
  );
}

function Chip({ active, onClick, label, color, soft }: {
  active: boolean;
  onClick: () => void;
  label: string;
  color?: string;
  soft?: string;
}) {
  return (
    <button
      type="button"
      onClick={onClick}
      className="font-mono-naut min-h-11 cursor-pointer border px-3 text-[11px] font-medium uppercase tracking-[0.1em] transition-colors focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring"
      style={
        active
          ? { background: color ?? "#0b3a55", color: "#fbf9f0", borderColor: color ?? "#0b3a55" }
          : { background: soft ?? "#e8e2d2", color: color ?? "#0b3a55", borderColor: "transparent" }
      }
    >
      {label}
    </button>
  );
}
