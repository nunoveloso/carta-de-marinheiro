import { useEffect, useMemo, useRef, useState } from "react";
import { useLocation } from "react-router";
import { AppHeader } from "@/components/AppHeader";
import { TermDetail } from "@/components/TermDetail";
import { Skeleton } from "@/components/ui/skeleton";
import { TermIllustration } from "@/illustrations";
import { linkify, matchSnippet, normalizeText, SECTION_GLOSSARY_MAP, type Term, type TermIndexEntry } from "@/lib/glossary";
import { MANUAL_SECTIONS } from "@/data/manual-content";
import { trpc } from "@/providers/trpc";
import { BookOpenText, List, Search, X } from "lucide-react";

/** Sub-títulos curtos dentro do texto corrido */
function isSubheading(p: string): boolean {
  return p.length <= 70 && !p.endsWith(".") && !p.endsWith(";") && !p.endsWith(",");
}

export default function Manual() {
  const list = trpc.glossary.list.useQuery({});
  const indexQuery = trpc.glossary.index.useQuery();
  const index = useMemo(() => indexQuery.data ?? [], [indexQuery.data]);
  const all = useMemo(() => (list.data ?? []) as Term[], [list.data]);

  const [openSlug, setOpenSlug] = useState<string | null>(null);
  const [active, setActive] = useState<string>(MANUAL_SECTIONS[0]?.id ?? "");
  const [tocOpen, setTocOpen] = useState(false);
  const [query, setQuery] = useState("");
  const [flash, setFlash] = useState<string | null>(null);
  const articleRef = useRef<HTMLDivElement>(null);

  const linkedTerm = trpc.glossary.bySlug.useQuery(
    { slug: openSlug! },
    { enabled: openSlug !== null },
  );
  const detailTerm = (linkedTerm.data as Term | null) ?? null;

  // ilustrações do glossário por capítulo
  const sectionTerms = useMemo(() => {
    const map: Record<string, Term[]> = {};
    for (const [sid, names] of Object.entries(SECTION_GLOSSARY_MAP)) {
      map[sid] = all.filter((t) => names.includes(t.section));
    }
    return map;
  }, [all]);

  // scroll-spy
  useEffect(() => {
    const root = articleRef.current;
    if (!root) return;
    const headings = Array.from(root.querySelectorAll<HTMLElement>("[data-section]"));
    const obs = new IntersectionObserver(
      (entries) => {
        for (const e of entries) {
          if (e.isIntersecting) setActive((e.target as HTMLElement).dataset.section ?? "");
        }
      },
      { rootMargin: "-80px 0px -70% 0px" },
    );
    headings.forEach((h) => obs.observe(h));
    return () => obs.disconnect();
  }, []);

  const goTo = (id: string) => {
    document.getElementById(`manual-${id}`)?.scrollIntoView({ behavior: "smooth", block: "start" });
    setTocOpen(false);
  };

  // âncora no URL (ex.: /manual#manual-rieam, a partir das cartas do glossário)
  const location = useLocation();
  useEffect(() => {
    if (!location.hash || list.isLoading || indexQuery.isLoading) return;
    const id = location.hash.slice(1);
    const t = window.setTimeout(() => {
      document.getElementById(id)?.scrollIntoView({ behavior: "smooth", block: "start" });
    }, 150);
    return () => window.clearTimeout(t);
  }, [location.hash, list.isLoading, indexQuery.isLoading]);

  // ---- pesquisa dentro do manual ----
  interface ManualHit {
    secId: string;
    secNum: number;
    secTitle: string;
    paraIdx: number; // -1 = correspondência no título da secção
    snippet: string;
    matchStart: number;
    matchEnd: number;
  }

  const hits = useMemo<ManualHit[]>(() => {
    const q = query.trim();
    if (q.length < 2) return [];
    const out: ManualHit[] = [];
    MANUAL_SECTIONS.forEach((sec, si) => {
      if (normalizeText(sec.title).includes(normalizeText(q))) {
        out.push({
          secId: sec.id, secNum: si + 1, secTitle: sec.title, paraIdx: -1,
          snippet: sec.title, matchStart: 0, matchEnd: sec.title.length,
        });
      }
      sec.paragraphs.forEach((p, pi) => {
        const m = matchSnippet(p, q);
        if (m) {
          out.push({
            secId: sec.id, secNum: si + 1, secTitle: sec.title, paraIdx: pi,
            snippet: m.text, matchStart: m.matchStart, matchEnd: m.matchEnd,
          });
        }
      });
      sec.tables?.forEach((tb) => {
        const m = matchSnippet(`${tb.title} ${tb.columns.join(" ")} ${tb.rows.map((r) => r.join(" ")).join(" ")}`, q);
        if (m && normalizeText(tb.title).includes(normalizeText(q))) {
          out.push({
            secId: sec.id, secNum: si + 1, secTitle: sec.title, paraIdx: -1,
            snippet: tb.title, matchStart: 0, matchEnd: tb.title.length,
          });
        }
      });
    });
    return out.slice(0, 40);
  }, [query]);

  const jumpTo = (h: ManualHit) => {
    const elId = h.paraIdx >= 0 ? `manual-${h.secId}-p-${h.paraIdx}` : `manual-${h.secId}`;
    document.getElementById(elId)?.scrollIntoView({ behavior: "smooth", block: "center" });
    if (h.paraIdx >= 0) {
      const key = `${h.secId}:${h.paraIdx}`;
      setFlash(key);
      window.setTimeout(() => setFlash((f) => (f === key ? null : f)), 2600);
    }
  };

  return (
    <div className="min-h-dvh">
      <AppHeader />

      {/* introdução */}
      <section className="border-b border-border">
        <div className="mx-auto max-w-7xl px-4 py-8 sm:px-6 sm:py-10">
          <p className="font-mono-naut text-[11px] uppercase tracking-[0.2em] text-muted-foreground">
            Manual do Marinheiro 2021 · texto integral
          </p>
          <h1 className="mt-2 max-w-2xl text-3xl font-semibold leading-tight tracking-tight sm:text-4xl">
            O manual completo, capítulo a capítulo.
          </h1>
          <p className="mt-3 max-w-2xl text-[15px] leading-relaxed text-muted-foreground">
            Os termos que fazem parte do glossário aparecem a{" "}
            <span className="font-medium text-[#b3402f] underline decoration-[#b3402f]/50 underline-offset-2">
              vermelho
            </span>{" "}
            — clica neles para abrir a carta com a definição e o esquema. Algumas páginas do
            manual original são digitalizações; a transcrição pode ter pequenas imprecisões.
          </p>

          {/* pesquisa dentro do manual */}
          <div className="relative mt-6 max-w-2xl">
            <Search className="pointer-events-none absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" />
            <input
              type="text"
              value={query}
              onChange={(e) => setQuery(e.target.value)}
              placeholder="Pesquisar no manual (ex.: homem ao mar, abalroamento, maré)…"
              className="font-mono-naut min-h-12 w-full border border-border bg-card pl-10 pr-10 text-[13px] uppercase tracking-[0.06em] placeholder:normal-case placeholder:tracking-normal placeholder:text-muted-foreground/70 focus:border-primary focus:outline-none focus:ring-2 focus:ring-ring"
            />
            {query && (
              <button
                type="button"
                onClick={() => setQuery("")}
                aria-label="Limpar pesquisa"
                className="absolute right-2 top-1/2 flex h-8 w-8 -translate-y-1/2 cursor-pointer items-center justify-center text-muted-foreground hover:text-foreground"
              >
                <X className="h-4 w-4" />
              </button>
            )}
          </div>

          {query.trim().length >= 2 && (
            <div className="mt-3 max-w-2xl border border-border bg-card">
              <p className="font-mono-naut border-b border-border px-3 py-2 text-[10px] uppercase tracking-[0.16em] text-muted-foreground">
                {hits.length === 0 ? "sem resultados" : `${hits.length}${hits.length >= 40 ? "+" : ""} resultado${hits.length === 1 ? "" : "s"} no manual`}
              </p>
              <ul className="max-h-80 overflow-y-auto">
                {hits.map((h, i) => (
                  <li key={i}>
                    <button
                      type="button"
                      onClick={() => jumpTo(h)}
                      className="flex w-full cursor-pointer flex-col gap-0.5 border-b border-border/60 px-3 py-2.5 text-left transition-colors last:border-b-0 hover:bg-secondary focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring"
                    >
                      <span className="font-mono-naut text-[10px] uppercase tracking-[0.14em] text-primary">
                        {String(h.secNum).padStart(2, "0")} · {h.secTitle}
                        {h.paraIdx === -1 && <span className="text-[#b3402f]"> · título</span>}
                      </span>
                      {h.paraIdx >= 0 && (
                        <span className="text-[13px] leading-snug text-foreground/85">
                          {h.snippet.slice(0, h.matchStart)}
                          <mark className="bg-[#e3b505]/40 font-medium text-foreground">
                            {h.snippet.slice(h.matchStart, h.matchEnd)}
                          </mark>
                          {h.snippet.slice(h.matchEnd)}
                        </span>
                      )}
                    </button>
                  </li>
                ))}
              </ul>
            </div>
          )}
        </div>
      </section>

      <div className="mx-auto flex max-w-7xl gap-8 px-4 py-6 sm:px-6" ref={articleRef}>
        {/* índice — barra lateral no desktop */}
        <aside className="hidden w-64 shrink-0 lg:block">
          <div className="sticky top-24 max-h-[calc(100dvh-8rem)] overflow-y-auto pr-2">
            <Toc active={active} onGo={goTo} />
          </div>
        </aside>

        <main className="min-w-0 max-w-3xl flex-1 pb-16">
          {/* índice móvel */}
          <button
            type="button"
            onClick={() => setTocOpen((v) => !v)}
            aria-expanded={tocOpen}
            className="font-mono-naut flex min-h-11 w-full cursor-pointer items-center justify-between border border-border bg-card px-4 text-[11px] font-semibold uppercase tracking-[0.12em] lg:hidden"
          >
            <span className="flex items-center gap-2">
              <List className="h-4 w-4" />
              Índice do manual
            </span>
            <span>{tocOpen ? "−" : "+"}</span>
          </button>
          {tocOpen && (
            <div className="mt-2 border border-border bg-card p-3 lg:hidden">
              <Toc active={active} onGo={goTo} />
            </div>
          )}

          {list.isLoading || indexQuery.isLoading ? (
            <div className="mt-8 space-y-4">
              {Array.from({ length: 4 }).map((_, i) => (
                <Skeleton key={i} className="h-32 w-full rounded-none" />
              ))}
            </div>
          ) : (
            MANUAL_SECTIONS.map((sec) => (
              <section
                key={sec.id}
                id={`manual-${sec.id}`}
                data-section={sec.id}
                className="scroll-mt-24 border-b border-border py-8 first:pt-6"
              >
                <h2 className="text-2xl font-semibold tracking-tight text-primary sm:text-[28px]">
                  {sec.title}
                </h2>

                {/* ilustrações dos termos do glossário deste capítulo */}
                {(sectionTerms[sec.id]?.length ?? 0) > 0 && (
                  <div className="mt-4 grid grid-cols-2 gap-3 sm:grid-cols-3">
                    {sectionTerms[sec.id].slice(0, 6).map((t) => (
                      <button
                        key={t.slug}
                        type="button"
                        onClick={() => setOpenSlug(t.slug)}
                        className="group cursor-pointer border border-border bg-card text-left transition-all hover:-translate-y-0.5 hover:border-primary hover:shadow-[3px_3px_0_0_#0b3a55] focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring"
                      >
                        <div className="aspect-[8/5] w-full border-b border-border">
                          <TermIllustration name={t.illustration} />
                        </div>
                        <p className="p-2 text-[12.5px] font-medium leading-tight group-hover:text-primary">
                          {t.term}
                        </p>
                      </button>
                    ))}
                  </div>
                )}

                <div className="mt-5 space-y-4">
                  {sec.paragraphs.map((p, i) =>
                    isSubheading(p) ? (
                      <h3
                        key={i}
                        className="font-mono-naut pt-3 text-[13px] font-semibold uppercase tracking-[0.12em] text-foreground"
                      >
                        {p}
                      </h3>
                    ) : (
                      <p
                        key={i}
                        id={`manual-${sec.id}-p-${i}`}
                        className={`scroll-mt-28 text-[15.5px] leading-[1.75] text-foreground/90 transition-colors duration-500 ${
                          flash === `${sec.id}:${i}` ? "bg-[#e3b505]/30" : ""
                        }`}
                      >
                        <LinkedText text={p} index={index} onOpen={setOpenSlug} />
                      </p>
                    ),
                  )}
                </div>

                {sec.tables && sec.tables.length > 0 && (
                  <div className="mt-6 space-y-8">
                    {sec.tables.map((tb, ti) => (
                      <figure key={ti} className="border border-border bg-card">
                        <figcaption className="border-b border-border bg-secondary/60 px-4 py-3">
                          <span className="font-mono-naut text-[11px] font-semibold uppercase tracking-[0.12em] text-primary">
                            {tb.title}
                          </span>
                        </figcaption>
                        <div className="overflow-x-auto">
                          <table className="w-full min-w-[560px] border-collapse text-[12.5px] leading-snug">
                            <thead>
                              <tr>
                                {tb.columns.map((c, ci) => (
                                  <th
                                    key={ci}
                                    className="border-b border-border bg-card px-3 py-2.5 text-left font-mono-naut text-[10px] font-semibold uppercase tracking-[0.1em] text-muted-foreground"
                                  >
                                    {c}
                                  </th>
                                ))}
                              </tr>
                            </thead>
                            <tbody>
                              {tb.rows.map((r, ri) => (
                                <tr key={ri} className="odd:bg-secondary/30">
                                  {r.map((cell, ci) => (
                                    <td
                                      key={ci}
                                      className={`border-b border-border/60 px-3 py-2 align-top ${
                                        ci === 0 ? "font-medium text-foreground" : "text-foreground/85"
                                      }`}
                                    >
                                      {cell}
                                    </td>
                                  ))}
                                </tr>
                              ))}
                            </tbody>
                          </table>
                        </div>
                        {tb.notes && tb.notes.length > 0 && (
                          <ul className="space-y-1 border-t border-border px-4 py-3">
                            {tb.notes.map((n, ni) => (
                              <li key={ni} className="text-[12px] leading-snug text-muted-foreground">
                                {n}
                              </li>
                            ))}
                          </ul>
                        )}
                      </figure>
                    ))}
                  </div>
                )}

                {sec.photos && sec.photos.length > 0 && (
                  <div className="mt-6 grid grid-cols-2 gap-3 sm:grid-cols-3">
                    {sec.photos.map((ph, phi) => (
                      <figure key={`${ph.url}-${phi}`} className="border border-border bg-card">
                        <img
                          src={ph.url}
                          alt={ph.alt}
                          loading="lazy"
                          className="h-36 w-full border-b border-border object-cover sm:h-44"
                        />
                        <figcaption className="p-2">
                          <span className="block text-[12.5px] font-medium leading-tight">
                            {ph.alt}
                          </span>
                          <a
                            href={ph.page}
                            target="_blank"
                            rel="noreferrer"
                            className="font-mono-naut mt-1 block text-[9.5px] uppercase tracking-[0.12em] text-muted-foreground underline decoration-1 underline-offset-2 transition-colors hover:text-primary"
                          >
                            Fonte: Wikimedia Commons
                          </a>
                        </figcaption>
                      </figure>
                    ))}
                  </div>
                )}
              </section>
            ))
          )}

          <div className="mt-8 flex items-center gap-3 border border-dashed border-border bg-card p-4 text-[13px] text-muted-foreground">
            <BookOpenText className="h-5 w-5 shrink-0" strokeWidth={1.6} />
            Fim do manual. Fonte: «Manual do Marinheiro 2021» (cm002) — consulta sempre a
            publicação oficial e os avisos aos navegantes do Instituto Hidrográfico.
          </div>
        </main>
      </div>

      <TermDetail
        term={detailTerm}
        open={detailTerm !== null}
        onOpenChange={(o) => !o && setOpenSlug(null)}
        onPrev={() => {}}
        onNext={() => {}}
        position={0}
        total={1}
        index={index}
        onNavigate={setOpenSlug}
      />
    </div>
  );
}

/** Texto com os termos do glossário ligados (a vermelho, clicáveis) */
function LinkedText({
  text,
  index,
  onOpen,
}: {
  text: string;
  index: TermIndexEntry[];
  onOpen: (slug: string) => void;
}) {
  const segments = useMemo(() => linkify(text, index, ""), [text, index]);
  return (
    <>
      {segments.map((seg, i) =>
        seg.slug ? (
          <button
            key={i}
            type="button"
            onClick={() => onOpen(seg.slug!)}
            className="cursor-pointer font-medium text-[#b3402f] underline decoration-[#b3402f]/45 underline-offset-2 transition-colors hover:text-[#8c2f22] focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring"
          >
            {seg.text}
          </button>
        ) : (
          <span key={i}>{seg.text}</span>
        ),
      )}
    </>
  );
}

function Toc({ active, onGo }: { active: string; onGo: (id: string) => void }) {
  return (
    <nav aria-label="Índice do manual">
      <p className="font-mono-naut mb-2 text-[10px] uppercase tracking-[0.18em] text-muted-foreground">
        Índice
      </p>
      <ul className="space-y-0.5">
        {MANUAL_SECTIONS.map((s, i) => (
          <li key={s.id}>
            <button
              type="button"
              onClick={() => onGo(s.id)}
              className={`flex min-h-9 w-full cursor-pointer items-baseline gap-2 px-2 text-left text-[13.5px] transition-colors focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring ${
                active === s.id ? "bg-primary text-primary-foreground" : "hover:bg-secondary"
              }`}
            >
              <span
                className={`font-mono-naut shrink-0 text-[10px] ${
                  active === s.id ? "text-primary-foreground/70" : "text-muted-foreground"
                }`}
              >
                {String(i + 1).padStart(2, "0")}
              </span>
              <span>{s.title}</span>
            </button>
          </li>
        ))}
      </ul>
    </nav>
  );
}
