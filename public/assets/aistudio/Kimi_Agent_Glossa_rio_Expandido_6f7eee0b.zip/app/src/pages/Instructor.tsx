import { useEffect, useMemo, useRef, useState } from "react";
import { Link } from "react-router";
import { AppHeader } from "@/components/AppHeader";
import { TermDetail } from "@/components/TermDetail";
import { answerQuestion, SUGGESTIONS, type InstructorAnswer } from "@/lib/instructor";
import type { Term } from "@/lib/glossary";
import { trpc } from "@/providers/trpc";
import { ArrowRight, BookOpenText, Sailboat, Send, User } from "lucide-react";

interface ChatMessage {
  id: number;
  role: "bot" | "user";
  text: string;
  answer?: InstructorAnswer;
}

export default function Instructor() {
  const list = trpc.glossary.list.useQuery({});
  const indexQuery = trpc.glossary.index.useQuery();
  const terms = useMemo(() => (list.data ?? []) as Term[], [list.data]);
  const index = useMemo(() => indexQuery.data ?? [], [indexQuery.data]);

  const [messages, setMessages] = useState<ChatMessage[]>([
    {
      id: 0,
      role: "bot",
      text: "Olá! Sou o teu instrutor virtual. Tudo o que te explicar aqui vem do glossário e do Manual do Marinheiro. Que dúvida tens?",
    },
  ]);
  const [input, setInput] = useState("");
  const [openSlug, setOpenSlug] = useState<string | null>(null);
  const nextId = useRef(1);
  const scrollRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    scrollRef.current?.scrollTo({ top: scrollRef.current.scrollHeight, behavior: "smooth" });
  }, [messages]);

  const ask = (raw: string) => {
    const q = raw.trim();
    if (!q || !terms.length) return;
    const answer = answerQuestion(q, terms);
    setMessages((m) => [
      ...m,
      { id: nextId.current++, role: "user", text: q },
      { id: nextId.current++, role: "bot", text: answer.text, answer },
    ]);
    setInput("");
  };

  const termBySlug = useMemo(() => {
    const m = new Map<string, Term>();
    for (const t of terms) m.set(t.slug, t);
    return m;
  }, [terms]);

  const detailTerm = openSlug ? (termBySlug.get(openSlug) ?? null) : null;
  const openIndex = detailTerm ? terms.findIndex((t) => t.slug === detailTerm.slug) : -1;

  return (
    <div className="flex min-h-svh flex-col bg-background">
      <AppHeader />

      <main className="mx-auto flex w-full max-w-3xl flex-1 flex-col px-4 sm:px-6">
        <div className="border-b border-border py-5">
          <p className="font-mono-naut text-[11px] font-semibold uppercase tracking-[0.14em] text-muted-foreground">
            Instrutor virtual
          </p>
          <h1 className="mt-1 text-2xl font-bold tracking-tight">Tira as tuas dúvidas</h1>
        </div>

        <div ref={scrollRef} className="flex-1 space-y-5 overflow-y-auto py-6">
          {messages.map((m) => (
            <div key={m.id} className={`flex gap-3 ${m.role === "user" ? "flex-row-reverse" : ""}`}>
              <span
                className={`flex h-9 w-9 shrink-0 items-center justify-center border ${
                  m.role === "bot"
                    ? "border-primary bg-primary text-primary-foreground"
                    : "border-border bg-secondary text-foreground"
                }`}
              >
                {m.role === "bot" ? <Sailboat className="h-4.5 w-4.5" /> : <User className="h-4.5 w-4.5" />}
              </span>
              <div className={`max-w-[85%] ${m.role === "user" ? "text-right" : ""}`}>
                <div
                  className={`inline-block border px-4 py-3 text-left text-[15px] leading-relaxed whitespace-pre-line ${
                    m.role === "bot"
                      ? "border-border bg-card"
                      : "border-primary bg-primary text-primary-foreground"
                  }`}
                >
                  {m.text}
                </div>

                {m.answer?.photo && (
                  <button
                    type="button"
                    onClick={() => setOpenSlug(m.answer!.termSlugs[0] ?? null)}
                    className="mt-2 block border border-border bg-card outline-none focus-visible:ring-2 focus-visible:ring-ring"
                  >
                    <img
                      src={m.answer.photo.url}
                      alt={m.answer.photo.alt}
                      loading="lazy"
                      className="max-h-44 w-full object-contain bg-secondary/30"
                    />
                    <span className="font-mono-naut block border-t border-border bg-secondary/40 px-3 py-1.5 text-left text-[9.5px] uppercase tracking-[0.12em] text-muted-foreground">
                      Fotografia: Wikimedia Commons
                    </span>
                  </button>
                )}

                {m.answer && (m.answer.termSlugs.length > 0 || m.answer.manualRef || m.answer.appLink) && (
                  <div className="mt-2 flex flex-wrap gap-2">
                    {m.answer.termSlugs.map((slug) => {
                      const t = termBySlug.get(slug);
                      if (!t) return null;
                      return (
                        <button
                          key={slug}
                          type="button"
                          onClick={() => setOpenSlug(slug)}
                          className="font-mono-naut border border-primary/60 bg-background px-2.5 py-1.5 text-[10.5px] font-medium uppercase tracking-[0.1em] text-primary transition-colors hover:bg-primary hover:text-primary-foreground"
                        >
                          {t.term}
                        </button>
                      );
                    })}
                    {m.answer.manualRef && (
                      <Link
                        to={`/manual#${m.answer.manualRef.hash}`}
                        className="font-mono-naut flex items-center gap-1.5 border border-border bg-background px-2.5 py-1.5 text-[10.5px] font-medium uppercase tracking-[0.1em] text-foreground transition-colors hover:bg-secondary"
                      >
                        <BookOpenText className="h-3.5 w-3.5" />
                        Manual: {m.answer.manualRef.title}
                      </Link>
                    )}
                    {m.answer.appLink && (
                      <Link
                        to={m.answer.appLink.to}
                        className="font-mono-naut flex items-center gap-1.5 border border-border bg-background px-2.5 py-1.5 text-[10.5px] font-medium uppercase tracking-[0.1em] text-foreground transition-colors hover:bg-secondary"
                      >
                        <ArrowRight className="h-3.5 w-3.5" />
                        {m.answer.appLink.label}
                      </Link>
                    )}
                  </div>
                )}
              </div>
            </div>
          ))}

          {messages.length === 1 && (
            <div className="flex flex-wrap gap-2 pl-12">
              {SUGGESTIONS.map((s) => (
                <button
                  key={s}
                  type="button"
                  onClick={() => ask(s)}
                  className="border border-border bg-card px-3 py-2 text-left text-[13px] text-foreground transition-colors hover:bg-secondary"
                >
                  {s}
                </button>
              ))}
            </div>
          )}
        </div>

        <form
          className="sticky bottom-0 flex gap-2 border-t border-border bg-background py-4"
          onSubmit={(e) => {
            e.preventDefault();
            ask(input);
          }}
        >
          <input
            value={input}
            onChange={(e) => setInput(e.target.value)}
            placeholder={terms.length ? "Escreve a tua dúvida…" : "A carregar o glossário…"}
            disabled={!terms.length}
            className="min-h-11 flex-1 border border-border bg-card px-3.5 text-[15px] outline-none placeholder:text-muted-foreground focus:border-primary focus-visible:ring-2 focus-visible:ring-ring"
          />
          <button
            type="submit"
            disabled={!input.trim() || !terms.length}
            className="flex min-h-11 min-w-11 items-center justify-center border border-primary bg-primary px-4 text-primary-foreground transition-opacity disabled:opacity-40"
            aria-label="Enviar pergunta"
          >
            <Send className="h-4.5 w-4.5" />
          </button>
        </form>
      </main>

      <TermDetail
        term={detailTerm}
        open={detailTerm !== null}
        onOpenChange={(o) => !o && setOpenSlug(null)}
        onPrev={() => openIndex > 0 && setOpenSlug(terms[openIndex - 1].slug)}
        onNext={() => openIndex < terms.length - 1 && setOpenSlug(terms[openIndex + 1].slug)}
        position={Math.max(0, openIndex)}
        total={terms.length || 1}
        index={index}
        onNavigate={setOpenSlug}
      />
    </div>
  );
}
