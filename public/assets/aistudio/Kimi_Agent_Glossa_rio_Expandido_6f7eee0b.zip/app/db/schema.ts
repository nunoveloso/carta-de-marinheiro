import {
  mysqlTable,
  serial,
  varchar,
  text,
  int,
  timestamp,
  // bigint,
} from "drizzle-orm/mysql-core";

export const glossaryTerms = mysqlTable("glossary_terms", {
  id: serial("id").primaryKey(),
  slug: varchar("slug", { length: 120 }).notNull().unique(),
  term: varchar("term", { length: 255 }).notNull(),
  definition: text("definition").notNull(),
  section: varchar("section", { length: 255 }).notNull(),
  subsection: varchar("subsection", { length: 255 }),
  category: varchar("category", { length: 120 }).notNull(),
  subcategory: varchar("subcategory", { length: 120 }).notNull(),
  illustration: varchar("illustration", { length: 80 }).notNull(),
  wikiUrl: varchar("wiki_url", { length: 500 }),
  photoUrl: varchar("photo_url", { length: 700 }),
  photoPage: varchar("photo_page", { length: 700 }),
  sortOrder: int("sort_order").notNull().default(0),
  createdAt: timestamp("created_at").notNull().defaultNow(),
});

export const rieamFeedback = mysqlTable("rieam_feedback", {
  id: serial("id").primaryKey(),
  scenarioId: varchar("scenario_id", { length: 80 }).notNull(),
  message: text("message").notNull(),
  createdAt: timestamp("created_at").notNull().defaultNow(),
});

// Note: FK columns referencing a serial() PK must use:
//   bigint("columnName", { mode: "number", unsigned: true }).notNull()
