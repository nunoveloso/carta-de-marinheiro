import { notInArray } from "drizzle-orm";
import { getDb } from "../api/queries/connection";
import { glossaryTerms } from "./schema";
import { GLOSSARY_TERMS } from "./glossary-data";
import { GLOSSARY_MEDIA } from "./glossary-media";

async function seed() {
  const db = getDb();
  console.log("Seeding glossary...");

  for (const [i, t] of GLOSSARY_TERMS.entries()) {
    const media = GLOSSARY_MEDIA[t.slug] ?? {};
    const row = {
      ...t,
      wikiUrl: media.wikiUrl ?? null,
      photoUrl: media.photoUrl ?? null,
      photoPage: media.photoPage ?? null,
      sortOrder: i,
    };
    await db
      .insert(glossaryTerms)
      .values(row)
      .onDuplicateKeyUpdate({
        set: {
          term: t.term,
          definition: t.definition,
          section: t.section,
          subsection: t.subsection,
          category: t.category,
          subcategory: t.subcategory,
          illustration: t.illustration,
          wikiUrl: row.wikiUrl,
          photoUrl: row.photoUrl,
          photoPage: row.photoPage,
          sortOrder: i,
        },
      });
  }

  // Remove rows whose slug is no longer part of the dataset
  const slugs = GLOSSARY_TERMS.map((t) => t.slug);
  await db.delete(glossaryTerms).where(notInArray(glossaryTerms.slug, slugs));

  console.log(`Done. ${GLOSSARY_TERMS.length} terms upserted.`);
  process.exit(0); // close MySQL connection pool
}

seed();
