# Taxonomia do Glossário do Marinheiro — Categorias e subcategorias

Árvore de classificação usada nas cartas do glossário (filtros por categoria/subcategoria).
Total: **198 termos** · 4 categorias.

```
R.I.E.A.M. (23)
├── Sinais Sonoros (6)
├── Balões (4)
└── Abalroamentos (13)
Segurança e Primeiros Socorros (33)
├── Incêndios (12)
├── Segurança (12)
└── Primeiros Socorros (9)
Marinharia (88)
├── Cabos, Voltas e Nós (19)
├── Âncoras e Amarras (15)
├── Nomenclatura (46)
└── Manobras (8)
Outras Matérias (54)
├── Marés (9)
├── Balizagem (10)
├── Meteorologia (6)
├── Motores (6)
├── Legislação (4)
├── Navegação (3)
└── Siglas (16)
```

## Em árvore Markdown

- **R.I.E.A.M.** (23 termos)
  - Sinais Sonoros (6)
  - Balões (4)
  - Abalroamentos (13)
- **Segurança e Primeiros Socorros** (33 termos)
  - Incêndios (12)
  - Segurança (12)
  - Primeiros Socorros (9)
- **Marinharia** (88 termos)
  - Cabos, Voltas e Nós (19)
  - Âncoras e Amarras (15)
  - Nomenclatura (46)
  - Manobras (8)
- **Outras Matérias** (54 termos)
  - Marés (9)
  - Balizagem (10)
  - Meteorologia (6)
  - Motores (6)
  - Legislação (4)
  - Navegação (3)
  - Siglas (16)
